import { User } from '../user';

export class GroupVm {
  id: string;
  title: string;
  description?: string;
  players: User[];
  category: string;
  createdBy: User;
  banner?: string;
  anyoneCanAcceptRequest: boolean;
  anyoneCanModifyGroup: boolean;
  approveNewPlayers: boolean;
  token?: string;
}
