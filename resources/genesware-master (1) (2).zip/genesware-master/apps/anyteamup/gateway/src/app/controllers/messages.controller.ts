import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import { Controller, Get, HttpStatus, Req, UseGuards } from '@nestjs/common';

import { Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { AuthRequest } from '../models/common';
import { Group } from '../models/group';
import { UserRole } from '../models/user';

@Controller('messages')
export class MessagesController {
  constructor(private core: CoreMsService) {}

  @Get()
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getUserMessages(@Req() { user }: AuthRequest) {
    const payload = { userId: user.id, populate: false };
    const groupResponse = await this.core.send<Group[]>(
      '@group/get_by_userId',
      payload,
      HttpStatus.OK
    );
    const groupIds = groupResponse.data.map((group) => group.id);

    if (!groupIds.length) return [];

    const messageResponses = await this.core.send<any[]>(
      '@message/get_all',
      { groupId: groupIds },
      HttpStatus.OK
    );

    return messageResponses.data;
  }
}
