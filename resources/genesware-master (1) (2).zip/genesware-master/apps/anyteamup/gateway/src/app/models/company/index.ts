export interface Company {
    id: string;
    createdAt: Date;
    updatedAt: Date;
    name: string;
    approved: boolean;
    address: string;
    contacts: {value: string, type: string}[];
    users: {id: string, role: string}[];
}