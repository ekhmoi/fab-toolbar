import { CoreMsModule } from '@genesware/shared/nestjs-sdk';
import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';

import { AppController } from './app.controller';
import CONTROLLERS from './controllers';
import { AuthService, JwtStrategy } from './services';

@Module({
  imports: [
    HttpModule,
    JwtModule.register({
      secret: process.env.JWT_KEY,
      // when expiresIn is not passed, jwt lives forever
      // signOptions: { expiresIn: process.env.JWT_EXPIRES_IN },
    }),
    CoreMsModule.forRoot({ redis: { host: process.env.REDIS_HOST, port: +process.env.REDIS_PORT } }),
  ],
  controllers: [...CONTROLLERS, AppController],
  providers: [AuthService, JwtStrategy],
})
export class AppModule {}
