import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import {
  Body,
  Controller,
  HttpException,
  HttpStatus,
  Logger,
  Post,
} from '@nestjs/common';

import { LoginResponseVm, LoginVm } from '../models/user';

const logger = new Logger('TokenController');

@Controller('tokens')
export class TokensController {
  constructor(private core: CoreMsService) {}

  @Post()
  async login(@Body() loginVm: LoginVm): Promise<LoginResponseVm> {
    try {
      const loginResponse = await this.core.send<LoginResponseVm>(
        '@token/create_for_credentials',
        loginVm,
        HttpStatus.OK
      );

      return loginResponse.data;
    } catch (error) {
      const { status, message, errors } = error as any;
      throw new HttpException(message, status);
    }
  }

  @Post('google')
  async loginWithGoogle(@Body() { token }: { token: string }) {
    logger.log('Signing in with google: ' + token);
    const loginResponse = await this.core.send<LoginResponseVm>(
      '@token/create_from_google_token',
      { token },
      HttpStatus.CREATED
    );
    logger.log(`Google sign in response: ${JSON.stringify(loginResponse)}`);
    return loginResponse.data;
  }
}
