import { EventStatus, TimeOfDay } from './event.enums';

export interface Event<T = string> {
  id: string;
  group: T;
  status: EventStatus;
  category: string;
  price: number;
  createdBy: string;
  currency: string;
  date: Date;
  title: string;
  startTime: Date;
  endTime: Date;
  booked: boolean;
  arenaId?: string;
  location: {
    name: string;
    address: string;
    coordinates: [[number]];
  };
  banner: string;
  description: string;
  preferredTimesOfTheDay: TimeOfDay[];
}
