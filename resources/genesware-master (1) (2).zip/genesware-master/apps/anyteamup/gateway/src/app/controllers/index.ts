import { ArenasController } from './arenas.controller';
import { CategoriesController } from './categories.controller';
import { CompaniesController } from './companies.controller';
import { EventsController } from './events.controller';
import { GroupsController } from './groups.controller';
import { MessagesController } from './messages.controller';
import { NotificationsController } from './notifications.controller';
import { RequestsController } from './requests.controller';
import { ReviewsController } from './reviews.controller';
import { TokensController } from './tokens.controller';
import { UsersController } from './users.controller';

export default [
  ArenasController,
  CategoriesController,
  EventsController,
  GroupsController,
  MessagesController,
  NotificationsController,
  RequestsController,
  ReviewsController,
  TokensController,
  UsersController,
  CompaniesController,
];
