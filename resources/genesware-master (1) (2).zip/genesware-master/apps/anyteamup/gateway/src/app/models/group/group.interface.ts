export interface Group {
  id: string;
  title: string;
  description?: string;
  users: string[];
  category: string;
  createdBy: string;
  banner?: string;
  anyoneCanAcceptRequest: boolean;
  anyoneCanModifyGroup: boolean;
  approveNewUsers: boolean;
  token?: string;
}
