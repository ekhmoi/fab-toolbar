export interface IMessage {
  parts: any[];
}
