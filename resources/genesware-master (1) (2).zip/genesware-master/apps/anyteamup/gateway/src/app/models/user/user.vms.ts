import { UserGender, UserRole } from './user.enums';

export class UserVm {
  username: string;
  firstName?: string;
  lastName?: string;
  fullName?: string;
  role?: UserRole;
}

export class ChangePasswordVm {
  password: string;
  newPassword: string;
}

export class ChangeProfileVm {
  firstName?: string;
  lastName?: string;
  avatar?: string;
  speaks?: string[];
  dob?: Date;
  weight?: number;
  height?: number;
  gender?: UserGender;
  about?: string;
}

export class ChangeSettingsVm {
  selectedCategories?: string[];
  maxDistance?: number;
  theme?: string;
  sortBy?: string;
  language?: string;
}

export class LoginVm {
  email: string;
  password: string;
}

export class RegisterVm extends LoginVm {
  profile: {
    firstName: string;
    lastName: string;
    speaks?: string[];
    avatar?: string;
    dob?: Date;
    weight?: number;
    height?: number;
    gender?: UserGender;
    about?: string;
  };
}
export class LoginResponseVm {
  token: string;
  user: UserVm;
}
