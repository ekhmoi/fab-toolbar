import { PipeTransform, Injectable, ArgumentMetadata } from '@nestjs/common';

@Injectable()
export class ToNumberPipe implements PipeTransform {
  transform(value: any, { type, metatype }: ArgumentMetadata) {
    if (type === 'query' && metatype === Number) {
      return value && !isNaN(value) ? parseFloat(value) : 0;
    }

    return value;
  }
}
