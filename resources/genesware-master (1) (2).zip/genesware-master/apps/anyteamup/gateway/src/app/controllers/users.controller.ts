import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import {
  BadRequestException,
  Body,
  Controller,
  Get,
  HttpException,
  HttpStatus,
  InternalServerErrorException,
  Logger,
  Param,
  Post,
  Put,
  Query,
  Request,
  UseGuards,
} from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { IpAddress, Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { AuthRequest } from '../models/common';
import {
  ChangePasswordVm,
  ChangeProfileVm,
  RegisterVm,
  User,
  UserPreference,
  UserRole,
  UserStatus,
} from '../models/user';

const logger = new Logger('UserController');

@Controller('users')
export class UsersController {
  constructor(private core: CoreMsService, private http: HttpService) {}

  @Get()
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getCurrentUser(@Request() { user }: AuthRequest) {
    const currentUser = await this.getUser(user.id);
    return { ...currentUser, ratings: [], reviews: [] };
  }

  @Post()
  async register(@Body() registerVm: RegisterVm): Promise<User> {
    try {
      // create user
      const { data: createdUser } = await this.core.send<User>(
        '@user/create',
        { ...registerVm, status: UserStatus.Active, loginType: 'Email' },
        HttpStatus.CREATED
      );
      this._sendRegistrationEmail(createdUser);
      return createdUser;
    } catch (err) {
      throw new HttpException(err, err.status);
    }
  }

  private async _sendRegistrationEmail({ status, email, profile }: User) {
    const name = `${profile.firstName || ''} ${profile.firstName || ''}`.trim();
    let params = {
      to: email,
      context: { name } as { [param: string]: any },
      template: 'welcome',
      subject: 'Welcome to AnyTeam!',
    };

    if (status === UserStatus.PendingActivation) {
      const createTokenPayload = {
        payload: { email: email },
        expiresIn: '30d',
      };
      const { data: token } = await this.core.send<string>(
        '@token/create_expirable_token',
        createTokenPayload,
        HttpStatus.CREATED
      );
      params = {
        to: email,
        template: 'confirmation',
        subject: 'Confirm your email',
        context: { name, token },
      };
    }

    // FIXME
    // this.core.send('@mailer/send', params);
  }

  @Get('geoip')
  async getGeoIP(@IpAddress() ipAddress: string) {
    if (!ipAddress) {
      throw new InternalServerErrorException('Could not determine ip address');
    }
    try {
      const response = await this.http.get(`https://freegeoip.app/json/${ipAddress}`).toPromise();

      return response.data;
    } catch (err) {
      return {};
    }
  }

  @Post('reset-password-link')
  async requestResetPasswordLink(@Body() { email }: { email: string }): Promise<void> {
    try {
      await this.core.send<any>('@user/get_by_email', { email }, HttpStatus.OK);
      const { data: token } = await this.core.send<string>(
        '@token/create_expirable_token',
        {
          payload: { email },
          expiresIn: '20m',
        },
        HttpStatus.CREATED
      );

      // send confirmation email
      // FIXME
      // this.core.client.emit('@mailer/send', {
      //   to: email,
      //   template: 'reset-password',
      //   subject: 'Reset password',
      //   context: {
      //     token,
      //   },
      // });
    } catch (error) {
      logger.error(error);
      throw new BadRequestException(error);
    }
  }

  @Post('password')
  async setNewPassword(@Body() { token, password }: { password: string; token: string }) {
    console.log('Query param token is', token);
    const docededToken = await this.core.send<{ email: string }>('@token/decode', { token }, HttpStatus.OK);
    console.log(docededToken);
    await this.core.send('@user/set_new_password', { email: docededToken.data.email, password }, HttpStatus.ACCEPTED);
  }

  @Put('password')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async changePassword(@Body() changePasswordVm: ChangePasswordVm, @Request() { user }: AuthRequest): Promise<any> {
    const payload = { ...changePasswordVm, id: user.id, userId: user.id };
    const response = await this.core.send<any>('@user/change_password', payload, HttpStatus.ACCEPTED);

    return response.data;
  }

  @Put('preferences')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async upsertPreferences(@Body() preferences: UserPreference[], @Request() { user }: AuthRequest): Promise<void> {
    const payload = {
      userId: user.id,
      preferences: preferences.map((p) => ({ ...p, userId: user.id })),
    };
    const response = await this.core.send<void>('@user/set_preferences', payload, HttpStatus.ACCEPTED);

    return response.data;
  }

  @Put('profile')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async changeProfile(@Body() changeProfileVm: ChangeProfileVm, @Request() { user }: AuthRequest): Promise<any> {
    const payload = { id: user.id, userId: user.id, profile: changeProfileVm };
    const response = await this.core.send<User>('@user/change_profile', payload, HttpStatus.ACCEPTED);

    return response.data;
  }

  @Get('activate')
  async activateUser(@Query('token') token: string) {
    console.log('Query param token is', token);
    const { data } = await this.core.send<{ email: string }>('@token/decode', { token }, HttpStatus.OK);
    console.log(data);
    await this.core.send('@user/activate', { email: data.email });
  }

  @Get(':id')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getUser(@Param('id') id: string) {
    const paylod = { id, full: true, populate: true };
    const response = await this.core.send<User, { id: string; full: boolean }>(
      '@user/get_by_id',
      paylod,
      HttpStatus.OK
    );

    return response.data;
  }
}
