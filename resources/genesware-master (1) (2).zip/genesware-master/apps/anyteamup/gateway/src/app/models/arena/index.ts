
export interface SearchArenasParams {
    lat: number;
    maxDistance: number;
    lng: number;
    categories?: string;
    createdBy?: string;
    sortBy?: string;
    sortDirection?: number;
  }
  
  export interface Arena {
    id: string;
    name: string;
    category: string;
    images: string[];
    createdBy?: string;
    companyId?: string;
    recommendedUsers: [number, number];
    location: {
      coordinates: [number, number];
      street?: string;
      country?: string;
      city?: string;
      zip?: string;
      address?: string;
    };
  }