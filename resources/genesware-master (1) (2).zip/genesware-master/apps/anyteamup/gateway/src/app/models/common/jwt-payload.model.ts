import { UserRole } from '../user';

export interface JwtPayload {
  email: string;
  role: UserRole;
  iat?: Date;
  id: string;
}
