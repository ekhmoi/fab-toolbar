import { CoreMsService, MSResponse } from '@genesware/shared/nestjs-sdk';
import {
  BadRequestException,
  Body,
  Controller,
  Get,
  HttpStatus,
  Logger,
  Param,
  Post,
  Put,
  Req,
  Request,
  UseGuards,
} from '@nestjs/common';
import { Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { AuthRequest } from '../models/common';
import {
  CreateRequestVm,
  IRequest,
  RequestStatus,
  UpdateRequestStatusVm,
} from '../models/request';
import { UserRole } from '../models/user';

const logger = new Logger('RequestsController');
const MODEL_NAME_TO_MS_PREFIX = new Map([
  ['group', '@group'],
  ['arena', '@arena'],
  ['booking', '@booking'],
]);

@Controller('requests')
export class RequestsController {
  constructor(private core: CoreMsService) {}

  @Post()
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async createRequest(
    @Body() createRequestVm: CreateRequestVm,
    @Req() { user }: AuthRequest
  ) {
    // First we need to find out who are the receivers of this request
    // To do this we need to figure out which microservice to call
    // We use MODEL_NAME_TO_MS_PREFIX to map requestedForDocumentName to ms prefix
    const msPrefix = MODEL_NAME_TO_MS_PREFIX.get(
      createRequestVm.requestedForDocumentName
    );
    if (!msPrefix) {
      throw new BadRequestException(
        'invalid',
        `${msPrefix} is not a supported requestedForDocumentName`
      );
    }
    console.log('Getting receivers', msPrefix);
    const receiversResponse = await this.core.send<string[]>(
      `${msPrefix}/get_moderators_for_document`,
      {
        id: createRequestVm.requestedForDocumentId,
      },
      HttpStatus.OK
    );
    console.log('receivers', receiversResponse);

    if (!receiversResponse.data || !receiversResponse.data.length) {
      throw new BadRequestException('WTF mate?');
    }

    // Fill out the received data and user id
    createRequestVm.receiverIds = receiversResponse.data;
    createRequestVm.createdBy = user.id;

    // Then create a new request
    const payload = { request: createRequestVm, populate: true };
    const requestResponse = await this.core.send<IRequest>(
      '@request/create',
      payload,
      HttpStatus.CREATED
    );
    return requestResponse.data;
  }

  @Put(':id/status')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async updateRequestStatus(
    @Param('id') id: string,
    @Body() { status }: UpdateRequestStatusVm,
    @Req() { user }: AuthRequest
  ) {
    const payload = { id, status, userId: user.id, populate: false };
    let response: MSResponse<any>;

    switch (status) {
      case RequestStatus.Accepted:
        response = await this.core.send(
          '@request/accept_request',
          payload,
          HttpStatus.ACCEPTED
        );
        break;
      case RequestStatus.Rejected:
        response = await this.core.send(
          '@request/reject_request',
          payload,
          HttpStatus.ACCEPTED
        );
        break;
      default:
        throw new BadRequestException('Status is not valid');
    }

    return response.data;
  }

  @Get()
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async get(@Request() { user }: AuthRequest) {
    const payload = { userId: user.id, populate: true };
    const response = await this.core.send<IRequest[]>(
      '@request/get_by_userId',
      payload,
      HttpStatus.OK
    );

    return response.data;
  }

  @Get(':id')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getById(@Request() { user }: AuthRequest, @Param('id') id: string) {
    const payload = { userId: user.id, id, populate: true };
    const response = await this.core.send<IRequest>(
      '@request/get_by_id',
      payload,
      HttpStatus.OK
    );

    return response.data;
  }
}
