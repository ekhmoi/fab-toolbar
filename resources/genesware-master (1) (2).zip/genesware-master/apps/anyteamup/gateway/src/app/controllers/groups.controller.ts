import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Param,
  Patch,
  Post,
  Req,
  Request,
  UseGuards,
} from '@nestjs/common';

import { Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { AuthRequest } from '../models/common';
import { Group, GroupVm } from '../models/group';
import { IMessage } from '../models/message';
import { User, UserRole } from '../models/user';

@Controller('groups')
export class GroupsController {
  constructor(private readonly core: CoreMsService) {}

  @Delete(':id/users/:userId')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async removeUserFromGroup(
    @Param('id') id: string,
    @Param('userId') userIdToDelete: string,
    @Request() { user }: AuthRequest
  ) {
    const payload = { id, userId: user.id, users: [userIdToDelete] };
    await this.core.send('@group/remove_users', payload, HttpStatus.ACCEPTED);

    return { success: true };
  }

  @Get()
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async get(@Req() { user }: AuthRequest): Promise<Group[]> {
    const payload = { userId: user.id, populate: true };
    const groupResponse = await this.core.send<Group[]>(
      '@group/get_by_userId',
      payload,
      HttpStatus.OK
    );

    return groupResponse.data;
  }

  @Get(':id')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getById(
    @Request() { user }: AuthRequest,
    @Param('id') id: string
  ): Promise<Group> {
    const payload = { id, userId: user.id, populate: true };
    const response = await this.core.send<Group>(
      '@group/get_by_id',
      payload,
      HttpStatus.OK
    );

    return response.data;
  }

  @Post()
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async create(@Body() groupBody: Group, @Request() { user }: AuthRequest) {
    const payload = { group: groupBody, userId: user.id, populate: true };
    const response = await this.core.send<Group>(
      '@group/create',
      payload,
      HttpStatus.CREATED
    );

    return response.data;
  }

  @Get(':id/messages')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getGroupMessages(
    @Req() { user }: AuthRequest,
    @Param('id') id: string
  ): Promise<IMessage[]> {
    const payload = { createdBy: user.id, groupId: id };
    const response = await this.core.send<IMessage[]>(
      '@message/get_all',
      payload,
      HttpStatus.OK
    );

    return response.data;
  }

  @Get(':id/users')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getGroupUsers(
    @Req() { user }: AuthRequest,
    @Param('id') id: string
  ): Promise<User[]> {
    const groupResponse = await this.core.send<Group>(
      '@group/get_by_id',
      { id },
      HttpStatus.OK
    );
    const userResponse = await this.core.send<User[]>(
      '@user/get_by_ids',
      { ids: groupResponse.data.users },
      HttpStatus.OK
    );

    return userResponse.data;
  }

  @Patch(':id')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async partialUpdateGroup(
    @Body() body: Partial<GroupVm>,
    @Req() req: AuthRequest,
    @Param('id') groupId: string
  ) {
    const payload = {
      id: groupId,
      group: body,
      userId: req.user.id,
      populate: true,
    };
    const response = await this.core.send<GroupVm>(
      '@group/update_partial',
      payload,
      HttpStatus.ACCEPTED
    );

    return response.data;
  }

  // Create token to join
  @Post(':id/token')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async createJoinToken(
    @Req() { user }: AuthRequest,
    @Param('id') groupId: string
  ) {
    const payload = { id: groupId, userId: user.id };
    const response = await this.core.send<string>(
      '@group/create_join_token',
      payload,
      HttpStatus.CREATED
    );

    return response.data;
  }
}
