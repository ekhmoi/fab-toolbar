import { RequestStatus } from './request.enums';
import { IRequest } from './request.interfaces';
export interface CreateRequestVm extends Partial<IRequest> {}

export interface UpdateRequestStatusVm {
  status: RequestStatus;
}
