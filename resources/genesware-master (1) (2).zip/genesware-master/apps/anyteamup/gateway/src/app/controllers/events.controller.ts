import { CoreMsService, NotificationService } from '@genesware/shared/nestjs-sdk';
import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
  Req,
  Request,
  UseGuards,
} from '@nestjs/common';

import { Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { Arena } from '../models/arena';
import { Booking } from '../models/booking';
import { AuthRequest } from '../models/common';
import { CreateEventVm, Event, EventStatus, GetEventsVm } from '../models/event';
import { Group } from '../models/group';
import { User, UserRole } from '../models/user';
import { RequestsController } from './requests.controller';

@Controller('events')
export class EventsController {
  constructor(private core: CoreMsService, private notificationService: NotificationService) {}

  @Post()
  @Roles(UserRole.User, UserRole.Manager, UserRole.Admin)
  @UseGuards(JwtGuard, RolesGuard)
  async create(@Request() req: AuthRequest, @Body() params: CreateEventVm) {
    const { user } = req;
    const groupId = await this._createGroupForEvent(params, user.id);
    // Then call event ms to create new event
    const payload = {
      event: {
        ...params,
        booked: !!params.booking || params.booked || false,
        startTime: params.booking?.bookedFrom || params.startTime,
        endTime: params.booking?.bookedTo || params.endTime,
        group: groupId,
      },
      userId: user.id,
      populate: true,
    };
    try {
      const response = await this.core.send<Event>('@event/create', payload, HttpStatus.CREATED);
      if (params.booking && params.arenaId) {
        return this._createBookingForEvent(params.booking, response.data, user);
      }

      return response.data;
    } catch (err) {
      console.log('Err', err);
      throw err;
    }
  }

  private async _createBookingForEvent(bookingBody: Partial<Booking>, event: Event, user: User) {
    try {
      console.log('Creating booking for arena:', event.arenaId);
      const { data: arena } = await this.core.send<Arena>('@arena/get_by_id', { id: event.arenaId }, HttpStatus.OK);

      console.log('Creating new booking', bookingBody);
      const { data: booking } = await this.core.send<Booking>('@booking/create', {
        ...bookingBody,
        createdBy: user.id,
        status: arena.companyId ? 'pending' : 'approved',
      });

      if (arena.companyId) {
        console.log(`Arena ${arena.id} belongs to company ${arena.companyId}.`);
        console.log(`Creating new CreateBooking request for arena ${arena.id}`);
        this._createBookingRequest(booking, event, user);
      }

      await this.core.send(
        '@event/update',
        { id: event.id, event: { bookingId: booking.id }, userId: user.id },
        HttpStatus.ACCEPTED
      );
      return { ...event, bookingId: booking.id };
    } catch (err) {
      console.log('Something hapened', err);
      return event;
    }
  }

  private async _createBookingRequest(booking: Booking, event: Event, user: User) {
    try {
      // Create a NewBooking request to company's users as receivers
      const requestsController = new RequestsController(this.core);
      const request = await requestsController.createRequest(
        {
          createdBy: user.id,
          type: 'CreateBooking',
          requestedForDocumentId: booking.id,
          requestedForDocumentName: 'booking',
        },
        { user } as any
      );
      console.log('Request has been send', request);
    } catch (err) {
      console.log('Could not create a request to CreateBooking', err);
    }
  }

  private async _createGroupForEvent(event: CreateEventVm, userId: string) {
    const { anyoneCanAcceptRequest, anyoneCanModifyGroup, approveNewUsers, ...eventBody } = event;
    const groupPayload = {
      userId,
      group: {
        category: eventBody.category,
        title: eventBody.title,
        anyoneCanAcceptRequest,
        anyoneCanModifyGroup,
        approveNewUsers,
      },
      populate: false,
    };
    const groupResponse = await this.core.send<Group>('@group/create', groupPayload, HttpStatus.CREATED);

    return groupResponse.data.id;
  }

  @Put(':id/status')
  @Roles(UserRole.User, UserRole.Manager, UserRole.Admin)
  @UseGuards(JwtGuard, RolesGuard)
  async updateEventStatus(
    @Request() { user }: AuthRequest,
    @Param('id') id: string,
    @Body() { status }: { status: EventStatus }
  ) {
    const payload = { id, status, userId: user.id, populate: true };
    const { data: event } = await this.core.send<Event<Group>>('@event/update_status', payload, HttpStatus.ACCEPTED);

    if (event.status === EventStatus.Finished) {
      this._onEventStatusFinished(event);
    }

    return event;
  }

  @Get('joined')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getJoinedEvents(@Req() { user }: AuthRequest) {
    const groupPayload = {
      userId: user.id,
      populate: false, // no need to populate groups as we only want the ids
    };
    const groupResponse = await this.core.send<Group[]>('@group/get_by_userId', groupPayload, HttpStatus.OK);
    const groupIds = groupResponse.data.map((group) => group.id);

    if (!groupIds.length) return [];

    const eventPayload = {
      groupIds,
      populate: true,
    };
    const eventResponse = await this.core.send<Event[]>('@event/get_by_groupIds', eventPayload, HttpStatus.OK);

    return eventResponse.data;
  }

  @Get()
  async get(@Query() queryParams: GetEventsVm) {
    const payload = { params: queryParams, populate: true };
    const response = await this.core.send<Event[]>('@event/search', payload, HttpStatus.OK);

    return response.data;
  }

  @Get(':id')
  async getById(@Req() req: AuthRequest, @Param('id') id: string): Promise<any> {
    return this._getById(id);
  }

  private async _getById(id: string) {
    const payload = { id, populate: true };
    const response = await this.core.send<Event[]>('@event/get_by_id', payload, HttpStatus.OK);

    return response.data;
  }

  @Put(':id')
  @Roles(UserRole.Admin)
  @UseGuards(JwtGuard, RolesGuard)
  async update(@Body() event: Event, @Request() { user }: AuthRequest, @Param('id') id: string) {
    const payload = { id, event, userId: user.id, populate: true };
    const response = await this.core.send<Event>('@event/update', payload, HttpStatus.ACCEPTED);

    return response.data;
  }

  @Delete(':id')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async delete(@Param('id') id: string, @Request() { user }: AuthRequest) {
    await this.core.send('@event/delete', { id, userId: user.id }, HttpStatus.NO_CONTENT);

    return { success: true };
  }

  async _onEventStatusFinished(event: Event<Group>) {
    console.log('Event status is finished sending notifications', event);
    // get users of event by calling @group/get_by_id {id: params.group}
    const group = event.group;
    console.log('Group', group);
    const requests = [];
    const notifications = [];
    // call request microservice ('@request/create') to create a request to review players
    group.users.forEach((user) => {
      const userId = (user as any).id as string;
      console.log('Sending request and notification for user', userId);
      requests.push({
        createdBy: event.createdBy,
        type: 'RequestEventFeedback',
        receiverIds: [userId],
        requestedForDocumentId: event.id,
        requestedForDocumentName: 'event',
      });
      if (userId !== event.createdBy) {
        notifications.push({
          type: '@event/status_updated',
          relatedDocumentId: event.id,
          relatedDocumentModelName: 'event',
          receiverId: userId,
          initiator: event.createdBy,
          data: { status: event.status },
        });
      }
    });

    this.core.send('@request/create_many', { requests });
    console.log('Sending notification', JSON.stringify(notifications, undefined, 2));
    this.notificationService.sendNotifications(
      notifications.map((notification) => ({
        notification,
        options: { ws: true },
      }))
    );
  }
}
