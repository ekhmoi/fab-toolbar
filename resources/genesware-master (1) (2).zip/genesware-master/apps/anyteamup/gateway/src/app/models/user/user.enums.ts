export enum UserGender {
  Female = 'female',
  Male = 'male',
  Other = 'other',
  PreferNotToSay = 'private',
}

export enum UserRole {
  Admin = 'Admin',
  User = 'User',
  Manager = 'Manager',
}
