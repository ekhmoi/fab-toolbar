export interface UserPreference {
    name: string;
    userId: string;
    key: string;
}