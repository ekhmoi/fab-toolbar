import { RequestStatus } from './request.enums';

export interface IRequest {
  id: string;
  type: string;
  status: RequestStatus;
  createdBy: string;
  receiverIds: string[];
  respondedById: string;
  requestedForDocumentId?: string;
  requestedForDocumentName?: string;
  updatedAt: Date;
  createdAt: Date;
}
