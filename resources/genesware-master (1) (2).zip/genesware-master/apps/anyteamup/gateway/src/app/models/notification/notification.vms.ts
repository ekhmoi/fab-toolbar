import { User } from '../user';
import { NotificationType } from './notification.enums';

export class NotificationVM {
  type: NotificationType;
  receiverIds: string[];
  relatedDocument: any;
  initiator: User;
}
