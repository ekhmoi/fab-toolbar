export enum EventStatus {
  Active = 'active',
  Deleted = 'deleted',
  Finished = 'finished',
  Canceled = 'canceled',
  Confirmed = 'confirmed',
}

export enum TimeOfDay {
  Morning = 'morning',
  Afternoon = 'afternoon',
  Evening = 'evening',
  Night = 'night',
}
