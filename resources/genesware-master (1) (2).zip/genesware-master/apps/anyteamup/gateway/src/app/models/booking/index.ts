type TimeUnit = 'millisecond' | 'second' | 'minute' | 'hour' | 'day' | 'week' | 'month' | 'quarter' | 'year';

enum BookingStatus {
  Created,
  Pending,
  Rejected,
  Approved,
  Finished,
  Canceled,
}

export interface Booking {
  id: string;
  placeId: string;
  optionId: string;
  bookedFrom: Date;
  bookedTo: Date;
  createdBy: string;
  status: BookingStatus;
  paid: boolean;
  data?: any;
  createdAt: Date;
  updatedAt: Date;
}

export function createBooking(params: Partial<Booking>) {
  return {} as Booking;
}

export interface BookingOption {
  id: string;
  name: string;
  description?: string;
  type?: string;
  optionProviderId?: string;
  duration: number;
  timeUnit: TimeUnit;
  createdBy: string;
  price?: string;
  currency?: string;
  recoveryTime?: number;
  date?: any;
}

export type WeekDay = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';
export interface BookingPlace {
  id: string;
  name: string;
  schedule: [WeekDay, Date, Date][];
  serviceProviderId: string;
  createdBy: string;
  date?: any;
}
