import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import { JwtPayload } from '../models/common';
import { User } from '../models/user';
import { HttpStatus, Injectable, Logger } from '@nestjs/common';

const logger = new Logger('AuthService');

@Injectable()
export class AuthService {
  constructor(private core: CoreMsService) {}

  async validateUser({ id }: JwtPayload): Promise<User> {
    const userResponse = await this.core.send<User>('@user/get_by_id', { id, full: true }, HttpStatus.OK);
    return userResponse.data;
  }
}
