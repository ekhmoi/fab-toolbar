import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import {
  Body,
  Controller,
  Delete,
  ForbiddenException,
  Get,
  HttpStatus,
  InternalServerErrorException,
  Param,
  Post,
  Request,
  UseGuards,
} from '@nestjs/common';

import { Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { AuthRequest } from '../models/common';
import { PostReviewDto, Review } from '../models/review';
import { UserRole } from '../models/user';

@Controller('reviews')
export class ReviewsController {
  constructor(private core: CoreMsService) {}

  @Post()
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async create(
    @Body() params: PostReviewDto,
    @Request() { user }: AuthRequest
  ) {
    return this.core.send('@review/create', {
      review: params,
      userId: user.id,
    });
  }

  @Post('bulk')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async createBulk(
    @Body()
    { reviews, requestId }: { reviews: PostReviewDto[]; requestId: string },
    @Request() { user }: AuthRequest
  ) {
    // call @request/accept_request and expect HttpStatus.ACCEPTED
    const { data: acceptedRequest } = await this.core.send<{
      requestedForDocumentId: string;
    }>(
      '@request/accept_request',
      { id: requestId, userId: user.id },
      HttpStatus.ACCEPTED
    );

    const { data: event } = await this.core.send<{
      group: string;
      createdBy: string;
    }>(
      '@event/get_by_id',
      { id: acceptedRequest.requestedForDocumentId },
      HttpStatus.OK
    );
    const { data: group } = await this.core.send<{ users: string[] }>(
      '@group/get_by_id',
      { id: event.group }
    );
    const users = [event.createdBy, ...group.users];
    reviews.forEach((review) => {
      if (!users.includes(review.reviewedDocumentId)) {
        throw new ForbiddenException();
      }
    });

    return this.core.send('@review/create_many', { reviews, userId: user.id });
  }

  @Get()
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async get(): Promise<Review[]> {
    try {
      const filter = {};
      const reviewResponse = await this.core.send<Review[]>(
        '@review/get_all',
        { filter, populate: true },
        HttpStatus.OK
      );
      return reviewResponse.data;
    } catch (e) {
      throw new InternalServerErrorException(e);
    }
  }

  @Delete(':id')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async delete(
    @Param('id') id: string,
    @Request() { user }: AuthRequest
  ): Promise<any> {
    this.core.send('@review/relete', { id, userId: user.id });
  }
}
