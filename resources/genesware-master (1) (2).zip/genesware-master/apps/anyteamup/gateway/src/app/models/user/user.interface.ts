import { UserGender, UserRole } from './user.enums';
export enum UserStatus {
  PendingActivation = 'PendingActivation',
  Active = 'Active',
  Disabled = 'Disabled',
  Deleted = 'Deleted',
}

export const DEFAULT_USER_AVATAR = null;
export interface User {
  id: string;
  email: string;
  password: string;
  role: UserRole;
  devices: string[];
  status: UserStatus;
  profile: {
    firstName: string;
    lastName: string;
    avatar?: string;
    speaks?: string[];
    dob?: Date;
    weight?: number;
    height?: number;
    gender?: UserGender;
    about?: string;
  };
  settings: {
    selectedCategories: string[];
    maxDistance: number;
    theme: string;
    sortBy: string;
    language: string;
  };
}
