export enum NotificationStatus {
  New = 'new',
  Read = 'read',
}

export enum NotificationType {
  JoinEventRequestAccepted = 'JoinEventRequestAccepted',
  RequestReject = 'RequestReject',
  RemovedFromGame = 'RemovedFromGame',
  JoinRequest = 'JoinRequest',
  PlayerJoined = 'PlayerJoined',

  JoinGroupRequestAccepted = 'JoinGroupRequestAccepted',
  JoinGroupRequestRejected = 'JoinGroupRequestRejected',
  JoinGroupRequestReceived = 'JoinGroupRequestReceived',
  PlayerJoinedGroup = 'PlayerJoinedGroup',
  RemovedFromGroup = 'RemovedFromGroup',

  Review = 'Review',
  RequestGameStatus = 'RequestGameStatus',
  RequestGameReview = 'RequestGameReview',

  MessageReceived = 'MessageReceived',
  NotificationType = 'MessageDeleted',
}
