import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import {
  Body,
  Controller,
  ForbiddenException,
  Get,
  HttpStatus,
  Param,
  Post,
  Request,
  UseGuards,
} from '@nestjs/common';

import { Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { Arena } from '../models/arena';
import { AuthRequest } from '../models/common';
import { Company } from '../models/company';
import { Review } from '../models/review';
import { User, UserRole } from '../models/user';

@Controller('companies')
export class CompaniesController {
  constructor(private core: CoreMsService) {}

  @Get()
  @Roles(UserRole.Admin, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async get(@Request() { user }: AuthRequest): Promise<Company[]> {
    const { data: companies } = await this.core.send<Company[]>(
      '@company/get_by_userId',
      { userId: user.id },
      HttpStatus.OK
    );
    return companies;
  }

  @Get(':id')
  @Roles(UserRole.Admin, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getById(@Param('id') id: string, @Request() { user }: AuthRequest) {
    const response = await this.core.send<Company>(
      '@company/get_by_id',
      { id },
      HttpStatus.OK
    );

    if (response.data.users.some((u) => u.id === user.id)) {
      return response.data;
    } else {
      throw new ForbiddenException();
    }
  }

  @Get(':id/reviews')
  @Roles(UserRole.Admin, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getCompanyReviews(
    @Param('id') id: string,
    @Request() { user }: AuthRequest
  ) {
    const { data: arenas } = await this.core.send<Arena[]>(
      '@arena/search',
      { companyId: id },
      HttpStatus.OK
    );
    const { data: reviews } = await this.core.send<Review[]>(
      '@review/get_all',
      {
        reviewedDocumentId: { $in: [id, ...arenas.map((arena) => arena.id)] },
      },
      HttpStatus.OK
    );

    return reviews;
  }

  @Get(':id/managers')
  @Roles(UserRole.Admin, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getCompanyManagers(
    @Param('id') id: string,
    @Request() req: AuthRequest
  ) {
    const company = await this.getById(id, req);
    const userRoleMap = company.users.reduce(
      (urMap, { id, role }) => ({ ...urMap, [id]: role }),
      {}
    );
    const { data: users } = await this.core.send<User[]>(
      '@user/get_by_ids',
      {
        ids: Object.keys(userRoleMap),
      },
      HttpStatus.OK
    );

    return users.map((user) => ({ ...user, role: userRoleMap[user.id] }));
  }

  @Post()
  @Roles(UserRole.Admin, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async create(
    @Request() { user }: AuthRequest,
    @Body() company: Company
  ): Promise<Company> {
    const { data: createdCompany } = await this.core.send<Company>(
      '@company/create',
      { ...company, createdBy: user.id },
      HttpStatus.CREATED
    );
    return createdCompany;
  }
}
