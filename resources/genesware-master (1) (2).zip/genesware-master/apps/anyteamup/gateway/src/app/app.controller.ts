import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import { Controller, Get } from '@nestjs/common';

@Controller('')
export class AppController {
  constructor(core: CoreMsService) {
    core.init();
  }

  @Get()
  home() {
    return `
    <html>
      <head>
        <title>Anyteamup Gateway</title>
      </head>
      <body>
        <p>Read more in <a href="/docs">API Documentation</a></p>
      </body>
    </html>
    `;
  }
}
