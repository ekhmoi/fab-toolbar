import { ReviewType } from './review.enums';

export interface PostReviewDto {
  reviewedDocumentId: string;
  reviewedForId: string;
  reviewedType: ReviewType;
  message: string;
  rating: number;
}
