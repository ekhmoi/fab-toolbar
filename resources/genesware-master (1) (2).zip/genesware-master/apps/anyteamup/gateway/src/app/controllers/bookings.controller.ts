import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import { Controller, Get, HttpStatus, Param, Request } from '@nestjs/common';

import { Booking } from '../models/booking';
import { AuthRequest } from '../models/common';

@Controller('bookings')
export class BookingsController {
  constructor(private core: CoreMsService) {}

  @Get(':id')
  async getById(@Request() req: AuthRequest, @Param('id') id: string): Promise<Booking> {
    const payload = { id, populate: true };
    const response = await this.core.send<Booking>('@booking/get_by_id', payload, HttpStatus.OK);

    return response.data;
  }
}
