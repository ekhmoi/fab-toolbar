import { ReviewType } from '../review';

export const CATEGORY_MODEL_NAME = 'Category';
export interface Category {
  id: string;
  key: string;
  icon?: string;
  iconSource?: string;
  color?: string;
  banner?: string;
  reviewableAttributes: ReviewType[];
  minPlayers?: number;
  maxPlayers?: number;
  hidden: boolean;
  createdAt: string;
  updatedAt: string;
}
