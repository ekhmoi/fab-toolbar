export enum ReviewType {
  Speed = 'speed',
  Catch = 'catch',
  Hit = 'hit',
  User = 'user',
  Shooting = 'shot',
  Passing = 'pass',
  TeamPlayer = 'teamPlayer',
  Aggression = 'aggression',
}
