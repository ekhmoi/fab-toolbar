import { Booking } from '../booking';
import { TimeOfDay } from './event.enums';

export class GetEventsVm {
  lat: number;
  maxDistance: number;
  lng: number;
  bookedOnly?: boolean;
  categories?: string;
  createdBy?: string;
  player?: string;
  statuses?: string;
  date?: string;
  sortBy?: string;
  sortDirection?: number;
  joined?: boolean;
}

// tslint:disable-next-line: max-classes-per-file
export class CreateEventVm {
  anyoneCanAcceptRequest?: boolean;
  anyoneCanModifyGroup?: boolean;
  approveNewUsers?: boolean;
  minUsers?: number;
  maxUsers?: number;
  category: string;
  price?: number;
  currency?: string;
  date: Date;
  title: string;
  startTime: Date;
  endTime: Date;
  booked: boolean;
  arenaId?: string;
  location: {
    name: string;
    address: string;
    coordinates: [number, number];
  };
  banner?: string;
  description?: string;
  preferredTimesOfTheDay?: TimeOfDay[];
  booking?: Partial<Booking>
}
