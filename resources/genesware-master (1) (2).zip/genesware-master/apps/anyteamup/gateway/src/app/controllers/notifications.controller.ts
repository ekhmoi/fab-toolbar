import { CoreMsService, NotificationService, PopulatorService } from '@genesware/shared/nestjs-sdk';
import { Body, Controller, Delete, Get, HttpStatus, Param, Post, Put, Query, Request, UseGuards } from '@nestjs/common';

import { Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { AuthRequest } from '../models/common';
import { Notification, NotificationStatus } from '../models/notification';
import { UserRole } from '../models/user';
import { ArenasController } from './arenas.controller';
import { BookingsController } from './bookings.controller';
import { EventsController } from './events.controller';
import { GroupsController } from './groups.controller';

@Controller('notifications')
export class NotificationsController {
  constructor(
    private core: CoreMsService,
    private populator: PopulatorService,
    private notificationService: NotificationService
  ) {}

  @Get(':id')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async getById(@Request() req: AuthRequest, @Param('id') id: string) {
    const payload = { id, populate: true };
    const { data: notification } = await this.core.send<Notification>(
      '@notification/get_by_id',
      payload,
      HttpStatus.OK
    );
    let controller: GroupsController | EventsController | ArenasController | BookingsController;
    switch (notification.relatedDocumentModelName) {
      case 'group':
        controller = new GroupsController(this.core);
        break;

      case 'event':
        controller = new EventsController(this.core, this.notificationService);
        break;

      case 'arena':
        controller = new ArenasController(this.core, this.notificationService);
        break;

      case 'booking':
        controller = new BookingsController(this.core);
        break;

      default:
        console.warn('[NOT_IMPLEMENTED] ', notification.relatedDocumentModelName);
        break;
    }
    notification['relatedDocument'] = await controller.getById(req, notification.relatedDocumentId);
    return notification;
  }

  @Get()
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async get(@Request() { user }: AuthRequest, @Query('status') status: NotificationStatus = NotificationStatus.Read) {
    const payload = { userId: user.id, status, populate: true };
    const response = await this.core.send<Notification[]>('@notification/get_by_userId', payload, HttpStatus.OK);

    // Group notifications by "relatedDocumentModelName" property
    // This will be used to fetch details of each relatedDocument from specific ms
    const groupedByMicroservices: {
      [key: string]: Notification[];
    } = response.data.reduce(
      (group, notification) => ({
        ...group,
        [notification.relatedDocumentModelName]: group[notification.relatedDocumentModelName]
          ? [...group[notification.relatedDocumentModelName], notification]
          : [notification],
      }),
      {}
    );

    const msPrefixes = Object.keys(groupedByMicroservices);

    for (const msPrefix of msPrefixes) {
      groupedByMicroservices[msPrefix] = await this.populator.populateMany(
        groupedByMicroservices[msPrefix],
        'relatedDocumentId',
        true,
        msPrefix,
        'relatedDocument'
      );
    }

    // Convert object to array
    return Object.values(groupedByMicroservices).reduce((arr, n) => [...arr, ...n], []);
  }

  @Put(':id/status')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async updateStatus(
    @Request() { user }: AuthRequest,
    @Param('id') id: string,
    @Body() { status }: { status: NotificationStatus }
  ) {
    const payload = { ids: [id], userId: user.id, status };
    const response = await this.core.send('@notification/update_status', payload, HttpStatus.ACCEPTED);

    return response.data;
  }

  @Post('device-token')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async registerDeviceToken(@Body() { token, device }: { token: string; device: string }, @Request() { user }: any) {
    const payload = { userId: user.id, token, device };
    const response = await this.core.send('@notification/register_device_token', payload, HttpStatus.ACCEPTED);

    return response.data;
  }

  @Delete('device-token/:id')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async removeDeviceToken(@Param() id: string, @Request() { user }: any) {
    const response = await this.core.send(
      '@notification/remove_device_token',
      { id, userId: user.id },
      HttpStatus.NO_CONTENT
    );
    return response.data;
  }

  /**
   * Update notification only supports setting isReceived flag to true at the moment.
   * @param param0
   * @param id
   * @param param2
   * @returns
   */
  @Put(':id')
  @Roles(UserRole.Admin, UserRole.User, UserRole.Manager)
  @UseGuards(JwtGuard, RolesGuard)
  async updateNotification(
    @Request() { user }: AuthRequest,
    @Param('id') id: string,
    @Body() updateBody: Partial<Notification>
  ) {
    if (updateBody.isReceived) {
      const payload = { ids: [id], userId: user.id };
      const response = await this.core.send('@notification/mark_as_received', payload, HttpStatus.ACCEPTED);

      return response.data;
    }
  }
}
