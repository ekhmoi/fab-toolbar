import { CoreMsService, NotificationService } from '@genesware/shared/nestjs-sdk';
import {
  Body,
  Controller,
  ForbiddenException,
  Get,
  HttpStatus,
  Logger,
  Param,
  Post,
  Put,
  Query,
  Request,
  UseGuards,
} from '@nestjs/common';

import { Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { Arena, SearchArenasParams } from '../models/arena';
import { Booking, BookingPlace } from '../models/booking';
import { AuthRequest } from '../models/common';
import { Company } from '../models/company';
import { UserRole } from '../models/user';
import { EventsController } from './events.controller';

const DEFAULT_BOOKING_OPTIONS = [
  { duration: 15, timeUnit: 'minute' },
  { duration: 30, timeUnit: 'minute' },
  { duration: 45, timeUnit: 'minute' },
  { duration: 60, timeUnit: 'minute' },
  { duration: 75, timeUnit: 'minute' },
  { duration: 90, timeUnit: 'minute' },
  { duration: 105, timeUnit: 'minute' },
  { duration: 120, timeUnit: 'minute' },
];

const logger = new Logger('EventController');

@Controller('arenas')
export class ArenasController {
  categoryMap = new Map<string, any>();

  constructor(private core: CoreMsService, private notificationService: NotificationService) {
    this.loadCategories();
  }

  async loadCategories() {
    const { data: categories } = await this.core.send<any[]>('@category/get_all', {}, HttpStatus.OK).catch((err) => {
      console.error('OMG', err);
      return { data: [] };
    });

    if (categories && categories.length) {
      categories.forEach((cat) => {
        this.categoryMap.set(cat.key, cat);
      });
    }
  }

  @Post()
  @Roles(UserRole.User, UserRole.Manager, UserRole.Admin)
  @UseGuards(JwtGuard, RolesGuard)
  async create(@Request() { user }: AuthRequest, @Body() params: Arena) {
    const { data: arena } = await this.core.send<Arena>(
      '@arena/create',
      { ...params, createdBy: user.id },
      HttpStatus.CREATED
    );

    try {
      // Create booking place for this arena in booking microservice
      const createBookingPlaceResponse = await this.core.send(
        '@booking/create_booking_place',
        {
          name: arena.name,
          createdBy: arena.createdBy,
          serviceProviderId: arena.companyId,
          linkedDocumentId: arena.id,
        },
        HttpStatus.CREATED
      );
      const bookingPlace: { id?: string } = createBookingPlaceResponse.data;

      // Create boking options for this category
      const category = this.categoryMap.get(arena.category);
      const bookingOptions = (category?.data?.bookingOptions || DEFAULT_BOOKING_OPTIONS).map(
        ({ duration, timeUnit }) => ({
          placeId: bookingPlace.id,
          name: `${duration}${timeUnit}`,
          duration,
          timeUnit,
          createdBy: arena.createdBy,
        })
      );
      // Or use default
      await this.core.send('@booking/create_booking_options', bookingOptions, HttpStatus.CREATED);
    } catch (err) {
      console.log('Could not create booking place or options for arena', arena, err);
    }
    return arena;
  }

  @Get()
  async get(@Query() queryParams: SearchArenasParams) {
    const response = await this.core.send<Arena[]>('@arena/search', queryParams, HttpStatus.OK);

    return response.data;
  }

  @Get(':id')
  async getById(@Request() req: AuthRequest, @Param('id') id: string): Promise<Arena> {
    const payload = { id, populate: true };
    const response = await this.core.send<Arena>('@arena/get_by_id', payload, HttpStatus.OK);

    return response.data;
  }

  @Get(':id/events')
  async getArenaEvents(@Param('id') id: string) {
    const payload = { params: { arena: id }, populate: true };
    const response = await this.core.send<Arena[]>('@event/search', payload, HttpStatus.OK);

    return response.data;
  }

  @Post(':id/events')
  @Roles(UserRole.User, UserRole.Manager, UserRole.Admin)
  @UseGuards(JwtGuard, RolesGuard)
  async bookArena(@Request() req: AuthRequest, @Param('id') id: string, @Body() booking: Booking) {
    const arena = await this.getById(req, id);
    const [minUsers, maxUsers] = arena.recommendedUsers || [0, 0];
    const eventController = new EventsController(this.core, this.notificationService);
    return eventController.create(req, {
      minUsers,
      maxUsers,
      booking,
      anyoneCanAcceptRequest: true,
      anyoneCanModifyGroup: true,
      approveNewUsers: false,
      arenaId: arena.id,
      category: arena.category,
      date: booking.bookedFrom,
      startTime: booking.bookedFrom,
      endTime: booking.bookedTo,
      booked: true,
      title: `${arena.category} in ${arena.name}`,
      location: {
        name: arena.name,
        address: arena.location.address,
        coordinates: arena.location.coordinates,
      },
    });
  }

  @Get(':id/bookings')
  @Roles(UserRole.Manager, UserRole.Admin)
  @UseGuards(JwtGuard, RolesGuard)
  async getBookings(
    @Param('id') id: string,
    @Query()
    query: { fromDate: string; toDate: string; arena: string; status: string },
    @Request() { user }: AuthRequest
  ) {
    const bookingPlace = await this.getBookingPlace(id);

    if (bookingPlace.serviceProviderId) {
      // Verify that user has access to view bookings
      const { data: company } = await this.core.send<Company>(
        '@company/get_by_id',
        { id: bookingPlace.serviceProviderId },
        HttpStatus.OK
      );
      const hasAccess = company.users.some(({ id }) => id === user.id);

      if (!hasAccess) {
        throw new ForbiddenException();
      }
    }

    // Get bookings places user
    const filters = {
      status: query.status,
      placeId: bookingPlace.id,
      bookedFrom: {
        $gte: query.fromDate,
        $lt: query.toDate,
      },
    };

    console.log('Getting bookings with filters', filters);
    const { data: bookings } = await this.core.send<Booking[]>(
      '@booking/get_all',
      { filters, populate: true },
      HttpStatus.OK
    );

    return bookings;
  }

  @Get(':id/booking-place')
  async getBookingPlace(@Param('id') id: string) {
    const response = await this.core.send<BookingPlace>(
      '@booking/get_booking_place',
      { linkedDocumentId: id },
      HttpStatus.OK
    );

    return response.data;
  }

  @Get(':id/booking-options')
  async getBookingOptins(@Param('id') id: string) {
    const response = await this.core.send('@booking/get_booking_options', { linkedDocumentId: id }, HttpStatus.OK);

    return response.data;
  }

  @Get(':id/booked-slots')
  async getBookedSlots(@Param('id') id: string) {
    const response = await this.core.send('@booking/get_booked_slots', { linkedDocumentId: id }, HttpStatus.OK);

    return response.data;
  }

  @Put(':id')
  @Roles(UserRole.Admin)
  @UseGuards(JwtGuard, RolesGuard)
  async update(@Body() arena: Arena, @Request() { user }: AuthRequest, @Param('id') id: string) {
    const payload = { id, arena, userId: user.id, populate: true };
    const response = await this.core.send<Arena>('@arena/update', payload, HttpStatus.ACCEPTED);

    return response.data;
  }
}
