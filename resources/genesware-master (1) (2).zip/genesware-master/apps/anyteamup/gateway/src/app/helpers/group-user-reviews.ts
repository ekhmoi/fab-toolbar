import { Review } from '../models/review';

export function groupUserReviews(reviews: Review[] = []) {
  const byType: { [key: string]: Review[] } = {};
  reviews.forEach((review) => {
    byType[review.reviewedType] = [
      ...(byType[review.reviewedType] || []),
      review,
    ];
  });
  return Object.keys(byType).map((key) => ({ key, value: avg(byType[key]) }));
}

function avg(reviews: Review[]) {
  return reviews.reduce((a, b) => a + b.rating, 0) / reviews.length;
}
