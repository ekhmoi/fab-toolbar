import { CoreMsService } from '@genesware/shared/nestjs-sdk';
import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Logger,
  Param,
  Put,
  UseGuards,
} from '@nestjs/common';

import { Roles } from '../decorators';
import { JwtGuard, RolesGuard } from '../guards';
import { Category } from '../models/category';
import { UserRole } from '../models/user';

const logger = new Logger('CategoriesController');

@Controller('categories')
export class CategoriesController {
  constructor(private core: CoreMsService) {}

  @Get()
  async get(): Promise<Category[]> {
    const categoriesResponse = await this.core.send<Category[]>(
      '@category/get_all',
      {},
      HttpStatus.OK
    );
    return categoriesResponse.data;
  }

  @Put(':id')
  @Roles(UserRole.Admin)
  @UseGuards(JwtGuard, RolesGuard)
  async update(@Body() category: Category, @Param('id') id: string) {
    return this.core.send('category_update', { id, category });
  }

  @Delete(':id')
  @Roles(UserRole.Admin)
  @UseGuards(JwtGuard, RolesGuard)
  async delete(@Param('id') id: string) {
    return this.core.send('category_delete_by_id', { id });
  }
}
