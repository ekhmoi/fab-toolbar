import { ReviewType } from './review.enums';

export interface Review {
  id: string;
  reviewer: string;
  reviewedDocumentId: string;
  reviewedForId: string;
  reviewedType: ReviewType;
  message: string;
  rating: number;
}
