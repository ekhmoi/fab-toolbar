import { NotificationStatus, NotificationType } from './notification.enums';

export interface Notification {
  id: string;
  type: NotificationType;
  receiverIds: string[];
  isReceived?: boolean;
  relatedDocumentId: string;
  relatedDocumentModelName: string;
  initiator: string;
  status: NotificationStatus;
}
