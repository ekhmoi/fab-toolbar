import { Logger } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';

import * as requestIp from 'request-ip';
import { AppModule } from './app/app.module';
import { HttpExceptionFilter } from './app/filters/http-exception.filter';

declare const module: any;
const logger = new Logger('Gateway');

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { cors: true });
  const port = +(process.env.PORT || 8101);
  app.enableCors();

  if (module.hot) {
    module.hot.accept();
    module.hot.dispose(() => app.close());
  }
  app.setGlobalPrefix(`${process.env.GATEWAY_PREFIX || ''}api`);
  app.use(requestIp.mw());
  app.useGlobalFilters(new HttpExceptionFilter());
  app.use((_, res, next) => {
    res.header('Access-Control-Expose-Headers', 'x-access-token');
    next();
  });

  await app.listen(port);
  logger.debug(`Gateway running at http://localhost:${port}/`);
}
bootstrap();
