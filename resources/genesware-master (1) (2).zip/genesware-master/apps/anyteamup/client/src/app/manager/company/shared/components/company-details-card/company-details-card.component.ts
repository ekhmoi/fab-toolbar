import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-company-details-card',
  templateUrl: './company-details-card.component.html',
  styleUrls: ['./company-details-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CompanyDetailsCardComponent implements OnInit {
  company$ = new BehaviorSubject({
    avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR90FF-DZZDZ2JFFfR51va45Q3IthG9JFy4QA&usqp=CAU',
    id: '1',
    name: 'Holesovice Sport Centrum',
    categories: ['football', 'basketball'],
    location: {
      coordinates: [0, 0],
      address: 'Holesovice, Bruselska 78',
    },
    createdBy: 'userId',
    arenas: ['Football Stadium', 'Basketball Court', 'Basketball Court 2'],
    schedule: [
      ['monday', new Date(), new Date()],
      ['tuesday', new Date(), new Date()],
      ['wednesday', new Date(), new Date()],
      ['thursday', new Date(), new Date()],
      ['friday', new Date(), new Date()],
    ],
    users: [{ id: 'userId', role: 'creator' }],
  });

  get selectedCompany() {
    return this.selectedCompanyId && (this.companies || []).find((c) => c.id === this.selectedCompanyId);
  }
  selectedCompanyId = '1';
  companies = [this.company$.getValue(), { ...this.company$.getValue(), id: '2', name: 'Zizkov Star' }];
  constructor() {}

  ngOnInit(): void {}
}
