import {
  ChangeDetectionStrategy,
  Component,
  Input,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { PopoverController } from '@ionic/angular';

@Component({
  selector: 'app-info-icon',
  template: `
    <ion-button
      class="info-button"
      fill="clear"
      [size]="size"
      [color]="color"
      (click)="onClick($event)"
    >
      <ion-icon [name]="icon" [size]="iconSize" slot="icon-only"></ion-icon>
    </ion-button>

    <ng-template #popoverContent>
      <ion-card mode="ios" class="popover-container">
        <ion-card-header mode="md">
          <ng-content select="[popover-header]"></ng-content>
        </ion-card-header>
        <ng-content select="[popover-content]"></ng-content>
      </ion-card>
    </ng-template>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [
    `
      .popover-container {
        margin: 0;
      }

      ::ng-deep .my-custom-class {
        --width: 80vw;
      }
      .info-button {
        --padding-start: 0;
        --padding-end: 0;
        --border-radius: 50%;
        width: 28px;
        height: 28px;
        margin: 0;
      }
    `,
  ],
})
export class InfoIconComponent {
  @Input() color!: string;
  @Input() size = 'small';
  @Input() iconSize = 'small';
  @Input() icon = 'help-circle-outline';
  @ViewChild('popoverContent', { static: true }) templateRef!: TemplateRef<any>;

  constructor(public popoverController: PopoverController) {}

  async onClick(ev: any) {
    const popover = await this.popoverController.create({
      component: InfoPopoverComponent,
      componentProps: {
        templateRef: this.templateRef,
      },
      cssClass: 'my-custom-class',
      event: ev,
      translucent: true,
    });
    await popover.present();

    const { role } = await popover.onDidDismiss();
    console.log('onDidDismiss resolved with role', role);
  }
}

@Component({
  selector: 'app-info-popover',
  template: ` <ng-container *ngTemplateOutlet="templateRef"></ng-container> `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [
    `
      ::ng-deep {
      }
    `,
  ],
})
export class InfoPopoverComponent {
  @Input() templateRef: any;
}
