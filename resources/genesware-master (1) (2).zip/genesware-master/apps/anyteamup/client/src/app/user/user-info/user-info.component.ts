import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import {
  AuthQuery,
  Group,
  GroupService,
  RequestQuery,
  RequestService,
  User,
} from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserInfoComponent {
  loggedUser!: User;
  loading = false;
  @Input() user!: User;
  @Input() group?: Group;
  @Input() isUserInPending = false;

  get isCreator() {
    return this.user.id === this.group?.createdBy.id;
  }

  get isLoggedUserCreator() {
    return this.loggedUser && this.loggedUser.id === this.group?.createdBy.id;
  }

  get allowedForGroup() {
    return (
      this.group?.anyoneCanAcceptRequest &&
      this.group?.users.some((user) => this.loggedUser.id === user.id)
    );
  }

  get approveVisible() {
    return (
      this.isUserInPending &&
      this.loggedUser &&
      (this.isLoggedUserCreator || this.allowedForGroup)
    );
  }

  get rejectVisible() {
    return this.approveVisible && this.isLoggedUserCreator;
  }

  get removeVisible() {
    return (
      this.group?.users.some((user) => user.id === this.user.id) &&
      !this.isCreator &&
      this.isLoggedUserCreator
    );
  }

  constructor(
    private modalController: ModalController,
    private groupService: GroupService,
    authQuery: AuthQuery,
    private requestService: RequestService,
    private requestQuery: RequestQuery
  ) {
    this.loggedUser = authQuery.getValue().user;
  }

  dismiss(obj?: any) {
    this.modalController.dismiss(obj);
  }

  getRequestToApprove() {
    return this.requestQuery
      .getAll()
      .find(
        (r) =>
          r.requestedForDocumentId === this.group?.id &&
          r.createdBy.id === this.user.id
      );
  }

  onClickApprove(e: MouseEvent) {
    e.stopPropagation();
    this.loading = true;
    const requestToApprove = this.getRequestToApprove();
    requestToApprove?.id &&
      this.requestService.approve(requestToApprove.id).subscribe({
        next: (obj) => this.dismiss(obj),
        error: () => this.dismiss(),
      });
  }
  onClickReject(e: MouseEvent) {
    e.stopPropagation();
    this.loading = true;
    const requestToReject = this.getRequestToApprove();
    requestToReject?.id &&
      this.requestService.reject(requestToReject.id).subscribe({
        next: (obj) => this.dismiss(obj),
        error: () => this.dismiss(),
      });
  }
  onClickRemove(e: MouseEvent) {
    e.stopPropagation();
    this.loading = true;
    if (this.group?.id) {
      this.groupService.removeUser(this.group.id, this.user.id).subscribe({
        next: (obj) => this.dismiss(obj),
        error: () => this.dismiss(),
      });
    }
  }
}
