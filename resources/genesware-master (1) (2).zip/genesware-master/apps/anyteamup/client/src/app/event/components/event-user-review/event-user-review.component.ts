import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  ViewChild,
} from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import {
  CategoryQuery,
  Event,
  Review,
  ReviewService,
  User,
} from '@genesware/shared/angular-sdk';
import { IonSlides, ModalController, ViewDidEnter } from '@ionic/angular';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { finalize } from 'rxjs/operators';

import { CategoryPipe } from '../../../shared/pipes/category.pipe';

@Component({
  selector: 'app-event-user-review',
  templateUrl: './event-user-review.component.html',
  styleUrls: ['./event-user-review.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'game-event' }],
})
export class EventUserReviewComponent implements ViewDidEnter {
  playersSlideConfig = {
    slidesPerView: 'auto',
    centeredSlides: true,
    spaceBetween: 10,
    grabCursor: true,
    preventInteractionOnTransition: true,
    slideToClickedSlide: true,
    dynamicBullets: true,
  };

  private _event!: Event;
  @Input()
  set event(event: Event) {
    this._event = event;
    this.currentFormGroupName = event.group.users[0].id;
    this.constructForm();
  }

  get event(): Event {
    return this._event;
  }

  @ViewChild('slides', { static: false }) slides!: IonSlides;

  form!: UntypedFormGroup;
  // Id of the player who is being reviewed currently
  currentFormGroupName: string | null = null;
  get currentFormGroup(): UntypedFormGroup | null {
    if (!this.form || !this.currentFormGroupName) {
      return null;
    }
    return this.form.get(this.currentFormGroupName) as UntypedFormGroup;
  }

  constructor(
    private fb: UntypedFormBuilder,
    private cdr: ChangeDetectorRef,
    private modalController: ModalController,
    private categoryQuery: CategoryQuery,
    private reviewService: ReviewService
  ) {}

  ionViewDidEnter() {
    this.slides.update();
  }

  async slideWillChange(ev: any) {
    const index = await ev.target.getActiveIndex();
    this.currentFormGroupName =
      this.event.group.users[
        Math.min(index, this.event.group.users.length - 1)
      ].id;
    this.cdr.detectChanges();
  }

  constructForm() {
    const fields = this.getCategoryFields();

    this.form = this.fb.group(
      this.event.group.users.reduce(
        (prev, current) => ({
          ...prev,
          [current.id]: this.fb.group(fields),
        }),
        {}
      )
    );

    this.cdr.detectChanges();
  }

  getCategoryFields() {
    const category = new CategoryPipe(this.categoryQuery).transform(
      this.event.category
    );
    return category.reviewableAttributes?.reduce((prev, current) => {
      return {
        ...prev,
        [current]: [0],
      };
    }, {} as any);
  }

  dismiss(displayReviewodal = false) {
    this.modalController.dismiss(displayReviewodal);
  }

  submit() {
    const values = this.form.getRawValue();
    const reviewsToSubmit = this.event.group.users
      .map(({ id: playerId }) => {
        const playerFields = values[playerId];
        const playerReviews: Review[] = Object.keys(playerFields).map(
          (key) =>
            ({
              reviewedDocumentId: playerId,
              reviewedForId: this.event.id,
              rating: playerFields[key],
              reviewedType: key,
            } as any)
        );
        return playerReviews.filter((r) => r.rating && r.rating > 0);
      })
      .reduce((prev, curr) => [...prev, ...curr], []);

    this.reviewService
      .sendBulkReview(reviewsToSubmit)
      .pipe(
        finalize(() => {
          this.dismiss();
        })
      )
      .subscribe();
  }

  trackByFn(index: number, { id }: User) {
    return id;
  }
}
