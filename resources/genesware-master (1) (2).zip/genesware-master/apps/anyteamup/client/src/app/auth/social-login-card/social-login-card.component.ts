import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

export type SocialLoginType = 'google' | 'facebook' | 'twitter' | 'github';
@Component({
  selector: 'app-social-login-card',
  templateUrl: './social-login-card.component.html',
  styleUrls: ['./social-login-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SocialLoginCardComponent {
  @Input() title!: string;
  @Output() buttonClick = new EventEmitter<SocialLoginType>();
}
