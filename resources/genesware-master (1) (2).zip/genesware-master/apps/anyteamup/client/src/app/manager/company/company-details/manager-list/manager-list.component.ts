import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';
import { User } from '@genesware/shared/angular-sdk';

import { Company } from '../../state/company.model';

@Component({
  selector: 'app-manager-list',
  templateUrl: './manager-list.component.html',
  styleUrls: ['./manager-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ManagerListComponent {
  @Input() company!: Company;
  @Input() user!: User;
  @Input() managers: User[] = [];
  @Input() loading = false;

  @Output() add = new EventEmitter();
}
