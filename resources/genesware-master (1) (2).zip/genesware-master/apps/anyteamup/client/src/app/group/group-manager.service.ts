import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Share } from '@capacitor/share';
import {
  AuthQuery,
  Group,
  GroupService,
  GroupStore,
} from '@genesware/shared/angular-sdk';
import {
  AlertController,
  ModalController,
  NavController,
  PopoverController,
} from '@ionic/angular';
import { JoinGroupLinkPipe } from './join-group-link.pipe';

@Injectable({
  providedIn: 'root',
})
export class GroupManagerService {
  constructor(
    private alertController: AlertController,
    private modalController: ModalController,
    private popoverController: PopoverController,
    private navController: NavController,
    private authQuery: AuthQuery,
    private service: GroupService,
    private store: GroupStore,
    private router: Router
  ) {}

  share(id: string) {
    const group = this.store.getValue().entities?.[id];

    if (!group) {
      console.error('Group not found by id', id);
      return;
    }

    Share.share({ url: new JoinGroupLinkPipe().transform(group) });
  }

  async openGroupModal(page: any, group?: Group, data: any = {}) {
    const modal = await this.modalController.create({
      component: page,
      componentProps: { group, data },
    });

    modal.present();
  }

  isOwner(creatorId: string) {
    return creatorId === this.authQuery.getValue()?.user?.id;
  }

  async leave(group: Group) {
    // Display alert;
    const header = 'Confirm action';
    const message = 'You are about to leave this group. We need you to confirm';
    const ownerMessage =
      "You are about to Leave and Delete this group. You won't be able to undo this action.";

    const alert = await this.alertController.create({
      header,
      message: this.isOwner(group.createdBy.id) ? ownerMessage : message,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'color-dark',
          handler: () => {},
        },
        {
          text: this.isOwner(group.createdBy.id) ? 'Leave and Delete' : 'Leave',
          cssClass: 'color-danger',
          handler: () => {
            this.navController.back();
            this.store.remove(group.id);
            this.service
              .delete(
                `${group.id}/users/${this.authQuery.getValue()?.user?.id}`,
                { skipWrite: true }
              )
              .subscribe();
          },
        },
      ],
    });

    alert.present();
  }

  async showGroupPopover(component: any, group: Group, ev: MouseEvent) {
    const popover = await this.popoverController.create({
      component,
      event: ev,
      translucent: true,
      showBackdrop: false,
      componentProps: { group },
      cssClass: 'my-custom-class',
    });
    return await popover.present();
  }
}
