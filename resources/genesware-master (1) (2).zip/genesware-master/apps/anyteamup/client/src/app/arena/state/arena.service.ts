import { Injectable } from '@angular/core';
import { NgEntityService } from '@datorama/akita-ng-entity-service';
import { Event, EventStatus, User } from '@genesware/shared/angular-sdk';

import {
  Booking,
  BookingOption,
  BookingPlace,
} from '../../booking/state/booking.model';
import { Arena } from './arena.model';
import { ArenaState, ArenaStore } from './arena.store';

@Injectable({ providedIn: 'root' })
export class ArenaService extends NgEntityService<ArenaState> {
  constructor(protected override store: ArenaStore) {
    super(store, { resourceName: 'arenas' });
  }

  getNearbyArenas(params: {
    lat: number;
    lng: number;
    categories: string;
    sortBy?: string;
    maxDistance?: number;
    date?: string;
  }) {
    return this.get<Arena[]>({
      params: {
        ...params,
        sortBy: 'location',
        maxDistance: params.maxDistance || 5,
        date: params.date || new Date().toJSON(),
      },
    });
  }

  getArenaEvents(id: string) {
    return this.getHttp().get<Event[]>(`${this.api}/${id}/events`, {
      params: { status: EventStatus.Active },
    });
  }

  createArenaEvent(arenaId: string, booking: Partial<Booking>) {
    return this.getHttp().post<Event>(`${this.api}/${arenaId}/events`, booking);
  }

  getBookings(arenaId: string, params: Record<string, string>) {
    return this.getHttp().get<Booking<User>[]>(
      `${this.api}/${arenaId}/bookings`,
      { params }
    );
  }

  getBookedPlace(arenaId: string) {
    return this.getHttp().get<BookingPlace>(
      `${this.api}/${arenaId}/booking-place`
    );
  }

  getBookingOptions(arenaId: string) {
    return this.getHttp().get<BookingOption[]>(
      `${this.api}/${arenaId}/booking-options`
    );
  }

  getBookedSlots(arenaId: string) {
    return this.getHttp().get<Partial<Booking>[]>(
      `${this.api}/${arenaId}/booked-slots`
    );
  }

  setActive(id: string) {
    this.store.setActive(id);
  }
}
