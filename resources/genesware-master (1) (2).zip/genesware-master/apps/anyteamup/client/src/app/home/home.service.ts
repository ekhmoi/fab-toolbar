import { Injectable } from '@angular/core';
import { EventService } from '@genesware/shared/angular-sdk';
import { BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';

export enum HomeViewMode {
  Upcoming = 'upcoming',
  Explore = 'explore',
  Community = 'community',
}

@Injectable()
export class HomeService {
  private _viewMode$ = new BehaviorSubject(HomeViewMode.Explore);
  viewMode$ = this._viewMode$.asObservable();
  get viewMode() {
    return this._viewMode$.getValue();
  }

  constructor(private gameEventService: EventService) {}

  onViewModeChange(viewMode: string): void {
    this._viewMode$.next(viewMode as any);
  }

  loadUpcomingEvents(keepViewMode = false) {
    return this.gameEventService.getUserEvents().pipe(
      tap((events) => {
        if (events.length && !keepViewMode) {
          this._viewMode$.next(HomeViewMode.Upcoming);
        }
      })
    );
  }
}
