import { ID } from '@datorama/akita';

export interface Company {
  id: string;
  name: string;
  approved: boolean;
  logo: string;

  location: {
    address: string;
    coordinates: [number, number];
  };
  contacts: { value: string; type: string }[];

  /**
   * schedule.0 - week of the day
   * schedule.1 - openingTime
   * schedule.2 - closingTime
   */
  schedule: [string, string, string][];
  users: { user: string; role: string }[];
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * A factory function that creates Company
 */
export function createCompany(params: Partial<Company>) {
  return {} as Company;
}
