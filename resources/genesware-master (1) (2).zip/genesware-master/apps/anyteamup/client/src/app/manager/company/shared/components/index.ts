export * from './company-details-card/company-details-card.component';
