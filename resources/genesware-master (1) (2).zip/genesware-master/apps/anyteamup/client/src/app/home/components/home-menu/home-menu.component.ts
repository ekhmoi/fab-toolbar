import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import {
  AuthQuery,
  Category,
  CategoryQuery,
  EventParams,
  EventService,
  UserService,
} from '@genesware/shared/angular-sdk';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { debounceTime, map, tap } from 'rxjs/operators';

import { EVENT_DEFAULT_RADIUS } from '../../../event/event.constants';
import { SettingsService } from '../../../settings/settings.service';

@Component({
  selector: 'app-home-menu',
  templateUrl: './home-menu.component.html',
  styleUrls: ['./home-menu.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'home' }],
})
export class HomeMenuComponent implements OnInit {
  form: UntypedFormGroup;
  selectedCategories$ = this.authQuery
    .selectPreference<string[]>('SELECTED_CATEGORIES')
    .pipe(map((categories) => categories || []));
  categories$ = this.categoryQuery.sortedCategories$;

  constructor(
    private categoryQuery: CategoryQuery,
    private fb: UntypedFormBuilder,
    private settingsService: SettingsService,
    private gameEventService: EventService,
    private userService: UserService,
    private authQuery: AuthQuery
  ) {
    this.form = this.fb.group({
      categories: [[], []],
      maxDistance: [EVENT_DEFAULT_RADIUS],
      bookedOnly: [false],
      date: [new Date()],
      sortBy: ['date'],
      sortDirection: [1],
    });
  }

  onCategoryClick([category, state]: [Category, boolean]) {
    this.settingsService.toggleCategory(category, state).subscribe();
  }

  ngOnInit() {
    this.authQuery
      .selectPreference<EventParams>('EVENT_PARAMS')
      .pipe(
        tap((params) => {
          Object.entries(params).forEach(([key, param]) => {
            const control = this.form.get(key);
            if (control && control.value !== param) {
              control.setValue(param);
            }
          });
        })
      )
      .subscribe();
    this.form.valueChanges
      .pipe(debounceTime(300))
      .subscribe(({ maxDistance, bookedOnly, date, sortBy, sortDirection }) => {
        this.gameEventService.setParams({
          maxDistance,
          bookedOnly,
          date,
          sortBy,
          sortDirection,
        });
        this.userService
          .upsertPreferences([
            {
              name: 'EVENT_PARAMS',
              value: JSON.stringify({ maxDistance, sortBy }),
            } as any,
          ])
          .subscribe();
      });
  }
}
