import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  NgZone,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { Arena } from '../../../../arena/state/arena.model';
import { ArenaService } from '../../../../arena/state/arena.service';
import { UserService } from '../../../../core/services/user.service';
import { MapComponent } from '../../../../shared/map';
import { CreateEventService } from '../../create-event.service';

@Component({
  selector: 'app-create-event-arena',
  template: `
    <app-map
      [coords]="coords"
      [markers]="arenas"
      [outputMarkerClicks]="true"
      [markCenter]="!arenaSelected"
      (markerClick)="onMarkerClick($event)"
      (placeSelect)="onPlaceSelect($event)"
    ></app-map>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateEventArenaComponent implements OnInit {
  coords: { lat: number; lng: number } = {
    lat: 10,
    lng: 40,
  };

  arenaSelected = false;
  arenas: Arena[] = [];
  arena!: Arena | null;

  get place() {
    return this.map?.place;
  }

  @Output() placeSelect = new EventEmitter<any>();

  @ViewChild(MapComponent) map!: MapComponent;

  constructor(
    private service: CreateEventService,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone,
    private userService: UserService,
    private arenaService: ArenaService
  ) {}

  ngOnInit() {
    this.initUserLocation();
  }

  async initUserLocation() {
    const [lng, lat] =
      this.service.form.get('location')?.value?.coordinates || [];
    if (lng && lat) {
      this.coords = {
        lat,
        lng,
      };
      await this.getNearbyArenas(lat, lng);
      return;
    }

    await this.userService.getCoordinates();
    this.ngZone.run(async () => {
      const position = this.userService.getCachedCoordinates();
      this.coords = position ? position : { lat: 0, lng: 0 };
      if (this.coords.lat && this.coords.lng) {
        await this.getNearbyArenas(this.coords.lat, this.coords.lng);
      }
      this.cdr.detectChanges();
    });
  }

  async getNearbyArenas(lat: number, lng: number) {
    const category = this.service.form.get('category')?.value;
    this.arenas = await firstValueFrom(
      this.arenaService.getNearbyArenas({
        lat,
        lng,
        categories: category,
        maxDistance: 30,
      })
    );
  }

  onPlaceSelect(place: any) {
    this.arenaSelected = false;
    this.arena = null;
    this.placeSelect.emit(place);
  }

  onMarkerClick(arena: Arena) {
    this.arenaSelected = true;
    this.arena = arena;
  }

  setPlace() {
    this.ngZone.run(() => {
      let placeDetails!: any;
      if (this.arenaSelected && this.arena) {
        placeDetails = {
          lng: this.arena.location.coordinates[0],
          lat: this.arena.location.coordinates[1],
          name: this.arena.name,
          address: this.arena.location.address,
        };
        this.service.form.patchValue({ arenaId: this.arena.id });
      } else {
        placeDetails = this.map.getPlace();
      }

      this.service.setPlace(placeDetails);
      this.cdr.detectChanges();
    });
  }
}
