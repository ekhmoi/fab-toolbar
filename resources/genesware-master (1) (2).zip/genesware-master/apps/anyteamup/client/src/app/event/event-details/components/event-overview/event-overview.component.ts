import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import {
  Event,
  EventStatus,
  Request,
  User,
} from '@genesware/shared/angular-sdk';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

@Component({
  selector: 'app-event-overview',
  templateUrl: './event-overview.component.html',
  styleUrls: ['./event-overview.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'game-event' }],
})
export class EventOverviewComponent {
  @Input() event!: Event;
  @Input() user!: User;
  @Input() hasPendingRequest!: boolean;
  @Input() joined!: boolean;
  @Input() requests!: Request[];

  @Output() joinClick = new EventEmitter();
  @Output() statusChange = new EventEmitter<EventStatus>();

  get validToJoin() {
    return this.event && this.event.status === EventStatus.Active;
  }
}
