import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';

import { SharedModule } from '../../shared/shared.module';
import { UserModule } from '../../user/user.module';
import { ChatComponent } from './chat.component';
import { StartConversationModalComponent } from './start-conversation-modal/start-conversation-modal.component';

@NgModule({
  declarations: [ChatComponent, StartConversationModalComponent],
  imports: [
    CommonModule,
    SharedModule,
    FlexLayoutModule,
    UserModule,
    MatBottomSheetModule,
  ],
  exports: [
    StartConversationModalComponent,
    MatBottomSheetModule,
    ChatComponent,
  ],
})
export class ChatModule {}
