import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { AuthQuery, User } from '@genesware/shared/angular-sdk';
import { BehaviorSubject, combineLatest } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserProfileComponent {
  @Input() title!: string;
  user$ = new BehaviorSubject<User | null>(null);
  currentUser$ = combineLatest([this.authQuery.user$, this.user$]).pipe(
    map(([loggedUser, user]) => user || loggedUser)
  );

  @Input()
  public set user(user: User) {
    this.user$.next(user);
  }
  @Input() fullMode = false;

  constructor(private authQuery: AuthQuery) {}
}
