import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import { TOAST_DURATION } from '../../core/constants';
import {
  CategoryQuery,
  Event,
  EventService,
  UserService,
} from '@genesware/shared/angular-sdk';
import { CreateEventService } from './create-event.service';
import {
  ModalController,
  Platform,
  ToastController,
  ViewDidEnter,
  ViewWillLeave,
} from '@ionic/angular';
import { translate } from '@ngneat/transloco';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { CreateEventContentComponent } from './components';

type EventFormValue = Partial<Event> & {
  playerCount: { lower: number; upper: number };
};
@Component({
  selector: 'app-create-event',
  template: `
    <app-create-event-content
      [categories]="$any(categories$ | async)"
      [step]="$any(step$ | async)"
      [loading]="loading"
      (dismiss)="dismiss($event)"
      (create)="createEvent()"
    ></app-create-event-content>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [CreateEventService],
})
export class CreateEventPage implements ViewDidEnter, ViewWillLeave, OnInit {
  step$ = this.service.step$;
  categories$ = this.categoryQuery.selectAll();
  userCategories: string[] = [];

  private _backButtonSubscription!: Subscription;

  loading = false;

  @ViewChild(CreateEventContentComponent) content!: CreateEventContentComponent;

  constructor(
    public service: CreateEventService,
    private userService: UserService,
    private modalCtrl: ModalController,
    private toast: ToastController,
    private eventService: EventService,
    private categoryQuery: CategoryQuery,
    private platform: Platform,
    private cdr: ChangeDetectorRef
  ) {
    this.service.createForm();
    this.service.resetSubmittedSteps();
  }

  ngOnInit() {
    this.userCategories =
      this.userService.getUserPreference('SELECTED_CATEGORIES') || [];
  }

  dismiss(data?: any) {
    this.modalCtrl.dismiss(data);
  }

  async createEvent() {
    const event: EventFormValue = this.service.form.getRawValue();
    event.date = moment(event.date, 'DD-MM-YYYY').toISOString() as any;
    // event.minUsers = event.playerCount.lower;
    // event.maxUsers = event.playerCount.upper;
    const loader = this.presentLoading();
    this.eventService
      .add(event as any)
      .pipe(
        finalize(async () => {
          loader.dismiss();
        })
      )
      .subscribe({
        next: async (createdEvent) => {
          const toast = await this.toast.create({
            message: translate('gameEvent.createEvent.success.message'),
            header: translate('gameEvent.createEvent.success.header'),
            duration: TOAST_DURATION,
            mode: 'ios',
            position: 'top',
            color: 'light',
          });
          await toast.present();
          this.dismiss(createdEvent);
        },
      });
  }

  ionViewDidEnter() {
    this._backButtonSubscription =
      this.platform.backButton.subscribeWithPriority(9999, () => void 0);
    this.content.ionViewDidEnter();
  }

  ionViewWillLeave() {
    this._backButtonSubscription.unsubscribe();
  }

  presentLoading() {
    this.loading = true;
    this.cdr.detectChanges();
    return {
      dismiss: () => {
        this.loading = false;
        this.cdr.detectChanges();
      },
    };
  }
}
