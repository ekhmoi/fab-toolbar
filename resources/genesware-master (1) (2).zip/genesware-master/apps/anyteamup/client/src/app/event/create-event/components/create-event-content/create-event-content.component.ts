import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { Category } from '@genesware/shared/angular-sdk';
import { IonContent, ViewDidEnter } from '@ionic/angular';

import { Arena } from '../../../../arena/state/arena.model';
import { CreateBookingComponent } from '../../../../booking/create-booking/create-booking.component';
import { slideInOut } from '../../../../shared/animations';
import { CreateEventService } from '../../create-event.service';
import { CreateEventArenaComponent } from '../create-event-arena/create-event-arena.component';
import { CreateEventDetailsComponent } from '../create-event-details/create-event-details.component';

@Component({
  selector: 'app-create-event-content',
  templateUrl: './create-event-content.component.html',
  styleUrls: ['./create-event-content.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [slideInOut()],
})
export class CreateEventContentComponent implements ViewDidEnter {
  @Input() loading = false;
  @Input() categories: Category[] = [];
  @Input() formGroup!: UntypedFormGroup;
  private _step = 1;
  @Input() set step(step: number) {
    if (step !== 1 || this._step === 2) {
      this._step = step;
      this.content.scrollToTop();
    }
  }
  get step() {
    return this._step;
  }

  @Output() dismiss = new EventEmitter<void>();
  @Output() create = new EventEmitter<void>();

  @ViewChild(IonContent) content!: IonContent;
  @ViewChild(CreateBookingComponent, { static: false })
  createBooking!: CreateBookingComponent;
  @ViewChild('arenaDetails', { static: false })
  arenaDetails!: CreateEventArenaComponent;
  @ViewChild('createEventDetails', { static: false })
  eventDetailsComponent!: CreateEventDetailsComponent;
  @ViewChild('horizontalPages', { static: false }) horizontalPages: any;

  selectedArena!: Arena;
  stepTitles: Map<number, string> = new Map<number, string>([
    [1, 'gameEvent.createEvent.step.newGame'],
    [2, 'gameEvent.createEvent.step.location'],
    [3, 'gameEvent.createEvent.step.date'],
    [4, 'gameEvent.createEvent.step.details'],
  ]);
  iconByStep = ['', 'arrow-forward', 'checkmark', 'checkmark'];
  submitted = false;

  get nextDisabled() {
    if (this.step < 3) {
      return this.arenaDetails && !this.arenaDetails.place;
    } else if (this.selectedArena && this.createBooking) {
      return this.createBooking.form.invalid;
    } else {
      const { startTime, booked, endTime, date } = this.service.form.controls;
      return booked.value ? startTime.invalid || endTime.invalid : date.invalid;
    }
  }

  constructor(
    private cdr: ChangeDetectorRef,
    public readonly service: CreateEventService
  ) {}

  ionViewDidEnter() {
    setTimeout(() => {
      this.eventDetailsComponent.focus();
    });
  }

  scrollToBottom() {
    this.content.scrollToBottom(300);
  }

  onPlaceSelect() {
    this.cdr.detectChanges();
  }

  onNext() {
    this.submitted = true;
    const { title: titleControl, category: categoryControl } =
      this.service.form.controls;
    switch (this.service.step$.getValue()) {
      case 1:
        if (titleControl.valid && categoryControl.valid) {
          this.service.goNext(2);
        }
        break;
      case 2:
        this.arenaDetails.setPlace();

        if (this.arenaDetails.arenaSelected) {
          this.selectedArena = this.arenaDetails.arena as Arena;
          // Arena selected, lets choose booking
          this.service.form.patchValue(
            { arenaId: this.selectedArena.id },
            { emitEvent: false }
          );
        }
        this.service.goNext(3);
        break;

      case 3:
        if (this.selectedArena && this.createBooking.form.valid) {
          this.service.setBooking(this.createBooking.value);
        }
        this.create.emit();
        break;
    }
  }
}
