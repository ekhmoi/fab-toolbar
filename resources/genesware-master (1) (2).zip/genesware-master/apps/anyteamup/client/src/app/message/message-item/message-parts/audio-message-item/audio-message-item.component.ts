import { Component, Input } from '@angular/core';
import { Message, MessagePartType, User } from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-audio-message',
  templateUrl: './audio-message-item.component.html',
  styleUrls: ['./audio-message-item.component.scss'],
})
export class AudioMessageItemComponent {
  @Input() message!: Message;
  @Input() groupUsers!: Map<string, User>;
  @Input() part!: {
    type: MessagePartType;
    message: string;
    payload?: { assetId: string };
  };
  @Input() displaySender!: boolean;
}
