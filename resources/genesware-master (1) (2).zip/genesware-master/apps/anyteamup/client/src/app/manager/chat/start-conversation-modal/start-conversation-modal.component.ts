import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Inject,
  ViewChild,
} from '@angular/core';
import {
  MatBottomSheetRef,
  MAT_BOTTOM_SHEET_DATA,
} from '@angular/material/bottom-sheet';
import { User } from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-start-conversation-modal',
  templateUrl: './start-conversation-modal.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [
    `
      ion-content {
        height: 200px;
      }
    `,
  ],
})
export class StartConversationModalComponent {
  message = '';
  minMessageLength = 3;

  constructor(
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: { user: User },
    private bottomSheetRef: MatBottomSheetRef
  ) {}

  @ViewChild('textArea') textArea!: ElementRef;

  sendMessage() {
    console.log('Send message', this.message);
    this.dismiss(this.message);
  }

  dismiss(val: any = null) {
    this.bottomSheetRef.dismiss(val);
  }
}
