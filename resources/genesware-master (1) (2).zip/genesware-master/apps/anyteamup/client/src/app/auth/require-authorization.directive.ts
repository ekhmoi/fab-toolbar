import {
  Directive,
  EventEmitter,
  HostListener,
  Input,
  Output,
} from '@angular/core';
import { AuthQuery } from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';

import { AuthDialogComponent } from './auth-dialog/auth-dialog.component';

@Directive({
  selector: '[requireAuth]',
})
export class RequireAuthorizationDirective {
  @Output() authClick = new EventEmitter<void>();
  @Input() requireAuth!: string;
  private _sub!: Subscription;

  constructor(
    private authQuery: AuthQuery,
    private modalController: ModalController
  ) {}

  @HostListener('click', ['$event']) onClick(event: MouseEvent) {
    event.preventDefault();
    this._sub = this.authQuery.isLoggedIn$
      .pipe(take(1))
      .subscribe((isLoggedIn) => {
        if (isLoggedIn) {
          this.authClick.emit();
        } else {
          this._requireAuthorization();
        }
      });
  }

  async _requireAuthorization() {
    const modal = await this.modalController.create({
      component: AuthDialogComponent,
      mode: 'md',
      componentProps: {
        isInModal: true,
      },
    });

    modal.onDidDismiss().then((data) => {
      if (this._sub && this._sub.unsubscribe) {
        this._sub.unsubscribe();
      }
      if (data.data) {
        this.authClick.emit(data.data);
      }
    });
    modal.present();
  }

  ngOnDestroy() {
    if (this._sub && this._sub.unsubscribe) {
      this._sub.unsubscribe();
    }
  }
}
