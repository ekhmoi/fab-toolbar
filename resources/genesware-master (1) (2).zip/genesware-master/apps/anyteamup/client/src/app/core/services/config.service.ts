import { Injectable } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { BehaviorSubject } from 'rxjs';
import {
  AuthService,
  CategoryService,
  EventParams,
  EventService,
  User,
  UserPreference,
  UserService,
} from '@genesware/shared/angular-sdk';

import { DEFAULT_LANGUAGE } from '../../models/language.enum';
import { SettingsService } from '../../settings/settings.service';
import { STORAGE_KEYS } from '../constants';

@Injectable({
  providedIn: 'root',
})
export class ConfigService {
  appStarted$ = new BehaviorSubject(false);
  constructor(
    private authService: AuthService,
    private gameEventService: EventService,
    private categoryService: CategoryService,
    private userService: UserService,
    private settingsService: SettingsService,
    private transloco: TranslocoService
  ) {}

  setInit(init: boolean) {
    this.appStarted$.next(init);
  }

  async init() {
    return new Promise(async (resolve) => {
      const token =
        sessionStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) ||
        localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      await this.categoryService.get().toPromise();
      const preferDarkMode = this.isDarkModePreferred();
      if (preferDarkMode) {
        // FIXME: Ass any
        this.userService.upsertPreferences([
          {
            name: 'UI_THEME',
            value: JSON.stringify({ selected: 'dark' }),
          } as any,
        ]);
      }
      if (token) {
        const user: User = JSON.parse(
          localStorage.getItem(STORAGE_KEYS.USER) || '{}'
        );
        const loggedUser = await this.authService
          .loginStoredUser(token, user)
          .toPromise();
        this.applyUserPreferences(loggedUser?.preferences);
      }
      const params = this.userService.getUserPreference('EVENT_PARAMS');
      this.gameEventService.setParams(new EventParams(params as any), true);
      resolve(true);
    });
  }

  applyUserPreferences(preferences: UserPreference[]) {
    if (preferences && preferences.length) {
      this.userService.upsertPreferences(preferences);
      const languagePreference: any =
        this.userService.getUserPreference('USER_LANGUAGE');
      const themePreference: any =
        this.userService.getUserPreference('UI_THEME');
      this.transloco.setDefaultLang(
        languagePreference?.selected || DEFAULT_LANGUAGE
      );
      this.transloco.setActiveLang(
        languagePreference?.selected || DEFAULT_LANGUAGE
      );
      if (themePreference?.selected) {
        this.settingsService.setTheme(themePreference.selected as any);
      }
    }
  }

  isDarkModePreferred() {
    return (
      window.matchMedia &&
      window.matchMedia('(prefers-color-scheme: dark)').matches
    );
  }
}

export function configFactory(config: ConfigService) {
  return () => config.init();
}
