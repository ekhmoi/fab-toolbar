import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class MapService {
  map!: google.maps.Map;

  geocode(lat: number, lng: number) {
    return new Observable<{
      lat: number;
      lng: number;
      name: string;
      address: string;
      icon?: string;
    } | null>((observer) => {
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ location: { lat, lng } }, (results, status) => {
        if (status === 'OK') {
          if (results?.[0]) {
            new google.maps.places.PlacesService(this.map).getDetails(
              { placeId: results[0].place_id },
              (place) => {
                const address = this.extractAddressFromPlace(place);
                observer.next({
                  name: place?.name as string,
                  address,
                  icon: place?.icon,
                  lat,
                  lng,
                });
                observer.complete();
              }
            );
          } else {
            observer.next(null);
            observer.complete();
          }
        } else {
          observer.error({ results, status });
          observer.complete();
        }
      });
    });
  }

  extractAddressFromPlace(place: any): string {
    if (place.address_components) {
      return [
        (place.address_components[0] &&
          place.address_components[0].short_name) ||
          '',
        (place.address_components[1] &&
          place.address_components[1].short_name) ||
          '',
        (place.address_components[2] &&
          place.address_components[2].short_name) ||
          '',
      ].join(' ');
    }
    return '';
  }
}
