import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { User } from '@genesware/shared/angular-sdk';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import * as moment from 'moment';

import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'auth' }],
})
export class RegisterFormComponent {
  today = moment().format('YYYY-MM-DD');
  minimumHeight = 130;
  minimumWeight = 35;
  form: UntypedFormGroup;

  @Input() editMode = false;
  @Input()
  public set user(user: User) {
    if (user) {
      this._patchForm(user);
    }
  }

  constructor(fb: UntypedFormBuilder) {
    this.form = fb.group({
      email: [null, [Validators.email]],
      password: [null, [Validators.minLength(6)]],
      profile: fb.group({
        firstName: [
          environment.production ? '' : 'Manager',
          [Validators.required],
        ],
        lastName: ['', []],
        avatar: [null, []],
        speaks: [[], []],
        dob: [null, []],
        weight: [null],
        height: [null],
        gender: [null],
        about: [],
      }),
    });
  }

  get value(): User {
    return this._getFormValueParsed();
  }

  get valid() {
    return this.form.valid;
  }

  get weightControl() {
    return this.form.get('profile')?.get('weight');
  }
  get heightControl() {
    return this.form.get('profile')?.get('height');
  }

  private _patchForm(user: User) {
    this.form.patchValue({ ...user });
  }

  private _getFormValueParsed() {
    const val = this.form.getRawValue();
    Object.keys(val.profile).forEach((key) => {
      if (val.profile[key] === null) {
        delete val.profile[key];
      }
    });
    return val;
  }
}
