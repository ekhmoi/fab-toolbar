export function hidePullToRefresh(event: any) {
  if (event && event.target && typeof event.target.complete === 'function') {
    event.target.complete();
  }
}
