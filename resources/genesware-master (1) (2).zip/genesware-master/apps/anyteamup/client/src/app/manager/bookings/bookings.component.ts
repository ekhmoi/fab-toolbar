import { ScrollDispatcher } from '@angular/cdk/scrolling';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import { User } from '@genesware/shared/angular-sdk';
import { IonContent } from '@ionic/angular';
import * as moment from 'moment';
import { forkJoin } from 'rxjs';
import { filter, switchMap, tap } from 'rxjs/operators';

import { Arena } from '../../arena/state/arena.model';
import { ArenaQuery } from '../../arena/state/arena.query';
import { ArenaService } from '../../arena/state/arena.service';
import { Booking } from '../../booking/state/booking.model';
import { CompanyQuery } from '../company/state/company.query';
import { calcTop } from './booking-card/booking-card.component';

@Component({
  selector: 'app-manager-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ManagerBookingsComponent implements OnInit {
  loading = true;
  bookings: Booking[] = [];
  arenas$ = this.arenaQuery.items$;
  times: Date[] = [];
  bookingsByArenaId = new Map<string, Booking<User>[]>([]);

  minDate = new Date();
  private _date = new Date();
  set date(date: Date) {
    this._date = date;
    this.loadBookings([...this.bookingsByArenaId.keys()], date).subscribe(
      () => {
        this.cdr.detectChanges();
      }
    );
  }
  get date(): Date {
    return this._date;
  }
  @ViewChild('scrollTwo') scrollTwo: any;

  now = new Date();
  get currentTimeTop() {
    return calcTop(this.now) + 7;
  }
  @ViewChild(IonContent) content!: IonContent;
  @ViewChild('currentTime') currentTime!: ElementRef;
  constructor(
    private arenaQuery: ArenaQuery,
    private arenaService: ArenaService,
    private cdr: ChangeDetectorRef,
    private companyQuery: CompanyQuery,
    private scrollDispatcher: ScrollDispatcher
  ) {
    const start = new Date();
    start.setHours(0);
    start.setMinutes(0);

    for (let i = 0; i <= 24; i++) {
      this.times.push(new Date(start.getTime() + i * 60 * 60 * 1000));
    }
  }

  ngOnInit(): void {
    this.arenaService
      .get<Arena[]>({ params: { companyId: this.companyQuery.getActiveId() } })
      .pipe(
        filter((arenas) => !!arenas.length),
        tap((arenas) => this.arenaService.setActive(arenas[0].id)),
        switchMap((arenas) =>
          this.loadBookings(
            arenas.map(({ id }) => id),
            this.date
          )
        )
      )
      .subscribe(() => {
        const rect = this.currentTime.nativeElement.getBoundingClientRect();
        this.content.scrollToPoint(0, rect.y - window.innerHeight / 2);
        this.loading = false;
        this.cdr.detectChanges();
      });

    this.scrollDispatcher.scrolled().subscribe((scrollable) => {
      if (!scrollable) {
        return;
      }

      if (typeof scrollable === 'undefined') {
        return true;
      }
      const left = scrollable.measureScrollOffset('left');

      Array.from(this.scrollDispatcher.scrollContainers.keys())
        .filter(
          (otherScrollable) => otherScrollable && otherScrollable !== scrollable
        )
        .forEach((otherScrollable) => {
          if (otherScrollable.measureScrollOffset('left') !== left) {
            otherScrollable.scrollTo({ left });
          }
        });
    });
  }

  loadBookings(arenaIds: string[], date: Date) {
    const fromDate = new Date(this.date.getTime());
    const toDate = new Date(this.date.getTime());
    fromDate.setDate(this.date.getDate() - 1);
    toDate.setDate(this.date.getDate() + 1);

    return forkJoin(
      arenaIds.map((arenaIds) =>
        this.arenaService
          .getBookings(arenaIds, {
            fromDate: fromDate.toJSON(),
            toDate: toDate.toJSON(),
          })
          .pipe(
            tap((bookings) =>
              this.bookingsByArenaId.set(
                arenaIds,
                bookings.filter((booking) =>
                  moment(booking.bookedFrom).isSame(moment(this.date), 'day')
                )
              )
            )
          )
      )
    );
  }
}
