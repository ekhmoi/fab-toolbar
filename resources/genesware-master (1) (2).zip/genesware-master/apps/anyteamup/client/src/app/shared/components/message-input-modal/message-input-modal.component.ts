import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Inject,
  ViewChild,
} from '@angular/core';
import {
  MatBottomSheet,
  MatBottomSheetRef,
  MAT_BOTTOM_SHEET_DATA,
} from '@angular/material/bottom-sheet';
import { User } from '@genesware/shared/angular-sdk';

export interface MessageInputModalData {
  user?: User;
  title?: string;
  titleParams?: any;
  rows?: number;
  showUserInHeader?: boolean;
  placeholder?: string;
  description?: string;
  buttonColor?: string;
  buttonIcon?: string;
  buttonText?: string;
}

@Component({
  selector: 'app-message-input-modal',
  template: `
    <ion-header class="ion-no-border" mode="md">
      <ion-toolbar *ngIf="data.showUserInHeader">
        <ion-buttons slot="start" *ngIf="data.user?.profile?.avatar">
          <ion-button>
            <app-avatar
              [size]="30"
              [avatar]="data.user?.profile?.avatar || ''"
            ></app-avatar>
          </ion-button>
        </ion-buttons>
        <ion-title *ngIf="data.user?.profile">
          {{ data.user?.profile?.firstName }}
          {{ data.user?.profile?.lastName }}
        </ion-title>
        <ion-buttons slot="end">
          <ion-button (click)="dismiss()">
            <ion-icon name="close"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
      <ion-toolbar *ngIf="!data?.showUserInHeader && data.title">
        <ion-title>
          {{ data.title | transloco: data.titleParams }}
        </ion-title>
        <ion-buttons slot="end">
          <ion-button (click)="dismiss()">
            <ion-icon name="close"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content>
      <ion-card mode="ios">
        <ion-card-content mode="md" *ngIf="data.description">
          {{ data.description }}
        </ion-card-content>
        <ion-item mode="md" lines="none">
          <ion-textarea
            [rows]="data.rows || 6"
            [placeholder]="data.placeholder"
            [(ngModel)]="message"
          ></ion-textarea>
        </ion-item>
      </ion-card>
    </ion-content>

    <ion-footer
      mode="ios"
      slot="fixed"
      [translucent]="true"
      class="ion-no-border"
    >
      <ion-toolbar mode="md">
        <div fxLayout="row" fxLayoutAlign="center center">
          <ion-button
            shape="round"
            [color]="data.buttonColor"
            (click)="sendMessage()"
            class="no-text-transform"
            [disabled]="message.length < minMessageLength"
          >
            {{ data.buttonText }}
            <ion-icon [name]="data.buttonIcon" slot="end"></ion-icon>
          </ion-button>
        </div>
      </ion-toolbar>
    </ion-footer>
  `,
  styles: [
    `
      ion-content {
        height: 200px;
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MessageInputModalComponent {
  message = '';
  minMessageLength = 3;

  @ViewChild('textArea') textArea!: ElementRef;

  constructor(
    @Inject(MAT_BOTTOM_SHEET_DATA)
    public data: MessageInputModalData,
    private bottomSheetRef: MatBottomSheetRef
  ) {}

  public static async open(
    matViewProvider: MatBottomSheet,
    data: MessageInputModalData,
    onSuccess: (message?: string) => void,
    onCancel?: () => void
  ) {
    const bottomSheetRef = matViewProvider.open(MessageInputModalComponent, {
      data,
      panelClass: 'start-conversation-modal',
    });
    const result = await bottomSheetRef.afterDismissed().toPromise();
    console.log(data);
    if (result && typeof onSuccess === 'function') {
      onSuccess(result);
    } else if (!result && typeof onCancel === 'function') {
      onCancel();
    }
  }

  sendMessage() {
    this.dismiss(this.message);
  }

  dismiss(val: any = null) {
    this.bottomSheetRef.dismiss(val);
  }
}
