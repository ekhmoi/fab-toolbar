import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Review, User } from '@genesware/shared/angular-sdk';

import { Company } from '../../state/company.model';

@Component({
  selector: 'app-review-list',
  templateUrl: './review-list.component.html',
  styleUrls: ['./review-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReviewListComponent {
  @Input() company!: Company;
  @Input() user!: User;
  @Input() reviews: Review[] = [];
  @Input() loading = false;
}
