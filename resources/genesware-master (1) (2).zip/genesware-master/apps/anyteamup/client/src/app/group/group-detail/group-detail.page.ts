import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { filterNilValue } from '@datorama/akita';
import {
  AuthQuery,
  Group,
  GroupQuery,
  GroupService,
  MessageService,
  User,
} from '@genesware/shared/angular-sdk';
import { IonContent } from '@ionic/angular';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { Observable } from 'rxjs';
import { startWith, switchMap, tap } from 'rxjs/operators';

import { GroupManagerService } from '../group-manager.service';
import { GroupOptionsComponent } from '../group-options/group-options.component';
import { GroupSettingsPage } from '../group-settings/group-settings.page';

@Component({
  selector: 'app-group-detail',
  templateUrl: './group-detail.page.html',
  styleUrls: ['./group-detail.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  viewProviders: [{ provide: TRANSLOCO_SCOPE, useValue: 'group' }],
})
export class GroupDetailPage implements OnInit {
  // Id of the player to display after opening settings
  scrolled = false;
  pendingPlayer: string | null = null;
  group$: Observable<Group> = this.query.active$.pipe(
    filterNilValue(),
    tap((group) => {
      if (this.firstTime) {
        this.firstTime = false;
        if (this.pendingPlayer) {
          this.manager.openGroupModal(GroupSettingsPage);
        }
      }
    })
  ) as any;
  firstTime = true;
  activeId!: string;
  loggedUser!: User;
  groupRequests$ = this.group$.pipe(
    switchMap(({ id }) => this.query.selectGroupRequests(id)),
    startWith([])
  );

  @ViewChild(IonContent) content!: IonContent;

  constructor(
    private query: GroupQuery,
    public service: GroupService,
    private authQuery: AuthQuery,
    public manager: GroupManagerService,
    private route: ActivatedRoute,
    private messageService: MessageService
  ) {}

  onApproveToggle(val: boolean) {
    this.service.updateProperty(this.activeId, 'approveNewUsers', !val);
  }

  ngOnInit() {
    const { paramMap } = this.route.snapshot;
    this.activeId = (this.query.getActiveId() as any) || paramMap.get('id');
    this.service.setActive(this.activeId);
    this.pendingPlayer = paramMap.get('pendingPlayer') || null;
    this.loggedUser = this.authQuery.getValue().user;
  }

  onClickEnable() {
    this.firstTime = false;
    this.service.createLink(this.activeId).subscribe();
  }

  openSettings(group: Group) {
    this.manager.openGroupModal(GroupSettingsPage);
  }

  showOptions(ev: any) {
    this.manager.showGroupPopover(
      GroupOptionsComponent,
      this.query.getActive() as Group,
      ev
    );
  }

  sendMessage(message: string) {
    this.messageService.sendMessage(
      message,
      this.query.getActiveId() as string
    );
  }

  onNewMessage() {
    if (!this.content) {
      setTimeout(() => {
        this.onNewMessage();
      }, 20);
      return;
    }

    let scrollDuration = 100;
    if (!this.scrolled) {
      scrollDuration = 0;
      this.scrolled = true;
    }
    setTimeout(() => {
      this.content.scrollToBottom(scrollDuration);
    }, 100);
  }

  onTextAreaFocus() {
    setTimeout(() => {
      this.content.scrollToBottom(100);
    }, 300);
  }
}
