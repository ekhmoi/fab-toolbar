import {
  Directive,
  ElementRef,
  Input,
  TemplateRef,
  ViewContainerRef,
  OnInit,
} from '@angular/core';

import { User, UserRole, AuthQuery } from '@genesware/shared/angular-sdk';
@Directive({
  selector: '[hasRole]',
})
export class HasRoleDirective implements OnInit {
  private user!: User;
  private role!: UserRole;
  @Input()
  set hasRole(role: UserRole | string) {
    this.role = role as UserRole;
    this.updateView();
  }

  constructor(
    private authQuery: AuthQuery,
    private element: ElementRef,
    private template: TemplateRef<any>,
    private viewContainer: ViewContainerRef
  ) {}

  ngOnInit() {
    this.authQuery.user$.subscribe((user) => {
      this.user = user;
      this.updateView();
    });
  }

  private updateView() {
    if (this.checkRole()) {
      this.viewContainer.createEmbeddedView(this.template);
    } else {
      this.viewContainer.clear();
    }
  }

  private checkRole() {
    return this.user && this.user.role === this.role;
  }
}
