import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { Category } from '@genesware/shared/angular-sdk';
import { IonInput } from '@ionic/angular';

import { CreateEventService } from '../../create-event.service';

@Component({
  selector: 'app-create-event-details',
  templateUrl: './create-event-details.component.html',
  styleUrls: ['./create-event-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateEventDetailsComponent {
  @Input() categories: Category[] = [];
  @Input() submitted = false;
  @Output() categorySelect = new EventEmitter<Category>();

  @ViewChild('title') title!: IonInput;

  constructor(public service: CreateEventService) {}

  focus() {
    this.title.setFocus();
  }

  onCategorySelect([cat, state]: [Category, boolean]) {
    if (!state) {
      return;
    }

    this.service.form.patchValue({
      category: cat.key,
      minUsers: cat.minUsers,
      maxUsers: cat.maxUsers,
    });
    this.service.onCategorySelect(cat);

    // Emit categorySelect event in next change dectection
    // This will give time for the user count selecter to render properly
    setTimeout(() => {
      //
      this.categorySelect.emit(cat);
    }, 1);
  }
}
