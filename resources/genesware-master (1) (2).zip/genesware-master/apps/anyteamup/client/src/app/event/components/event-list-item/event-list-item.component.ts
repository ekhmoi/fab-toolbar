import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Event } from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-event-list-item',
  templateUrl: './event-list-item.component.html',
  styleUrls: ['./event-list-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventListItemComponent {
  @Input() event!: Event;
  @Input() compact = false;
  @Input() showDate = true;
}
