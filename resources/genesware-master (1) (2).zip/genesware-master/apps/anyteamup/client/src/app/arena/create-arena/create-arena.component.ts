import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  OnInit,
  ViewChild,
} from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { Category, CategoryQuery } from '@genesware/shared/angular-sdk';
import { IonInput, ModalController } from '@ionic/angular';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { UserService } from '../../core/services';
import { slideInOut } from '../../shared/animations';
import { MapComponent } from '../../shared/map';
import { ArenaService } from '../state/arena.service';

@Component({
  selector: 'app-create-arena',
  templateUrl: './create-arena.component.html',
  styles: [
    `
      ::ng-deep .footer-background {
        display: none;
      }
    `,
  ],
  animations: [slideInOut()],
  changeDetection: ChangeDetectionStrategy.OnPush,

  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'arena' }],
})
export class CreateArenaComponent implements OnInit {
  @Input() companyId!: string;
  @Input() location!: {
    coordinates: [number, number];
    country?: string;
    city?: string;
    zip?: string;
    address?: string;
  };

  step = 0;
  form = this.fb.group({
    name: ['', Validators.required],
    category: [null, Validators.required],
    images: [[]],
    companyId: [null],
    location: this.fb.group({
      coordinates: [[0, 0]],
      country: [],
      city: [],
      zip: [],
      address: [],
    }),
  });
  submitted = false;
  placeSelected = false;
  place: any;
  coords: { lat: number; lng: number } | null = { lat: 0, lng: 0 };
  categories$ = this.categoryQuery.selectAll();

  @ViewChild(MapComponent) map!: MapComponent;
  @ViewChild('name') nameInput!: IonInput;

  constructor(
    private fb: UntypedFormBuilder,
    private modal: ModalController,
    private userService: UserService,
    private cdr: ChangeDetectorRef,
    private categoryQuery: CategoryQuery,
    private service: ArenaService
  ) {}

  get arenaDetails(): any {
    return { place: this.place };
  }

  ngOnInit() {
    if (!this.location) {
      this.initUserLocation();
    }
  }

  ionViewDidEnter() {
    setTimeout(() => {
      this.nameInput.setFocus();
    });
  }

  async initUserLocation() {
    this.coords = await this.userService.getCoordinates();
    this.cdr.detectChanges();
  }

  dismiss() {
    this.modal.dismiss();
  }

  onCreate() {
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }
    const formValue = this.form.getRawValue();
    this.service
      .add({
        ...formValue,
        location: this.location || formValue.location,
        companyId: this.companyId,
      })
      .subscribe(
        (arena) => this.modal.dismiss(arena),
        () => this.modal.dismiss()
      );
  }

  onCategoryClick(cat: [Category, boolean]) {
    this.form.get('category')?.setValue(cat[0].key);
    if (this.location) {
      this.onCreate();
    } else {
      this.step = 1;
    }
  }

  setPlace(place: any) {
    this.place = place;
    this.form.patchValue({
      name: this.form.value.name || place.name,
      location: {
        coordinates: [place.lng, place.lat],
        address: place.address,
      },
    });
    this.placeSelected = !!this.place;
    this.cdr.detectChanges();
  }

  onClickNext() {
    this.place = this.map.getPlace();
    this.step = 1;
  }
}
