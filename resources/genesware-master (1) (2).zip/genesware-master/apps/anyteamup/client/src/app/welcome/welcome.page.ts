import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import { IonSlides, ModalController } from '@ionic/angular';
import { TranslocoService, TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { UserService } from '../core/services';
import { UserPreferencesSetupModalComponent } from '../user/user-preferences-setup-modal/user-preferences-setup-modal.component';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.page.html',
  styleUrls: ['./welcome.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'welcome' }],
})
export class WelcomePage implements OnInit {
  slideOpts = {
    initialSlide: 0,
    speed: 400,
  };
  @ViewChild('slidesRef', { static: false }) slidesRef!: IonSlides;
  isLast = false;
  slidesLength = 0;
  slides = [0, 1, 2];

  constructor(
    private router: Router,
    private userService: UserService,
    private transloco: TranslocoService,
    private modalController: ModalController,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.userService.setParam('WELCOME_PRESENTED', true);
  }

  onClickNext() {
    this.slidesRef.slideNext();
  }

  async onNextEnd() {
    const index = await this.slidesRef.getActiveIndex();
    this.isLast =
      index === this.transloco.translateObject('welcome.slides').length - 1;
    this.cdr.detectChanges();
  }

  async onSkip() {
    const modal = await this.modalController.create({
      component: UserPreferencesSetupModalComponent,
      mode: 'md',
      componentProps: {
        isInModal: true,
      },
    });
    modal.present();

    await modal.onWillDismiss();
    this.goToHome();
  }

  goToHome() {
    setTimeout(() => {
      this.router.navigate(['/tabs']);
    }, 100);
  }
}
