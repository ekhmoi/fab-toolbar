import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { BookingModule } from '../../booking/booking.module';
import { MapModule } from '../../shared/map';
import { SharedModule } from '../../shared/shared.module';
import {
  CreateEventArenaComponent,
  CreateEventContentComponent,
  CreateEventDatetimeComponent,
  CreateEventDetailsComponent,
} from './components';
import { CreateEventPage } from './create-event.page';

const routes: Routes = [
  {
    path: '',
    component: CreateEventPage,
  },
];

@NgModule({
  declarations: [
    CreateEventPage,
    CreateEventContentComponent,
    CreateEventArenaComponent,
    CreateEventDatetimeComponent,
    CreateEventDetailsComponent,
  ],
  exports: [CreateEventPage],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, MapModule, BookingModule],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'game-event' }],
})
export class CreateEventModule {}
