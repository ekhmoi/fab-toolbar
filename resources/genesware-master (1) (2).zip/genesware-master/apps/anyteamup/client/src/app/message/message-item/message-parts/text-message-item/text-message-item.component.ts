import { Component, Input } from '@angular/core';
import {
  AuthQuery,
  Message,
  MessagePartType,
  User,
} from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-text-message',
  templateUrl: './text-message-item.component.html',
  styleUrls: ['./text-message-item.component.scss'],
})
export class TextMessageItemComponent {
  @Input() message!: Message;
  @Input() groupUsers!: Map<string, User>;
  @Input() part!: { type: MessagePartType; message: string; payload?: any };
  @Input() displaySender!: boolean;

  user$ = this.authQuery.user$;

  constructor(private authQuery: AuthQuery) {}
}
