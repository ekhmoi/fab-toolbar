import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexModule } from '@angular/flex-layout';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { AuthModule } from '../auth/auth.module';
import { SharedModule } from '../shared/shared.module';
import { UserModule } from '../user/user.module';
import { AboutCardComponent } from './about-card/about-card.component';
import { ApplicationSettingsComponent } from './application-settings/application-settings.component';
import { ChangePasswordPage } from './change-password/change-password.page';
import { EditProfilePage } from './edit-profile/edit-profile.page';
import { ProfileManagementComponent } from './profile-management/profile-management.component';
import { SettingsPage } from './settings.page';

const routes: Routes = [
  {
    path: '',
    component: SettingsPage,
  },
  { path: 'change-password', component: ChangePasswordPage },
  { path: 'edit-profile', component: EditProfilePage },
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes),
    FlexModule,
    SharedModule,
    TranslocoModule,
    AuthModule,
    UserModule,
  ],
  declarations: [
    SettingsPage,
    ChangePasswordPage,
    AboutCardComponent,
    ApplicationSettingsComponent,
    ProfileManagementComponent,
    EditProfilePage,
  ],
  exports: [SettingsPage],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'settings' }],
})
export class SettingsModule {}
