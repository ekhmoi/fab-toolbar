import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Arena } from './arena.model';

export interface ArenaState extends EntityState<Arena> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'arena' })
export class ArenaStore extends EntityStore<ArenaState> {

  constructor() {
    super();
  }

}
