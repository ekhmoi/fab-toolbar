import { Component, EventEmitter, Input, Output } from '@angular/core';
import { User } from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-player-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss'],
})
export class UsersListComponent {
  @Input() playerId!: string;
  @Input() players: User[] = [];
  @Input() isPending = false;
  @Input() title!: string;
  @Input() createdById!: string;

  @Output() playerClick = new EventEmitter<User>();

  trackByFn(index: number, { id }: User) {
    return id;
  }
}
