import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  AuthQuery,
  GroupQuery,
  NotificationQuery,
  UserRole,
} from '@genesware/shared/angular-sdk';
import { IonFab, IonTabs } from '@ionic/angular';
import { map } from 'rxjs/operators';

enum TabMode {
  Chat = 'chat',
  Company = 'company',
  Notifications = 'notification',
  Settings = 'settings',
}

@Component({
  selector: 'app-manager-tabs',
  templateUrl: 'manager-tabs.page.html',
  styleUrls: ['manager-tabs.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ManagerTabsPage implements OnInit {
  isOnSettingsTab = false;
  inited = false;
  isLoggedIn$ = this.authQuery.isLoggedIn$;
  currentTab: TabMode = TabMode.Company;
  groupsCount$ = this.groupQuery.count$;
  unreadGroupsCount$ = this.groupQuery.groups$.pipe(
    map((groups) => groups.filter((group) => group.hasUnread).length)
  );
  hasUnreadGroup$ = this.groupQuery.hasUnreadGroup$;
  notificationsCount$ = this.notificationQuery.unreadCount$;
  @ViewChild(IonTabs) tabs!: IonTabs;
  @ViewChild(IonFab) fab!: IonFab;

  userRole!: string;

  constructor(
    private authQuery: AuthQuery,
    private groupQuery: GroupQuery,
    private notificationQuery: NotificationQuery,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.authQuery.user$.subscribe((user) => {
      this.userRole = user?.role || UserRole.User;
      this.cdr.detectChanges();
    });
  }

  tabChange({ tab }: { tab: string }) {
    this.currentTab = tab as TabMode;
    this.isOnSettingsTab = tab === 'settings';
    // close fab if it is opened
    this.fab?.close();
  }
}
