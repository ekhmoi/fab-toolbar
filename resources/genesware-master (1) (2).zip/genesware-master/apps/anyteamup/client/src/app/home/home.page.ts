import { ChangeDetectionStrategy, Component, ViewChild } from '@angular/core';
import {
  AuthQuery,
  EventQuery,
  EventStatus,
  GroupQuery,
} from '@genesware/shared/angular-sdk';
import { ModalController, ViewWillEnter } from '@ionic/angular';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { finalize, map } from 'rxjs/operators';

import { CreateEventPage } from '../event/create-event/create-event.page';
import { ExplorePage } from './explore/explore.page';
import { HomeService, HomeViewMode } from './home.service';
import { UserGamesPage } from './user-games.page';

@Component({
  selector: 'app-home',
  template: `
    <ion-header no-border mode="md" [translucent]="true">
      <ion-toolbar>
        <ion-buttons slot="end">
          <ion-button
            ><ion-icon slot="icon-only" name="" color="danger"></ion-icon>
          </ion-button>
        </ion-buttons>

        <app-card-segment
          [value]="service.viewMode"
          [items]="['upcoming', 'explore']"
          translocoRoot="home.viewMode"
          (change)="service.onViewModeChange($event)"
        ></app-card-segment>

        <ion-buttons slot="start">
          <ion-menu-button autoHide="false">
            <mat-icon>tune</mat-icon>
          </ion-menu-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content class="page" fullscreen>
      <div [ngSwitch]="service.viewMode$ | async">
        <app-explore *ngSwitchCase="'explore'"></app-explore>
        <app-user-games *ngSwitchCase="'upcoming'"></app-user-games>
      </div>
    </ion-content>
  `,
  styles: [
    `
      ion-header ion-card {
        margin-inline: 0px;
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [HomeService],
})
export class HomePage implements ViewWillEnter {
  loaded$ = new BehaviorSubject(false);
  isLoggedIn$ = this.authQuery.isLoggedIn$;
  groupCount$ = this.groupQuery.count$;
  today = moment();

  userEventsCount$ = this.gameEventQuery.userEvents$.pipe(
    map(
      (events) =>
        events.filter(
          (event) =>
            moment(event.date).isAfter(this.today) &&
            [
              EventStatus.Active,
              EventStatus.Confirmed,
              EventStatus.PendingUpdate,
            ].includes(event.status)
        ).length
    )
  );

  @ViewChild(ExplorePage) explore!: ExplorePage;
  @ViewChild(UserGamesPage) upcoming!: UserGamesPage;

  constructor(
    public service: HomeService,
    private groupQuery: GroupQuery,
    private authQuery: AuthQuery,
    private gameEventQuery: EventQuery,
    private modalController: ModalController
  ) {}

  ionViewWillEnter() {
    this.service
      .loadUpcomingEvents(this.loaded$.getValue())
      .pipe(
        finalize(() => {
          this.loaded$.next(true);
        })
      )
      .subscribe();
  }

  async onClickCreateEvent() {
    const modal = await this.modalController.create({
      component: CreateEventPage,
      mode: 'md',
      componentProps: {
        isInModal: true,
      },
    });
    return await modal.present();
  }

  onRefresh(event: any) {
    switch (this.service.viewMode) {
      case HomeViewMode.Explore:
        this.explore.onRefresh(event);
        break;
      case HomeViewMode.Upcoming:
        this.upcoming.onRefresh();
        break;
    }
  }
}
