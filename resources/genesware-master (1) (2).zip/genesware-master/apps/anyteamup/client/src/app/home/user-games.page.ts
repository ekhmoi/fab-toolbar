import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
} from '@angular/core';
import { hidePullToRefresh } from '../core/helpers';
import {
  AuthQuery,
  Event,
  EventQuery,
  EventService,
  EventStatus,
} from '@genesware/shared/angular-sdk';
import { EventDetailsPage } from '../event/event-details/event-details.page';
import { ModalController } from '@ionic/angular';
import { finalize, map } from 'rxjs/operators';
import * as moment from 'moment';
import { CreateEventPage } from '../event/create-event/create-event.page';
import { HomeService } from './home.service';

@Component({
  selector: 'app-user-games',
  template: `
    <ion-refresher slot="fixed" (ionRefresh)="onRefresh($event)">
      <ion-refresher-content></ion-refresher-content>
    </ion-refresher>
    <ng-container *ngIf="isLoggedIn$ | async; else notLoggedIn">
      <ng-container *ngIf="previousActiveEvents$ | async as previousEvents">
        <app-previous-events-list
          [items]="previousEvents"
          [description]="'home.previousEvents.description' | transloco"
          [title]="'home.previousEvents.description' | transloco"
          (eventClick)="onClickEvent($event)"
          (yesClick)="setStatusToFinished($event)"
          (noClick)="setStatusToCanceled($event)"
        ></app-previous-events-list>
      </ng-container>
      <ng-container *ngIf="userEvents$ | async as events">
        <app-event-list
          *ngIf="events && events.length; else noUpcomingEvents"
          [events]="events"
          [loading]="loading"
          title="home.upcoming.title"
          (eventClick)="onClickEvent($event)"
        >
        </app-event-list>
      </ng-container>
    </ng-container>

    <ng-template #notLoggedIn>
      <app-empty-page
        translocoRoot="home.upcoming.user"
        img="/assets/images/secure.svg"
        [loading]="loading"
        [messageVisible]="false"
        (actionClick)="loginPopupTrigger.click()"
      >
        <span #loginPopupTrigger requireAuth (authClick)="onRefresh()"></span>
      </app-empty-page>
    </ng-template>

    <ng-template #noUpcomingEvents>
      <app-empty-page
        translocoRoot="home.upcoming"
        img="/assets/images/calendar.svg"
        [loading]="loading"
        (actionClick)="$event === 1 ? goToExplore() : createNewEvent()"
      >
        <span #loginPopupTrigger requireAuth (authClick)="onRefresh()"></span>
      </app-empty-page>
    </ng-template>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserGamesPage {
  today = moment();

  previousActiveEvents$ = this.gameEventQuery.userEvents$.pipe(
    map((events) =>
      events.filter(
        (event) =>
          event.isCreator &&
          moment(event.date).isBefore(this.today) &&
          [EventStatus.Active].includes(event.status)
      )
    )
  );
  userEvents$ = this.gameEventQuery.userEvents$.pipe(
    map((events) =>
      events.filter(
        (event) =>
          moment(event.date).isAfter(this.today) &&
          [
            EventStatus.Active,
            EventStatus.Confirmed,
            EventStatus.PendingUpdate,
          ].includes(event.status)
      )
    )
  );
  loading = false;
  isLoggedIn$ = this.authQuery.isLoggedIn$;

  constructor(
    private homeService: HomeService,
    private gameEventService: EventService,
    private gameEventQuery: EventQuery,
    private modalController: ModalController,
    private cdr: ChangeDetectorRef,
    private authQuery: AuthQuery
  ) {}

  setStatusToFinished(event: Event) {
    this.gameEventService
      .updateStatus(event.id, EventStatus.Finished)
      .subscribe();
  }

  setStatusToCanceled(event: Event) {
    this.gameEventService
      .updateStatus(event.id, EventStatus.Canceled)
      .subscribe();
  }

  async onClickEvent(event: Event) {
    this.gameEventService.setActive(event.id);
    const modal = await this.modalController.create({
      component: EventDetailsPage,
      mode: 'md',
      componentProps: {
        isInModal: true,
      },
    });
    modal.present();
  }

  async onRefresh(event?: any) {
    // this.loading = true;
    this.gameEventService
      .getUserEvents()
      .pipe(
        finalize(() => {
          // this.loading = false;
          hidePullToRefresh(event);
          this.cdr.detectChanges();
        })
      )
      .subscribe();
  }

  async onNoItemActionClick(click: any) {
    console.log(click);
  }

  goToExplore() {
    this.homeService.onViewModeChange('explore');
  }

  async createNewEvent() {
    const modal = await this.modalController.create({
      component: CreateEventPage,
      mode: 'md',
      componentProps: {
        isInModal: true,
      },
    });
    const { data } = await modal.onDidDismiss();
    if (data) {
      this.gameEventService.setActive(data.id);
      const modal = await this.modalController.create({
        component: EventDetailsPage,
        mode: 'md',
        componentProps: {
          isInModal: true,
        },
      });
      modal.present();
    }
    return await modal.present();
  }
}
