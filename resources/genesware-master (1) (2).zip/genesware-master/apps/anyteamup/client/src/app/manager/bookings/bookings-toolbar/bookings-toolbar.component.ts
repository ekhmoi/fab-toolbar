import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookings-toolbar',
  templateUrl: './bookings-toolbar.component.html',
  styleUrls: ['./bookings-toolbar.component.css']
})
export class BookingsToolbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
