import { ChangeDetectionStrategy, Component } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Observable } from 'rxjs';

import { CreateArenaComponent } from '../../arena/create-arena/create-arena.component';
import { ArenaQuery } from '../../arena/state/arena.query';
import { Company } from '../company/state/company.model';
import { CompanyQuery } from '../company/state/company.query';

@Component({
  selector: 'app-manager-arenas',
  templateUrl: './arenas.component.html',
  styleUrls: ['./arenas.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ManagerArenasComponent {
  companies$ = this.companyQuery.companies$;
  activeCompany$ = this.companyQuery.selectActive() as Observable<Company>;
  arenas$ = this.arenaQuery.items$;

  constructor(
    private arenaQuery: ArenaQuery,
    private companyQuery: CompanyQuery,
    private modalController: ModalController
  ) {}

  async addArena() {
    const modal = await this.modalController.create({
      component: CreateArenaComponent,
      cssClass: 'my-custom-class',
      componentProps: {
        companyId: this.companyQuery.getActiveId(),
      },
    });
    await modal.present();
  }
}
