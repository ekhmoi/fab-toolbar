import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  AuthQuery,
  GroupQuery,
  GroupService,
} from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';
import { finalize } from 'rxjs/operators';

import { hidePullToRefresh } from '../../core/helpers';
import { CreateGroupPage } from '../create-group/create-group.page';

@Component({
  selector: 'app-group-home',
  templateUrl: './group-home.page.html',
  styleUrls: ['./group-home.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GroupHomePage implements OnInit {
  userGroups$ = this.groupQuery.groups$;
  loading$ = this.groupQuery.selectLoading();
  currentUser$ = this.authQuery.user$;
  constructor(
    private groupQuery: GroupQuery,
    private groupService: GroupService,
    private modalController: ModalController,
    private authQuery: AuthQuery,
    private router: Router
  ) {}

  ngOnInit() {
    this.onRefresh();
  }

  onRefresh(event?: any) {
    this.groupService
      .get({ upsert: false })
      .pipe(
        finalize(() => {
          hidePullToRefresh(event);
        })
      )
      .subscribe();
  }

  async onClickNew() {
    const modal = await this.modalController.create({
      component: CreateGroupPage,
    });

    const { data } = await modal.onDidDismiss();
    if (data) {
      this.onRefresh();
      this.groupService.setActive(data.id);
      this.router.navigate(['/group', 'details', data.id], {
        queryParams: { firstTime: true },
      });
    }
    modal.present();
  }

  onNoItemActionClick(action: number) {
    switch (action) {
      case 2:
        this.onClickNew();
        break;

      default:
        break;
    }
  }
}
