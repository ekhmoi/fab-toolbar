import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
} from '@angular/core';
import { Review, User } from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';
import { forkJoin, Observable, of } from 'rxjs';
import { distinctUntilChanged, filter, switchMap, tap } from 'rxjs/operators';

import { CreateArenaComponent } from '../../../arena/create-arena/create-arena.component';
import { ArenaQuery } from '../../../arena/state/arena.query';
import { ArenaService } from '../../../arena/state/arena.service';
import { CreateCompanyComponent } from '../create-company/create-company.component';
import { Company } from '../state/company.model';
import { CompanyQuery } from '../state/company.query';
import { CompanyService } from '../state/company.service';

type ViewMode = 'arenas' | 'reviews' | 'users';

@Component({
  selector: 'app-company-details',
  templateUrl: './company-details.component.html',
  styleUrls: ['./company-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CompanyDetailsComponent implements OnInit {
  reviews!: Review[];
  managers!: User[];
  viewMode: ViewMode = 'arenas';
  viewModes: ViewMode[] = ['arenas', 'reviews', 'users'];
  companies$ = this.companyQuery.companies$;
  activeCompany$ = this.companyQuery.selectActive() as Observable<Company>;
  arenas$ = this.activeCompany$.pipe(
    filter((company) => !!company),
    switchMap((company) => this.arenaQuery.selectByCompanyId(company.id))
  );
  loading = true;

  constructor(
    private arenaService: ArenaService,
    private arenaQuery: ArenaQuery,
    private companyQuery: CompanyQuery,
    private companyService: CompanyService,
    private modalController: ModalController,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.companyQuery
      .selectActiveId()
      .pipe(
        distinctUntilChanged(),
        tap(() => {
          this.loading = true;
          this.cdr.detectChanges();
        }),
        switchMap((id) =>
          forkJoin([
            of(id),
            this.companyService.getReviews(id),
            this.companyService.getManagers(id),
          ])
        )
      )
      .subscribe(([companyId, reviews, managers]) => {
        this.arenaService.get({ companyId }).subscribe();
        this.reviews = reviews;
        this.managers = managers;
        this.loading = false;
        this.cdr.detectChanges();
      });
  }

  switchToCompany(id: string) {
    this.companyService.setActive(id);
  }

  async addCompany() {
    const modal = await this.modalController.create({
      component: CreateCompanyComponent,
      cssClass: 'my-custom-class',
      componentProps: {
        companyId: this.companyQuery.getActiveId(),
      },
    });
    await modal.present();
  }

  async addArena() {
    const modal = await this.modalController.create({
      component: CreateArenaComponent,
      cssClass: 'my-custom-class',
      componentProps: {
        companyId: this.companyQuery.getActiveId(),
        location: (this.companyQuery.getActive() as Company).location,
      },
    });
    await modal.present();
  }

  async addManager() {
    console.warn('[NotImplemented] AddManager');
  }

  onViewModeChange(viewMode: any) {
    this.viewMode = viewMode as ViewMode;
  }
}
