import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule } from '@angular/router';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { SharedModule } from '../../../shared/shared.module';
import { UserModule } from '../../../user/user.module';
import { CreateCompanyModule } from '../create-company/create-company.module';
import { ArenaListComponent } from './arena-list/arena-list.component';
import { CompanyDetailsComponent } from './company-details.component';
import { CompanyInfoComponent } from './company-info/company-info.component';
import { ManagerListComponent } from './manager-list/manager-list.component';
import { ReviewListComponent } from './review-list/review-list.component';

@NgModule({
  declarations: [
    CompanyDetailsComponent,
    ArenaListComponent,
    CompanyInfoComponent,
    ReviewListComponent,
    ManagerListComponent,
  ],
  exports: [CompanyDetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule,
    UserModule,
    CreateCompanyModule,
    FlexLayoutModule,
    UserModule,
  ],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'company' }],
})
export class CompanyDetailsModule {}
