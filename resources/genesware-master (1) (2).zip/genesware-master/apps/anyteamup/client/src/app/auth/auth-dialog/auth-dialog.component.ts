import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  ViewChild,
} from '@angular/core';
import { GoogleAuth } from '@codetrix-studio/capacitor-google-auth';
import {
  AuthService,
  LoginResponse,
  User,
  UserRole,
  UserStatus,
} from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { finalize, switchMap } from 'rxjs/operators';

import { ConfigService } from '../../core/services';
import { CreateCompanyComponent } from '../../manager/company/create-company/create-company.component';
import { UserPreferencesSetupModalComponent } from '../../user/user-preferences-setup-modal/user-preferences-setup-modal.component';
import { LoginFormComponent } from '../login-form/login-form.component';
import { RegisterFormComponent } from '../register-form/register-form.component';
import { SocialLoginType } from '../social-login-card/social-login-card.component';
import { SuccessfulRegistrationDialog } from './successful-registration.dialog';

GoogleAuth.initialize();

@Component({
  selector: 'app-auth-dialog',
  templateUrl: './auth-dialog.component.html',
  styleUrls: ['./auth-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'auth' }],
})
export class AuthDialogComponent {
  @Input() message!: string;
  @Input() isInModal = false;
  @Input() isFromWelcome = false;

  viewMode: 'login' | 'register' = 'login';
  userType = {
    business: 'Manager',
    player: 'User',
  };
  loading = false;
  isResetPassword = false;

  @ViewChild(LoginFormComponent) loginForm!: LoginFormComponent;
  @ViewChild(RegisterFormComponent) registerForm!: RegisterFormComponent;

  constructor(
    private authService: AuthService,
    private modalController: ModalController,
    private cdr: ChangeDetectorRef,
    private configService: ConfigService
  ) {}

  get buttonDisabled() {
    return this.viewMode === 'login'
      ? !this.loginForm?.valid
      : !this.registerForm?.valid;
  }

  async login() {
    if (!this.loginForm.valid) {
      return;
    }
    const loader = this.presentLoading();
    this.authService
      .login(this.loginForm.value)
      .pipe(
        finalize(() => {
          loader.dismiss();
        })
      )
      .subscribe((result) => {
        const { user, token } = result as unknown as LoginResponse;
        this.configService.applyUserPreferences(user?.preferences);
        this.dismiss({ user, token });
      });
  }

  async register(role = this.userType.player) {
    if (!this.registerForm || !this.registerForm.valid) {
      return;
    }

    const loader = this.presentLoading();

    this.authService
      .register({ ...this.registerForm?.value, ...this.loginForm.value, role })
      .pipe(
        switchMap((user) => this.authService.login(this.loginForm.value)),
        finalize(async () => {
          loader.dismiss();
        })
      )
      .subscribe(async (result) => {
        const { user, token } = result as unknown as LoginResponse;
        this.dismiss(user);
        const ModalComponent: any =
          this._getModalToDisplayAfterRegistration(user);
        const modal = await this.modalController.create({
          component: ModalComponent,
          mode: 'md',
          backdropDismiss: false,
          keyboardClose: false,
          swipeToClose: false,
          componentProps: {
            isInModal: true,
            user,
          },
        });
        modal.present();
      });
  }

  toggleForgotPassword() {
    this.isResetPassword = !this.isResetPassword;
  }

  resetPassword() {
    console.warn('[NotImplemented] ResetPassword');
  }

  /**
   * Returns the correct modal component to display after registration
   * It takes into account user.role and user.status
   * @param user
   * @returns ModalComponent
   */
  private _getModalToDisplayAfterRegistration(user: User) {
    switch (user.status) {
      case UserStatus.Active: {
        if (user.role === UserRole.User) {
          return UserPreferencesSetupModalComponent;
        } else {
          return CreateCompanyComponent;
        }
      }
      case UserStatus.PendingActivation: {
        return SuccessfulRegistrationDialog;
      }
      default:
        return SuccessfulRegistrationDialog;
    }
  }

  loginWithSocialProvider(type: SocialLoginType) {
    switch (type) {
      case 'google':
        this.loginWithGoogle();
        break;

      default:
        console.warn(`Social login provider: ${type} is not supported yet.`);
        break;
    }
  }

  async loginWithGoogle() {
    const loader = this.presentLoading();
    const result = await GoogleAuth.signIn().catch((err) => {
      console.error(err);
      return null;
    });
    if (result && result.authentication && result.authentication.idToken) {
      this.authService
        .loginWithGoogle(result.authentication.idToken)
        .pipe(
          finalize(async () => {
            loader.dismiss();
          })
        )
        .subscribe((response) => this.dismiss(response));
    } else {
      loader.dismiss();
      // Could not login. Maybe display some message?
    }
  }

  presentLoading() {
    this.loading = true;
    this.cdr.detectChanges();
    return {
      dismiss: () => {
        this.loading = false;
        this.cdr.detectChanges();
      },
    };
  }

  dismiss(loginResponse: any) {
    this.modalController.dismiss(loginResponse);
  }
}
