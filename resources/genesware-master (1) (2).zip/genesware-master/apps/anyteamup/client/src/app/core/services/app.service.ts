import { Injectable, NgZone } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { App, AppState } from '@capacitor/app';
import { ActionPerformed, PushNotifications, Token } from '@capacitor/push-notifications';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar } from '@capacitor/status-bar';
import {
  AuthQuery,
  GroupService,
  MessageService,
  Notification,
  NotificationService,
  NotificationType,
  RequestService,
  RootQuery,
} from '@genesware/shared/angular-sdk';
import { Platform } from '@ionic/angular';
import { BehaviorSubject, Subscription } from 'rxjs';
import { filter, map, startWith } from 'rxjs/operators';

import { GroupNotificationHandlerService } from '../../group/group-notification-handler.service';
import { CompanyService } from '../../manager/company/state/company.service';

const HOME_ROUTE = '/tabs/home';
const MANAGER_HOME_ROUTE = '/manage/bookings';

const NAVIGATE_TO_EVENT_TYPES = [
  NotificationType.JoinRequest,
  NotificationType.RemovedFromGame,
  NotificationType.JoinEventRequestAccepted,
  NotificationType.RequestReject,
];

const NAVIGATE_TO_GROUP_TYPES = [
  NotificationType.JoinGroupRequestReceived,
  NotificationType.JoinGroupRequestAccepted,
  NotificationType.MessageReceived,
];

@Injectable({
  providedIn: 'root',
})
export class AppService {
  private _eventsSubscription!: Subscription | null;
  started = new BehaviorSubject(false);
  loading$ = this.rootQuery.select('loading');

  /**
   * FIXME: as any
   */
  isOnHomePage$ = (this.router.events as any).pipe(
    filter((ev) => ev instanceof NavigationEnd),
    map(({ url, urlAfterRedirects }: NavigationEnd) => url === HOME_ROUTE || urlAfterRedirects === HOME_ROUTE),
    startWith(true)
  );

  /**
   * FIXME: as any
   */
  isOnManagerHomePage$ = (this.router.events as any).pipe(
    filter((ev) => ev instanceof NavigationEnd),
    map(({ url, urlAfterRedirects }: NavigationEnd) => [url, urlAfterRedirects].includes(MANAGER_HOME_ROUTE)),
    startWith(true)
  );
  constructor(
    private platform: Platform,
    private rootQuery: RootQuery,
    private authQuery: AuthQuery,
    private companyService: CompanyService,
    private router: Router,
    private zone: NgZone,
    private groupService: GroupService,
    private messageService: MessageService,
    private notificationService: NotificationService,
    private requestService: RequestService,
    private groupNotificationHandlerService: GroupNotificationHandlerService
  ) {}

  start() {
    // this.translate.setDefaultLang('en');
    this.platform.ready().then(() => {
      if (this.platform.is('capacitor')) {
        StatusBar.setBackgroundColor({ color: '#121212' });
        // this.statusBar.styleBlackOpaque();
        StatusBar.show();
        this.setupDeeplinks();
        // this.chateor.init();
        App.addListener('appStateChange', ({ isActive }: AppState) => {
          // state.isActive contains the active state
          if (isActive) {
          }
        });

        setTimeout(async () => {
          await SplashScreen.hide();
          this.started.next(true);
        }, 500);
      }
      // Never ubsubscribe. This will trigger the necessary service when user logs in
      this.authQuery.isLoggedIn$.subscribe((isLoggedIn) => {
        if (isLoggedIn) {
          this.getUserData();
        } else {
          this.stopLoggedUserProcesses();
        }
      });
    });
  }

  stopLoggedUserProcesses() {
    // User logged out stopping listening to events
    if (this._eventsSubscription) {
      this._eventsSubscription.unsubscribe();
      this._eventsSubscription = null;
    }
  }

  getUserData() {
    const { token, user } = this.authQuery.getValue();

    this.requestNotificationPermission();

    // User logged in, we can load groups
    this.groupService.get().toPromise();

    if ((user.role as any) === 'Manager') {
      this.companyService.get({ setDefault: true }).toPromise();
    }

    // And initialize messages and notifications
    this.notificationService.init(token);
    this.messageService.init(token);
    this.requestService.get().toPromise();
    this.groupNotificationHandlerService.subscribeToNotifications();
  }

  setupDeeplinks() {
    App.addListener('appUrlOpen', ({ url }: any) => {
      // data.url contains the url that is opening your app

      // nomatch.$link - the full link data
      if (!url) {
        return;
      }
      const { pathname } = new URL(url);
      const [action, id, token] = pathname.split('/').filter((v) => v);

      if (action === 'join') {
        const internalPath = `/event/details/${id}`; // Run the navigation in the Angular zone
        this.zone.run(() => {
          this.router.navigateByUrl(internalPath);
        });
      } else if (action === 'join-group') {
        // this.groupService.handleDeepLink({ action, id, token });
      }
    });
  }

  registerDeviceToken(token: string) {
    this.notificationService
      .getHttp()
      .post(`${this.notificationService.api}/device-token`, {
        token,
        device: 'android',
      })
      .subscribe(
        (result) => {},
        (err) => {}
      );
  }

  requestNotificationPermission() {
    if (!this.platform.is('capacitor')) {
      return;
    }
    PushNotifications.requestPermissions().then((result) => {
      if (result.receive) {
        // Register with Apple / Google to receive push via APNS/FCM
        PushNotifications.register();
      } else {
        // Show some error
      }
    });

    PushNotifications.addListener('registration', (token: Token) => {
      this.registerDeviceToken(token.value);
    });

    PushNotifications.addListener('pushNotificationActionPerformed', (notification: ActionPerformed) => {
      try {
        this.handlePushNotification(notification.notification.data);
      } catch (err) {
        console.warn(err);
      }
    });
  }

  handlePushNotification(notification: Notification) {
    if (NAVIGATE_TO_EVENT_TYPES.includes(notification.type)) {
      this.router.navigate(['/tabs', 'home', 'event', 'details', notification.relatedDocumentId], {
        queryParams: {
          tab: notification.type === NotificationType.JoinRequest ? 'players' : 'overview',
        },
      });
    } else if (NAVIGATE_TO_GROUP_TYPES.includes(notification.type)) {
      this.router.navigate(['/tabs', 'group', 'details', notification.relatedDocumentId]);
    }
  }
}
