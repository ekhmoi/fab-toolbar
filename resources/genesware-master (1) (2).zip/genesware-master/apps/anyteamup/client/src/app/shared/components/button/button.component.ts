import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ButtonComponent {
  @Input() expand!: string;
  @Input() fill!: string;
  @Input() size!: string;
  @Input() color!: string;
  @Input() href!: string;
  @Input() shape!: string;
  @Input() cssClass!: string;
  @Input() buttonType!: string;
  @Input() disabled!: boolean;
  @Input() download!: string;
  @Input() mode!: string;
  @Input() routerDirection!: string;
  @Input() strong!: boolean;
  @Input() type!: string;
  @Input() loading = true;
  @Input() disableWhileLoading = true;
  @Input() spinnerSlot = 'end';
}
