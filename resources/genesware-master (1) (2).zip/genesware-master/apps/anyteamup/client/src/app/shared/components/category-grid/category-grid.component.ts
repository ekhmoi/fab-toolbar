import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from '@angular/core';
import { Category } from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-category-grid',
  templateUrl: './category-grid.component.html',
  styleUrls: ['./category-grid.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CategoryGridComponent implements OnChanges {
  @Input() nowrap = false;
  @Input() title!: string;
  @Input() userCategories: Category[] = [];
  private _categories: Category[] = [];
  @Input() set categories(categories: Category[] | null) {
    this._categories = categories || [];
  }
  get categories(): Category[] {
    return this._categories;
  }
  private _selectedCategories: string[] = [];
  @Input() set selectedCategories(categoryIds: string[]) {
    this._selectedCategories = categoryIds || [];
  }
  get selectedCategories() {
    return this._selectedCategories;
  }
  @Input() cardClasses: string[] = [];
  visibleCategories: Category[] = [];

  @Output() categoryClick = new EventEmitter<[Category, boolean]>();

  ngOnChanges({ categories, userCategories }: SimpleChanges) {
    if (!categories) {
      return;
    }
    if (
      !userCategories ||
      !userCategories.currentValue ||
      !userCategories.currentValue.length
    ) {
      this.visibleCategories = categories.currentValue || [];
    } else {
      this.visibleCategories = (categories.currentValue || []).filter(
        (cat: Category) => {
          return userCategories.currentValue.indexOf(cat.key) > -1;
        }
      );
    }
  }

  onClick(category: Category): void {
    const nextState = this.selectedCategories.indexOf(category.key) === -1;
    this.categoryClick.emit([category, nextState]);
  }

  trackByFn(index: number, { id }: Category) {
    return id;
  }

  showAll() {
    this.visibleCategories = this.categories;
  }
}
