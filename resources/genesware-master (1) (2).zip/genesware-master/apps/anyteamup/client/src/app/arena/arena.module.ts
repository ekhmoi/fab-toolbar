import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule } from '@angular/router';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { AuthModule } from '../auth/auth.module';
import { BookingModule } from '../booking/booking.module';
import { EventModule } from '../event/event.module';
import { MapModule } from '../shared/map';
import { SharedModule } from '../shared/shared.module';
import { UserModule } from '../user/user.module';

import { ArenaDetailsComponent } from './arena-details/arena-details.component';
import { CreateArenaComponent } from './create-arena/create-arena.component';
import { NearbyArenasComponent } from './nearby-arenas/nearby-arenas.component';

@NgModule({
  declarations: [
    CreateArenaComponent,
    NearbyArenasComponent,
    ArenaDetailsComponent,
  ],
  exports: [NearbyArenasComponent, ArenaDetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    MapModule,
    FlexLayoutModule,
    EventModule,
    BookingModule,
    UserModule,
    AuthModule,
    RouterModule.forChild([
      {
        path: '',
        component: NearbyArenasComponent,
      },
      {
        path: ':id',
        component: ArenaDetailsComponent,
      },
    ]),
  ],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'booking' }],
})
export class ArenaModule {}
