import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'app-avatar',
  template: `
    <ion-avatar [ngStyle]="{ 'width.px': size, 'height.px': size }">
      <img
        [src]="avatar ? (usePipe ? (avatar | assetUrl) : avatar) : defaultUrl"
      />
    </ion-avatar>
  `,
  styles: [
    `
      ion-avatar {
        margin: 10px 0px;
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AvatarComponent {
  defaultUrl = 'assets/custom-icons/avatars/default.svg';
  @Input() avatar!: string;
  @Input() size = 40;

  get usePipe() {
    return this.avatar && !this.avatar.startsWith('http');
  }
}
