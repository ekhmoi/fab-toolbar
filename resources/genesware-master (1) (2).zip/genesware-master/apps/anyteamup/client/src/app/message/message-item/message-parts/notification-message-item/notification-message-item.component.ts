import { Component, Input } from '@angular/core';
import { Message, MessagePartType, User } from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-notification-message',
  templateUrl: './notification-message-item.component.html',
  styleUrls: ['./notification-message-item.component.scss'],
})
export class NotificationMessageItemComponent {
  @Input() message!: Message;
  @Input() groupUsers!: Map<string, User>;
  @Input() part!: { type: MessagePartType; message: string; payload?: any };
  @Input() displaySender!: boolean;
}
