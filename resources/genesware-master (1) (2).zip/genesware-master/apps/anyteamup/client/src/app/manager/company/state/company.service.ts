import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ID } from '@datorama/akita';
import { Review, User } from '@genesware/shared/angular-sdk';

import { switchMap, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { Asset } from '../../../models/asset.interface';
import { Company } from './company.model';
import { CompanyStore } from './company.store';

@Injectable({ providedIn: 'root' })
export class CompanyService {
  apiURL = `${environment.gatewayUrl}/companies`;
  constructor(private companyStore: CompanyStore, private http: HttpClient) {}

  uploadAsset(file: File) {
    const formData = new FormData();
    formData.append('files', file);
    return this.http.post<Asset[]>(`${environment.assetUrl}/assets`, formData);
  }

  uploadLogo(companyId: string, file: File) {
    const url = `${this.apiURL}/${companyId}`;

    return this.uploadAsset(file).pipe(
      switchMap(([asset]) =>
        this.http.patch<Company>(url, { logo: asset.url })
      ),
      tap((company) => this.companyStore.update(companyId, company))
    );
  }

  setActive(id: string) {
    this.companyStore.setActive(id);
  }

  get({ setDefault }: { setDefault: boolean }) {
    return this.http.get<Company[]>(this.apiURL).pipe(
      tap((companies) => {
        this.companyStore.set(companies);
        if (setDefault && companies && companies.length) {
          this.setActive(companies[0].id);
        }
      })
    );
  }

  create(company: Partial<Company>) {
    return this.http
      .post<Company>(this.apiURL, company)
      .pipe(tap((c) => this.companyStore.add(c)));
  }

  add(company: Company) {
    this.companyStore.add(company);
  }

  update(id: string, company: Partial<Company>) {
    this.companyStore.update(id, company);
  }

  remove(id: ID) {
    this.companyStore.remove(id);
  }

  getManagers(companyId: string) {
    return this.http.get<User[]>(`${this.apiURL}/${companyId}/managers`);
  }

  getReviews(companyId: string) {
    return this.http.get<Review[]>(`${this.apiURL}/${companyId}/reviews`);
  }
}
