export class BaseMessagePage {
    
}