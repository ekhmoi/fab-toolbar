import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';

import { SharedModule } from '../../shared/shared.module';
import { UserModule } from '../../user/user.module';
import { BookingCardComponent } from './booking-card/booking-card.component';
import { BookingsToolbarComponent } from './bookings-toolbar/bookings-toolbar.component';
import { ManagerBookingsComponent } from './bookings.component';

@NgModule({
  declarations: [
    ManagerBookingsComponent,
    BookingsToolbarComponent,
    BookingCardComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    FlexLayoutModule,
    MatDatepickerModule,
    UserModule,
    MatIconModule,
    RouterModule.forChild([{ path: '', component: ManagerBookingsComponent }]),
  ],
})
export class ManagerBookingsModule {}
