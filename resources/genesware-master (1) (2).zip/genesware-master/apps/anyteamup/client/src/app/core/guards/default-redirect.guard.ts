import { AuthQuery, UserRole } from '@genesware/shared/angular-sdk';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router } from '@angular/router';
import { map, tap } from 'rxjs/operators';
import { UserService } from '../services/user.service';

const USER_DEFAULT_ROUTE = ['/tabs', 'home'];
const MANAGER_DEFAULT_ROUTE = ['/manage', 'company'];
@Injectable({
  providedIn: 'root',
})
export class DefaultRedirectGuard implements CanActivate {
  constructor(
    private userService: UserService,
    private router: Router,
    private authQuery: AuthQuery
  ) {}

  canActivate(snapShot: ActivatedRouteSnapshot) {
    const auth = this.authQuery.getValue();
    if (auth.isLoggedIn) {
      const isManager = (auth.user.role as string) === 'Manager';
      this.router.navigate(
        isManager ? MANAGER_DEFAULT_ROUTE : USER_DEFAULT_ROUTE
      );
      return false;
    }

    return this.userService.getParam<boolean>('WELCOME_PRESENTED').pipe(
      map((presented) => !presented),
      tap((displayWelcome) => {
        if (!displayWelcome) {
          this.router.navigate(['/tabs', 'home']);
        } else if (!snapShot.url[0] || snapShot.url[0].path !== 'welcome') {
          this.router.navigate(['/welcome']);
        }
      })
    );
  }
}
