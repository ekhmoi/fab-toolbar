import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import {
  AuthQuery,
  Group,
  GroupQuery,
  GroupService,
  NotificationQuery,
  NotificationService,
  NotificationStatus,
  NotificationType,
  User,
} from '@genesware/shared/angular-sdk';
import { IonContent, ModalController, PopoverController } from '@ionic/angular';
import { Subscription } from 'rxjs';

import { GroupManagerService } from '../group-manager.service';
import { UserInfoComponent } from '../../user/user-info/user-info.component';

@Component({
  selector: 'app-group-settings',
  templateUrl: './group-settings.page.html',
  styleUrls: ['./group-settings.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GroupSettingsPage implements OnInit, OnDestroy {
  @Input() data: any;
  @Input() group: Group = this.groupQuery.getActive() as Group;

  form = this.fb.group({
    anyoneCanAcceptRequest: [this.group.anyoneCanAcceptRequest],
    anyoneCanModifyGroup: [this.group.anyoneCanModifyGroup],
    approveNewUsers: [!this.group.approveNewUsers],
  });
  loggedUser!: User;
  alreadyMarked = false;
  subscriptions: Subscription[] = [];

  @ViewChild(IonContent) content!: IonContent;

  constructor(
    private modalController: ModalController,
    private popoverController: PopoverController,
    private authQuery: AuthQuery,
    public service: GroupService,
    public manager: GroupManagerService,
    private cdr: ChangeDetectorRef,
    private fb: UntypedFormBuilder,
    private groupQuery: GroupQuery,
    private notificationQuery: NotificationQuery,
    private notificationService: NotificationService
  ) {}

  get canModify() {
    return (
      this.group?.createdBy.id === this.loggedUser.id ||
      this.group?.anyoneCanModifyGroup
    );
  }

  get isCreator() {
    return this.group?.createdBy.id === this.loggedUser.id;
  }

  get pendingPlayers() {
    if (!this.group) {
      return [];
    }

    return this.group?.requests?.map((r) => r.createdBy) || [];
  }

  ngOnInit() {
    this.loggedUser = this.authQuery.getValue().user;
    this.groupQuery.active$.subscribe((group) => {
      this.group = group;
      this.markNotificationsAsRead();
      this.cdr.detectChanges();
    });
    const { anyoneCanAcceptRequest, anyoneCanModifyGroup, approveNewUsers } =
      this.form.controls;
    const s1 = anyoneCanAcceptRequest?.valueChanges.subscribe((val) => {
      this.service.updateProperty(this.group.id, 'anyoneCanAcceptRequest', val);
    });
    const s2 = anyoneCanModifyGroup.valueChanges.subscribe((val) => {
      this.service.updateProperty(this.group.id, 'anyoneCanModifyGroup', val);
    });
    const s3 = approveNewUsers.valueChanges.subscribe((val) => {
      this.service.updateProperty(this.group.id, 'approveNewUsers', !val);
    });
    this.subscriptions = [s1, s2, s3];

    // if (this.data?.pendingPlayer) {
    //   const player = this.group.pendingPlayers.find(({ id }) => id === this.data.pendingPlayers);
    //   if (player) {
    //     this.content.scrollToBottom();
    //     this.onView(player);
    //   }
    // }
  }

  markNotificationsAsRead() {
    if (this.alreadyMarked) {
      return;
    }

    this.alreadyMarked = true;
    // Mark related notifications as read
    const notifications = this.notificationQuery.getAll();
    const joinGroupNotifications = notifications.filter(
      (n) =>
        n.relatedDocumentId === this.group.id &&
        n.status === NotificationStatus.New &&
        n.type === NotificationType.JoinGroupRequestReceived
    );

    if (!joinGroupNotifications.length) {
      return;
    }

    this.notificationService.markAsRead(
      joinGroupNotifications.map(({ id }) => id)
    );
  }

  ngOnDestroy() {
    this.subscriptions.forEach((s) => s && s.unsubscribe && s.unsubscribe());
  }

  dismiss() {
    this.modalController.dismiss();
  }

  refreshLink() {
    this.service.createLink(this.group.id).subscribe((response: any) => {
      this.group = {
        ...this.group,
        token: response.token,
      };
      this.cdr.detectChanges();
    });
  }

  async onView(user: User) {
    const currentUser = this.authQuery.getValue().user;
    if (user.id === currentUser.id) {
      return;
    }

    const isUserInPending = this.group.requests?.some(
      ({ createdBy }) =>
        (typeof createdBy === 'string' ? createdBy : (createdBy as any).id) ===
        user.id
    );
    const modal = await this.modalController.create({
      component: UserInfoComponent,
      componentProps: { user, group: this.group, currentUser, isUserInPending },
      cssClass: 'transparent-modal',
      keyboardClose: true,
    });

    return await modal.present();
  }

  leave() {
    this.manager.leave(this.group);
    this.popoverController.dismiss();
  }
}
