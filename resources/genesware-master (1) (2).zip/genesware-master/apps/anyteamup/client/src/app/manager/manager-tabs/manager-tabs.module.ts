import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { IonicModule } from '@ionic/angular';

import { AuthModule } from '../../auth/auth.module';
import { ChatModule } from '../chat/chat.module';
import { CreateEventModule } from '../../event/create-event/create-event.module';
import { HomePageModule } from '../../home/home.module';

import { NotificationsModule } from '../../notifications/notifications.module';
import { ManagerTabsPage } from './manager-tabs.page';
import { ManagerTabsPageRoutingModule } from './manager-tabs.router.module';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    AuthModule,
    ManagerTabsPageRoutingModule,
    HomePageModule,
    MatIconModule,
    NotificationsModule,
    CreateEventModule,
    FlexLayoutModule,
    ChatModule,
  ],
  declarations: [ManagerTabsPage],
})
export class ManagerTabsPageModule {}
