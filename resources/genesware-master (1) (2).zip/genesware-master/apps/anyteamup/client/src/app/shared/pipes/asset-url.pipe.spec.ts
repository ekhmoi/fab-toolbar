import { AssetUrlPipe } from './asset-url.pipe';

describe('AssetUrlPipe', () => {
  it('create an instance', () => {
    const pipe = new AssetUrlPipe();
    expect(pipe).toBeTruthy();
  });
});
