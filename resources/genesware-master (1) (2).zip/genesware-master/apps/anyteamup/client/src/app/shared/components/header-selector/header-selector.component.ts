import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';

interface SelectOption {
  id: string;
  name: string;
  icon?: string;
}

@Component({
  selector: 'app-header-selector',
  templateUrl: './header-selector.component.html',
  styleUrls: ['./header-selector.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderSelectorComponent {
  @Input() hideSelected = false;
  @Input() addNewTitle!: string;
  @Input() showAddNew = true;
  @Input() imgPropertyName!: string;

  private _options: SelectOption[] = [];
  @Input() set options(options: SelectOption[]) {
    this._options = options;
    this._setSelectedOption();
  }
  get options() {
    return this._options;
  }
  private _selectedOptionId!: string;
  @Input() set selectedOptionId(id: string) {
    this._selectedOptionId = id;
    this._setSelectedOption();
  }
  get selectedOptionId() {
    return this._selectedOptionId;
  }

  @Output() optionSelect = new EventEmitter<string>();
  @Output() add = new EventEmitter<MouseEvent>();

  selectedOption!: SelectOption | null;

  onChange(option: SelectOption, index: number) {
    this.selectedOptionId = option.id;
    this.optionSelect.emit(option.id);
  }

  private _setSelectedOption() {
    this.selectedOption = this.selectedOptionId
      ? (this.options || []).find((o) => o.id === this.selectedOptionId) || null
      : null;
  }
}
