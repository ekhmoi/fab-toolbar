import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { of, Subject } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { AGM_DARK_THEME } from './agm-dark-theme';
import { MapService } from './map.service';

const ACTION_DELAY = 50;
declare var google: any;
@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss'],
})
export class MapComponent implements OnInit {
  @Input() outputMarkerClicks = false;
  @Input() searchable = true;
  @Input() markCenter = true;
  @Input() coords!: { lat: number; lng: number } | null;

  @Input() markers!: {
    name?: string;
    title?: string;
    location: { coordinates: [number, number] };
    category?: string;
  }[];

  private _zoom = 15;
  @Input() set zoom(zoom: number) {
    this._zoom = zoom;
    this.service?.map?.setZoom(zoom);
  }
  get zoom() {
    return this._zoom;
  }

  @Output() markerClick = new EventEmitter<any>();
  @Output() placeSelect = new EventEmitter<any>();

  listenToCenterChanges = false;
  hideCustomMarker = false;
  searchBox!: google.maps.places.Autocomplete;
  center$ = new Subject<{ lat: number; lng: number }>();
  viewingAutocompleteResult = false;
  iconSize: any = {
    width: 40,
    height: 40,
  };

  private _place: any = null;
  set place(place: any) {
    this._place = place;
    this.placeSelect.emit(place);
  }
  get place() {
    return this._place;
  }

  @ViewChild('searchInput') searchInput!: any;

  private _agm!: any;

  @ViewChild('agmMap', { static: false })
  public set agmMap(agm: any) {
    this._agm = agm;
    if (agm) {
      this._setupMap();
    }
  }
  public get agmMap() {
    return this._agm;
  }

  get theme(): any {
    const $html = document.querySelector('html');
    if (!$html) {
      return [];
    }
    return $html.className.indexOf('dark') > -1 ? AGM_DARK_THEME : [];
  }

  constructor(private cdr: ChangeDetectorRef, private service: MapService) {}

  ngOnInit(): void {
    this.center$
      .pipe(debounceTime(50), distinctUntilChanged())
      .subscribe(({ lat, lng }) => {
        this.service
          .geocode(lat, lng)
          .pipe(catchError((err) => of(null)))
          .subscribe((place) => {
            if (place === null) {
              // Nothing found, don't do anything.
              this.place = null;
            } else {
              this.place = {
                ...this.place,
                ...place,
                lat,
                lng,
              };
            }
          });
      });
  }

  onCenterChange(event: any) {
    if (!this.listenToCenterChanges) {
      return;
    }
    this.viewingAutocompleteResult = false;
    this.hideCustomMarker = false;

    const { lat, lng } = this.service.map.getCenter() as google.maps.LatLng;

    this.center$.next({ lat: lat(), lng: lng() });
  }

  private _setupMap() {
    this.agmMap.mapReady.subscribe((map: any) => {
      this.service.map = map;
      this.service.map.setZoom(this.zoom);
      setTimeout(() => {
        this.listenToCenterChanges = true;
        this._connectSearchBox();
        // (this.markers || []).forEach(
        //   (marker) =>
        //     new google.maps.Marker({
        //       position: { lng: marker.location.coordinates[0], lat: marker.location.coordinates[1] },
        //       map,
        //       title: marker.name || marker.title,
        //     })
        // );

        this.cdr.detectChanges();
      }, ACTION_DELAY);
    });
  }

  onClickMarker(marker: any) {
    console.log(marker);
  }

  getPlace() {
    if (this.listenToCenterChanges && !this.viewingAutocompleteResult) {
      return this.place;
    }
    const place = this.searchBox.getPlace();
    return {
      ...this.place,
      lat: place.geometry?.location?.lat(),
      lng: place.geometry?.location?.lng(),
    };
  }

  private _connectSearchBox() {
    if (!this.searchable) {
      return;
    }
    this.searchBox = new google.maps.places.Autocomplete(
      this.searchInput.el.querySelector('input')
    );
    this.searchBox.setFields([
      'address_components',
      'geometry',
      'icon',
      'name',
    ]);
    this._setupInfoWindow();
  }

  private _setupInfoWindow() {
    const marker = new google.maps.Marker({
      map: this.service.map,
      anchorPoint: new google.maps.Point(0, -29),
    });

    this.searchBox.addListener('place_changed', () => {
      marker.setVisible(false);
      const place = this.searchBox.getPlace();

      if (!place.geometry) {
        // User entered the name of a Place that was not suggested and
        // pressed the Enter key, or the Place Details request failed.
        return;
      }

      this.listenToCenterChanges = false;
      this.hideCustomMarker = true;
      this.viewingAutocompleteResult = true;
      // If the place has a geometry, then present it on a map.
      if (place.geometry.viewport) {
        this.service.map.fitBounds(place.geometry.viewport);
      } else {
        this.service.map.setCenter(place.geometry.location!);
        this.service.map.setZoom(17); // Why 17? Because it looks good.
      }
      marker.setPosition(place.geometry.location);
      marker.setVisible(true);

      const address = this.service.extractAddressFromPlace(place);
      this.place = {
        ...place,
        address,
        lat: place.geometry.location?.lat(),
        lng: place.geometry.location?.lng(),
      };
      setTimeout(() => {
        this.listenToCenterChanges = true;
      }, ACTION_DELAY);
    });
  }
}
