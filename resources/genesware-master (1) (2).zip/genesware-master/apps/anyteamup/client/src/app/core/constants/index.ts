export const STORAGE_KEYS = {
  AUTH_TOKEN: '@app/auth/token',
  USER: '@app/user/info',
};
export const TOAST_DURATION = 3000;
