import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { Event } from '@genesware/shared/angular-sdk';
import { animate, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'app-previous-events-list',
  templateUrl: './previous-events-list.component.html',
  styleUrls: ['./previous-events-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'game-event' }],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ transform: 'scale(0)' }),
        animate('200ms ease-in', style({ transform: 'scale(1)' })),
      ]),
      transition(':leave', [
        animate('200ms ease-in', style({ transform: 'scale(0)' })),
      ]),
    ]),
  ],
})
export class PreviousEventsListComponent implements AfterViewInit {
  @Input() title!: string;
  @Input() description!: string;
  @Input() items: Event[] = [];
  @Input() showActions = true;

  @Output() eventClick = new EventEmitter<Event>();
  @Output() noClick = new EventEmitter<Event>();
  @Output() yesClick = new EventEmitter<Event>();

  slideOpts = {
    slidesPerView: 'auto',
    spaceBetween: 30,
  };
  animate = false;

  ngAfterViewInit(): void {
    this.animate = true;
  }

  trackByFn(index: number, ev: Event) {
    return ev.id;
  }
}
