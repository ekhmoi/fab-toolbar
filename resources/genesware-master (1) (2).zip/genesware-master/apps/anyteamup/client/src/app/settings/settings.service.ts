import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  AuthQuery,
  AuthService,
  AuthStore,
  Category,
  LoginType,
  serializePreferences,
  User,
  UserService,
} from '@genesware/shared/angular-sdk';
import { BehaviorSubject, of } from 'rxjs';
import { finalize, switchMap, tap } from 'rxjs/operators';

import { environment } from '../../environments/environment';
import { setTheme } from '../core/helpers';
import { Asset } from '../models/asset.interface';

@Injectable({
  providedIn: 'root',
})
export class SettingsService {
  newPasswordLoading$ = new BehaviorSubject(false);
  constructor(
    private authQuery: AuthQuery,
    private authService: AuthService,
    private authStore: AuthStore,
    private userService: UserService,
    private http: HttpClient
  ) {}

  setTheme(theme: 'dark' | 'light' | 'auto', update = true) {
    setTheme(theme);
    if (update) {
      localStorage.setItem('@app/settings/theme', theme);
      const state = this.authQuery.getValue();
      if (!state.user) {
        return;
      }
      this.userService
        .upsertPreferences([
          { name: 'UI_THEME', value: JSON.stringify({ selected: theme }) },
        ] as any)
        .subscribe();
    }
  }

  setNewPassword(password: string) {
    this.newPasswordLoading$.next(true);
    this.userService
      .getHttp()
      .post(`${this.userService.api}/password`, {
        token: this.authQuery.getValue().token,
        password,
      })
      .pipe(finalize(() => this.newPasswordLoading$.next(false)))
      .subscribe(() => {
        this.authStore.update((state) => ({
          ...state,
          user: {
            ...state.user,
            loginType: LoginType.Email,
          },
        }));
      });
  }

  updateProfilePicture(file: string) {
    const formData = new FormData();
    formData.append('files', file);
    return this.http
      .post<Asset[]>(`${environment.assetUrl}/assets`, formData)
      .pipe(switchMap(([asset]) => this.updateProfile({ avatar: asset.url })));
  }

  updateProfile(profileToUpdate: any) {
    const { profile } = this.authQuery.getValue().user;
    return this.http
      .put<User>(`${environment.gatewayUrl}/users/profile`, {
        ...profile,
        ...profileToUpdate,
      })
      .pipe(
        tap((user) => {
          this.authService.updateUser({
            ...user,
            preferences: serializePreferences(user.preferences),
          });
        })
      );
  }

  toggleCategory(category: Category, s = false) {
    let selectedCategories: string[] =
      this.userService.getUserPreference('SELECTED_CATEGORIES') || [];

    if (selectedCategories.indexOf(category.key) > -1) {
      selectedCategories = selectedCategories.filter(
        (cat) => cat !== category.key
      );
    } else {
      selectedCategories = [...selectedCategories, category.key];
    }
    if (this.authQuery.getValue().isLoggedIn) {
      return this.userService.upsertPreferences([
        {
          name: 'SELECTED_CATEGORIES',
          value: JSON.stringify(selectedCategories),
        } as any,
      ]);
    } else {
      this.authStore.update((state) => ({
        user: {
          ...state.user,
          preferences: serializePreferences([
            {
              name: 'SELECTED_CATEGORIES',
              value: JSON.stringify(selectedCategories),
            } as any,
          ]),
        },
      }));
      return of();
    }
  }
}
