import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';
import { UntypedFormControl } from '@angular/forms';

import { User } from '@genesware/shared/angular-sdk';
import { SettingsService } from '../settings.service';

@Component({
  selector: 'app-profile-management',
  templateUrl: './profile-management.component.html',
  styleUrls: ['./profile-management.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProfileManagementComponent {
  imageControl = new UntypedFormControl();

  @Input() user!: User;

  @Output() changeAvatar = new EventEmitter<any>();
  @Output() setNewPassword = new EventEmitter<MouseEvent>();

  constructor(public service: SettingsService) {}

  onFileSelect(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.changeAvatar.next(file);
    }
  }
}
