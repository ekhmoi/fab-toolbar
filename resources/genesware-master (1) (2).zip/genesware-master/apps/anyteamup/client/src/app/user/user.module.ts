import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { IonicModule } from '@ionic/angular';
import { TranslocoModule } from '@ngneat/transloco';
import { NgChartsModule } from 'ng2-charts';

import { SharedModule } from '../shared/shared.module';
import { UserChartComponent } from './user-chart/user-chart.component';
import { UserInfoComponent } from './user-info/user-info.component';
import { UserPreferencesSetupModalComponent } from './user-preferences-setup-modal/user-preferences-setup-modal.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { UsersListComponent } from './users-list/users-list.component';

@NgModule({
  declarations: [
    UserChartComponent,
    UserInfoComponent,
    UserProfileComponent,
    UsersListComponent,
    UserPreferencesSetupModalComponent,
  ],
  exports: [
    UserChartComponent,
    UserInfoComponent,
    UserProfileComponent,
    UsersListComponent,
    UserPreferencesSetupModalComponent,
  ],
  imports: [CommonModule, IonicModule, NgChartsModule, TranslocoModule, FlexLayoutModule, SharedModule],
})
export class UserModule {}
