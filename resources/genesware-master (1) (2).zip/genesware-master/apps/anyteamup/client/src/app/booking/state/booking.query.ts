import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { BookingStore, BookingState } from './booking.store';

@Injectable({ providedIn: 'root' })
export class BookingQuery extends QueryEntity<BookingState> {
  items$ = this.selectAll();
  loading$ = this.selectLoading();

  constructor(protected override store: BookingStore) {
    super(store);
  }
}
