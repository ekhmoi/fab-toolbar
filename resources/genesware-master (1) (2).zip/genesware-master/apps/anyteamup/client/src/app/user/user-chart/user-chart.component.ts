import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { translate } from '@ngneat/transloco';
import { ChartDataset, ChartType } from 'chart.js';

import { Review, User } from '@genesware/shared/angular-sdk';
import { groupUserReviews } from '../../core/helpers';
import { USER_CHART_DEFAULT_OPTIONS } from './chart-default-options';

@Component({
  selector: 'app-user-chart',
  templateUrl: './user-chart.component.html',
  styleUrls: ['./user-chart.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserChartComponent {
  radarChartOptions = USER_CHART_DEFAULT_OPTIONS;
  radarChartLabels: string[] = [];
  radarChartData: ChartDataset[] = [
    {
      data: [],
      backgroundColor: 'rgba(0,0,0,0)',
      borderColor: '#18f2b0',
      pointBorderColor: '#18f2b0',
      pointBackgroundColor: '#18f2b0',
      borderJoinStyle: 'bevel',
      tension: 0.2,
    },
  ];
  radarChartType: ChartType = 'radar';

  @Input() limit = 5;
  @Input() set user(user: User | null) {
    if (user) {
      this.setReviews(user.reviews as any[]);
    }
  }

  @Input()
  public set ratings(ratings: any[]) {
    ratings = ratings
      .slice()
      .sort((a, b) => b.value - a.value)
      .slice(0, this.limit);
    this.radarChartLabels = ratings.map(({ key }) =>
      translate(`ratingFields.${key}`)
    );
    this.radarChartData = [
      {
        ...this.radarChartData[0],
        data: ratings.map(({ value }) => value),
      },
    ];
  }

  setReviews(r: Review[] = []) {
    const reviews = groupUserReviews(r)
      .slice()
      .sort((a, b) => b.value - a.value)
      .slice(0, this.limit);
    this.radarChartLabels = reviews.map(({ key }) =>
      translate(`ratingFields.${key}`)
    );
    this.radarChartData = [
      {
        ...this.radarChartData[0],
        data: reviews.map(({ value }) => value),
      },
    ];
  }
}
