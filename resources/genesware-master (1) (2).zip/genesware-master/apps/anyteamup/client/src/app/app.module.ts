import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserModule, HammerModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouteReuseStrategy } from '@angular/router';
import { MomentModule } from 'ngx-moment';

import { SdkModule } from '@genesware/shared/angular-sdk';

import { environment } from '../environments/environment';
import { ErrorHandlerInterceptor, TokenInterceptor } from './core/interceptors';
import { configFactory, ConfigService } from './core/services';
import { EventModule } from './event/event.module';
import { HomePageModule } from './home/home.module';
import { NotificationsModule } from './notifications/notifications.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GroupModule } from './group/group.module';
import { TranslocoRootModule } from './transloco/transloco-root.module';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    IonicModule.forRoot({
      // mode: 'md',
      swipeBackEnabled: true,
    }),
    FlexLayoutModule.withConfig({}),
    HttpClientModule,
    AppRoutingModule,
    // IonicStorageModule.forRoot(),
    MomentModule.forRoot({
      relativeTimeThresholdOptions: {
        m: 59,
      },
    }),
    SdkModule.forRoot({
      gatewayUrl: environment.gatewayUrl,
      assetsUrl: environment.assetUrl,
      messagesUrl: environment.messageUrl,
      notificationsUrl: environment.notificationUrl,
      // production: environment.production,
    }),
    // TranslocoPreloadLangsModule.preload([
    //   'en',
    //   'notification',
    //   'game-event',
    //   'group',
    //   'welcome',
    // ]),
    EventModule,
    HomePageModule,
    GroupModule,
    NotificationsModule,
    TranslocoRootModule,
  ],
  providers: [
    ConfigService,
    {
      provide: APP_INITIALIZER,
      useFactory: configFactory,
      deps: [ConfigService],
      multi: true,
    },
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },

    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorHandlerInterceptor,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
