import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';
import { Notification, NotificationType } from '@genesware/shared/angular-sdk';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { ViewNotification } from '../../models/view-notification.interface';

const TYPE_TO_ICON_MAP = new Map([
  [NotificationType.PlayerJoined, 'car'],
  [NotificationType.JoinEventRequestAccepted, 'car'],
  [NotificationType.RequestReject, 'car'],
  [NotificationType.Review, 'car'],
]);

function isGroupType(type: string) {
  return (
    [
      NotificationType.JoinGroupRequestReceived,
      // NotificationType.RemovedFromGame,
      NotificationType.JoinGroupRequestRejected,
      NotificationType.PlayerJoinedGroup,
    ] as string[]
  ).includes(type);
}

function isEventType(type: string) {
  return (
    [
      NotificationType.JoinRequest,
      NotificationType.JoinEventRequestAccepted,
      NotificationType.RemovedFromGame,
      NotificationType.RequestReject,
    ] as string[]
  ).includes(type);
}

function isBookingType(type: string) {
  return ['CreateBookingRequestReceived'].includes(type);
}

@Component({
  selector: 'app-notification-list',
  templateUrl: './notification-list.component.html',
  styleUrls: ['./notification-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'notification' }],
})
export class NotificationListComponent {
  private _rawNotifications: Notification[] = [];
  viewNotifications: ViewNotification[] = [];

  @Input() displayNew = false;
  @Input() displayTypes: NotificationType[] = [];
  @Input() set notifications(notifications: Notification[]) {
    this._rawNotifications = notifications || [];
    this.parseNotifications();
  }

  @Output() notificationClick = new EventEmitter<any>();

  parseNotifications() {
    this.viewNotifications = this._rawNotifications
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .map((notification: Notification) => {
        let route: string[] = [];
        let queryParams = null;
        if (isEventType(notification.type)) {
          route = ['/event', 'details', notification.relatedDocument.id];
          if (notification.type === NotificationType.JoinRequest) {
            queryParams = { tab: 'players' };
          }
        } else if (isGroupType(notification.type)) {
          route = ['/group', 'details', notification.relatedDocument.id];
        } else if (isBookingType(notification.type)) {
          console.log(
            '[FIXME] Add proper URL to navigate to booking notifications'
          );
        }

        let firstName: string;
        let lastName: string;

        if ((notification.data as any)?.user) {
          const profile = (notification.data as any)?.user?.profile || {};
          firstName = profile.firstName;
          lastName = profile.lastName;
        } else {
          const profile = (notification.initiator as any)?.profile || {};
          firstName = profile.firstName;
          lastName = profile.lastName;
        }

        return {
          id: notification.id,
          type: notification.type,
          icon: TYPE_TO_ICON_MAP.get(notification.type),
          title: `notification.${notification.type}.title`,
          content: `notification.${notification.type}.content`,
          createdAt: notification.createdAt,
          route,
          queryParams,
          status: notification.status,
          translationParams: {
            related: notification.relatedDocument.title,
            initiator: (firstName + ' ' + lastName).trim(),
          },
        };
      });
  }

  onClick(notification: any) {
    this.notificationClick.next(notification);
  }

  trackByFn(index: number, { id }: ViewNotification) {
    return id;
  }
}
