import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { SharedModule } from '../shared/shared.module';
import { CreateBookingComponent } from './create-booking/create-booking.component';

@NgModule({
  declarations: [CreateBookingComponent],
  imports: [CommonModule, SharedModule, MatDatepickerModule, FlexLayoutModule],
  exports: [CreateBookingComponent],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'booking' }],
})
export class BookingModule {}
