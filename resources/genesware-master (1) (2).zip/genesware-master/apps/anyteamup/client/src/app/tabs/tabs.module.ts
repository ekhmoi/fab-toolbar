import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { IonicModule } from '@ionic/angular';

import { AuthModule } from '../auth/auth.module';
import { CreateEventModule } from '../event/create-event/create-event.module';
import { HomePageModule } from '../home/home.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { TabsPage } from './tabs.page';
import { TabsPageRoutingModule } from './tabs.router.module';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    AuthModule,
    TabsPageRoutingModule,
    HomePageModule,
    MatIconModule,
    NotificationsModule,
    CreateEventModule,
    FlexLayoutModule,
  ],
  declarations: [TabsPage],
})
export class TabsPageModule {}
