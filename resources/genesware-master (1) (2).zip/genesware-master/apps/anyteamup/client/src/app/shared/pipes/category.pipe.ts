import { Pipe, PipeTransform } from '@angular/core';
import { Category, CategoryQuery } from '@genesware/shared/angular-sdk';

@Pipe({
  name: 'category',
})
export class CategoryPipe implements PipeTransform {
  constructor(private categoryQuery: CategoryQuery) {}

  transform(key: string | Category): Category {
    if (typeof key === 'string') {
      const allCategories = this.categoryQuery.getAll();
      return allCategories.find((c) => c.key === key) as Category;
    }
    return key;
  }
}
