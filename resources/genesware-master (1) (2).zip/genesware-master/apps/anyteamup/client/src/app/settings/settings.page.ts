import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
} from '@angular/core';
import {
  AuthQuery,
  AuthService,
  UserService,
} from '@genesware/shared/angular-sdk';
import { AlertController } from '@ionic/angular';
import { TranslocoService } from '@ngneat/transloco';
import { filter, finalize, map } from 'rxjs/operators';

import { Language } from '../models/language.enum';
import { SettingsService } from './settings.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SettingsPage {
  user$ = this.authQuery.user$;
  isLoggedIn$ = this.authQuery.isLoggedIn$;
  language$ = this.authQuery
    .selectPreference<{ selected: string }>('USER_LANGUAGE')
    .pipe(
      filter((val) => !!val),
      map(({ selected }) => selected)
    );
  theme$ = this.authQuery
    .selectPreference<{ selected: string }>('UI_THEME')
    .pipe(
      filter((val) => !!val),
      map(({ selected }) => selected)
    );

  constructor(
    private authQuery: AuthQuery,
    private authService: AuthService,
    private service: SettingsService,
    private userService: UserService,
    private transloco: TranslocoService,
    private alertCtrl: AlertController,
    private cdr: ChangeDetectorRef
  ) {}

  onRefresh(event?: any) {
    this.authService
      .reloadUser()
      .pipe(
        finalize(() => {
          event && event.target.complete();
        })
      )
      .subscribe();
  }

  onLogin(ev: any) {
    console.log('logged in', ev);
  }
  onChangeLanguage(language: Language) {
    this.userService
      .upsertPreferences([
        {
          name: 'USER_LANGUAGE',
          value: JSON.stringify({ selected: language }),
        } as any,
      ])
      .subscribe();
    this.transloco.setActiveLang(language);
    ('');
  }

  onChangeTheme(theme: any) {
    this.service.setTheme(theme);
  }

  onChangeAvatar(file: any) {
    this.service.updateProfilePicture(file).subscribe();
  }

  onClickLogout() {
    this.authService.logout();
    this.cdr.detectChanges();
  }

  async onSetNewPassword() {
    const alert = await this.alertCtrl.create({
      cssClass: 'my-custom-class',
      header: 'Type your new password',
      inputs: [
        {
          name: 'password',
          type: 'password',
          placeholder: 'Password',
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          },
        },
        {
          text: 'Set Password',
          handler: (v) => {
            console.log('Confirm Ok', v);
            this.service.setNewPassword(v.password);
          },
        },
      ],
    });

    await alert.present();
  }
}
