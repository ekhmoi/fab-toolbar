import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';

@Component({
  selector: 'app-empty-page',
  templateUrl: './empty-page.component.html',
  styleUrls: ['./empty-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EmptyPageComponent {
  @Input() items!: any[];
  @Input() loading = true;
  @Input() img = '/assets/images/dead-pin.svg';
  @Input() minImgHeight = 100;
  @Input() translocoScope = 'game-event';
  @Input() translocoRoot = 'gameEvent.eventList';
  @Input() messageVisible = true;
  @Input() tipVisible = true;
  @Input() fullScreen = true;

  @Output() actionClick = new EventEmitter<number>();
}
