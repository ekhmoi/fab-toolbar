import { Chart, ChartConfiguration, RadarControllerChartOptions } from 'chart.js';

export const USER_CHART_DEFAULT_OPTIONS: any = {
  responsive: true,
  title: {
    display: false,
  },
  legend: {
    display: false,
  },
  aspectRatio: 1,
  scale: {
    ticks: {
      display: false,
      beginAtZero: true,
      precision: 0,
    },
    pointLabels: {
      fontSize: 13,
      fontStyle: 'bold',
    },
    angleLines: {
      display: true,
      color: 'rgba(0,0,0,0.2)'
    },
    animate: true,
    position: 'bottom',
    gridLines: {
      offsetGridLines: true,
      // circular: true
    },
    //     animate?: boolean;
    // position?: PositionType;
    // angleLines?: AngleLineOptions;
    // pointLabels?: PointLabelOptions;
    // ticks?: LinearTickOptions;
    // display?: boolean;
    // gridLines?: GridLineOptions;
  },
  tooltips: {
    callbacks: {
      label(tooltipItem: any, data: any): string | string[] {
        return data.datasets?.[tooltipItem.datasetIndex as any]?.label + ': ' + tooltipItem.yLabel;
      },
    },
  },
};
