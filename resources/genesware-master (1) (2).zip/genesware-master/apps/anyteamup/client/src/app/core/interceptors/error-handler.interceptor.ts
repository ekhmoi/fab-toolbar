import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpEvent,
  HttpHandler,
  HttpRequest,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { ToastController } from '@ionic/angular';
import { translate } from '@ngneat/transloco';

import { TOAST_DURATION } from '../constants';

@Injectable()
export class ErrorHandlerInterceptor implements HttpInterceptor {
  constructor(private toastCtrl: ToastController) {}
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      retry(1),
      catchError((error: HttpErrorResponse) => {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
          // client-side error
          errorMessage = `Error: ${error.error.message}`;
        } else {
          // server-side errorz
          this.presentToast(error.error);

          errorMessage = `Error Status: ${error.status}\nMessage: ${error.message}`;
        }
        return throwError(errorMessage);
      })
    );
  }

  async presentToast({ message }: { message: string }) {
    const headerTranslateAttempt: string = translate(`error.${message}.header`);
    const messageTranslateAttempt: string = translate(
      `error.${message}.message`
    );
    const toast = await this.toastCtrl.create({
      message: messageTranslateAttempt.startsWith('error.')
        ? message
        : messageTranslateAttempt,
      header: headerTranslateAttempt.startsWith('error.')
        ? undefined
        : headerTranslateAttempt,
      mode: 'ios',
      duration: TOAST_DURATION,
      position: 'top',
      color: 'light',
      buttons: ['ok'],
    });
    // toast.present();
  }
}
