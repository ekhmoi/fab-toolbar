import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { translate, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { filter } from 'rxjs/operators';
import {
  convertToMinutes,
  filterBookingOptions,
  getAvailableSlots,
} from '../../../booking/create-booking/get-available-slots';
import { Booking, BookingOption } from '../../../booking/state/booking.model';

@Component({
  selector: 'app-start-duration-selector',
  templateUrl: './start-duration-selector.component.html',
  styleUrls: ['./start-duration-selector.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'booking' }],
})
export class StartDurationSelectorComponent {
  @Input() collapseCalendarOnSelect = false;
  @Input() displayTimeSelector = true;
  @Input() minDate = new Date();
  @Input() availableSlots: {
    date?: Date;
    bookedFrom?: Date;
    bookedTo?: Date;
  }[] = [];
  @Input() bookingOptions: BookingOption[] = [];
  @Input() bookedSlots: Partial<Booking>[] = [];

  filteredBookingOptions: BookingOption[] = [];
  selectedSlotIndex = -1;
  dateSelected = false;
  form = this.fb.group({
    date: [],
    bookedFrom: [],
    bookedTo: [],
    optionId: [],
  });

  @Output() dateSelect = new EventEmitter<Date>();
  @Output() durationSelect = this.form.valueChanges.pipe(
    filter(() => this.form.valid)
  );

  @ViewChild('slotScroller')
  set slotScroller(el: ElementRef<HTMLElement>) {
    setTimeout(() => {
      if (el?.nativeElement) {
        el.nativeElement.scrollTop = el.nativeElement.scrollHeight / 2;
      }
      this.cdr.detectChanges();
    });
  }

  constructor(private fb: UntypedFormBuilder, private cdr: ChangeDetectorRef) {}

  onDateSelect(date: Date) {
    this.form.patchValue({
      date,
      bookedFrom: null,
      bookedTo: null,
      optionId: null,
    });
    this.selectedSlotIndex = -1;
    this.availableSlots = getAvailableSlots(
      date,
      this.bookingOptions,
      this.bookedSlots
    );
    this.filteredBookingOptions = filterBookingOptions(
      date,
      this.bookingOptions,
      this.bookedSlots
    );
    this.dateSelected = true;
    this.dateSelect.emit(date);
    this.cdr.detectChanges();
  }

  onChangeDateClick() {
    this.dateSelected = false;
    this.form.patchValue({
      date: null,
      bookedFrom: null,
      bookedTo: null,
      optionId: null,
    });
  }

  selectBookingSlot({ date }: { date?: Date }, index: number) {
    this.selectedSlotIndex = index;
    this.form.patchValue({ bookedFrom: date });
    this.filteredBookingOptions = filterBookingOptions(
      date as Date,
      this.bookingOptions,
      this.bookedSlots
    );
    const selectedOption = this.filteredBookingOptions.find(
      (option) => option.id === this.form.value.optionId
    );
    if (selectedOption) {
      this.selectBookingOption(selectedOption);
    } else {
      this.form.patchValue({ optionId: null, bookedTo: null });
    }
  }

  selectBookingOption(bookingOption: BookingOption) {
    const endDate = new Date(this.form.value.bookedFrom);
    endDate.setMinutes(
      endDate.getMinutes() +
        convertToMinutes(bookingOption.duration, bookingOption.timeUnit)
    );
    this.form.patchValue({ bookedTo: endDate, optionId: bookingOption.id });
  }

  getOptionDisplayValue(bookingOption: BookingOption): string {
    if (bookingOption.duration / 60 < 1) {
      return `${bookingOption.duration} mins`;
    } else {
      const hours = Math.floor(bookingOption.duration / 60);
      const minutes = bookingOption.duration - hours * 60;
      const hhh = hours
        ? translate(`booking.createBooking.hours`, { count: hours })
        : '';
      const mmm = minutes
        ? translate(`booking.createBooking.minutes`, { count: minutes })
        : '';
      return `${hhh} ${mmm}`.trim();
    }
  }
}
