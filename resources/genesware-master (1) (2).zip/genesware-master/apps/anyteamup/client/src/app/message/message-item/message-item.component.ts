import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Message, User } from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-message-item',
  templateUrl: './message-item.component.html',
  styleUrls: ['./message-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MessageItemComponent {
  @Input() message!: Message;
  @Input() groupUsers!: Map<string, User>;
  @Input() displaySender = false;
  @Input() currentUser!: User;
}
