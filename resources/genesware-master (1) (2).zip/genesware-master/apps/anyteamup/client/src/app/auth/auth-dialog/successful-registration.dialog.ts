import { Component, Input } from '@angular/core';
import { User } from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-successful-registration-dialog',
  template: `
    <ion-content>
      <div
        fxLayout="column"
        fxLayoutAlign="center center"
        style="height: 100%"
        (click)="dismiss()"
      >
        <ion-card mode="ios">
          <ion-card-header mode="md">
            <ion-card-title> Registration successful! </ion-card-title>
            <ion-card-subtitle>
              Welcome to AnyTeamup, {{ user?.profile?.firstName }}
              {{ user?.profile?.lastName }}
            </ion-card-subtitle>
          </ion-card-header>
          <ion-card-content mode="md">
            We've sent a confirmation link to email address:
            <span class="email">{{ user?.email }}</span>
            <br />

            Next:
            <div fxLayout="column">
              <ion-button expand="block" shape="round" class="no-text-transform"
                >Select favorite games</ion-button
              >
              <ion-button
                fill="clear"
                expand="block"
                shape="round"
                color="dark"
                class="no-text-transform"
                >Setup later</ion-button
              >
            </div>
          </ion-card-content>
        </ion-card>
      </div>
    </ion-content>
  `,
  styles: [
    `
      ion-content {
        --background: transparent;
        -ion-backdrop-opacity: 0.2;
      }
    `,
  ],
})
export class SuccessfulRegistrationDialog {
  @Input() user!: User;

  constructor(private modalCtrl: ModalController) {}

  dismiss() {
    this.modalCtrl.dismiss();
  }
}
