import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ViewChild,
} from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { AuthQuery } from '@genesware/shared/angular-sdk';
import { NavController } from '@ionic/angular';
import { finalize } from 'rxjs/operators';

import { RegisterFormComponent } from '../../auth/register-form/register-form.component';
import { SettingsService } from '../settings.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.page.html',
  styleUrls: ['./edit-profile.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EditProfilePage {
  loading = false;
  user$ = this.authQuery.user$;

  @ViewChild(RegisterFormComponent) registerForm!: RegisterFormComponent;

  constructor(
    private authQuery: AuthQuery,
    private cdr: ChangeDetectorRef,
    private settingsService: SettingsService,
    private navCtrl: NavController
  ) {}

  async onSubmitForm() {
    if (!this.registerForm) {
      return;
    }
    const { firstName, lastName } = (
      this.registerForm.form.get('profile') as UntypedFormGroup
    ).controls;

    if (firstName.invalid || lastName.invalid) {
      return;
    }

    // This action happens too fast. No need for a loader.
    const loader = await this.presentLoading();
    this.settingsService
      .updateProfile(this.registerForm.value.profile)
      .pipe(finalize(() => loader.dismiss()))
      .subscribe({
        next: this.goBack,
        error: console.error,
      });
  }

  goBack = () => this.navCtrl.back();

  presentLoading() {
    this.loading = true;
    this.cdr.detectChanges();
    return {
      dismiss: () => {
        this.loading = false;
        this.cdr.detectChanges();
      },
    };
  }
}
