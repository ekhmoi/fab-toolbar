import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { MomentModule } from 'ngx-moment';
import { SharedModule } from '../shared/shared.module';
import { NotificationListComponent } from './notification-list/notification-list.component';
import { NotificationsPage } from './notifications.page';

const routes: Routes = [
  {
    path: 'list',
    component: NotificationsPage,
  },
  { path: '', pathMatch: 'full', redirectTo: 'list' },
];

@NgModule({
  declarations: [NotificationsPage, NotificationListComponent],
  imports: [
    CommonModule,
    IonicModule,
    SharedModule,
    TranslocoModule,
    RouterModule.forChild(routes),
    MomentModule,
    FlexLayoutModule,
  ],
  exports: [NotificationsPage],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'notification' }],
})
export class NotificationsModule {}
