import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
} from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { AuthService } from '@genesware/shared/angular-sdk';
import { ToastController } from '@ionic/angular';
import { translate } from '@ngneat/transloco';
import { finalize } from 'rxjs/operators';

import { TOAST_DURATION } from '../../core/constants';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.page.html',
  styleUrls: ['./change-password.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChangePasswordPage {
  loading = false;
  form = new UntypedFormGroup({
    password: new UntypedFormControl('', [Validators.required]),
    newPassword: new UntypedFormControl('', [Validators.required]),
    repeatPassword: new UntypedFormControl('', [Validators.required]),
  });

  constructor(
    private cdr: ChangeDetectorRef,
    private authService: AuthService,
    private toast: ToastController
  ) {}
  visibleInputs = new Map([
    ['password', false],
    ['newPassword', false],
    ['repeatPassword', false],
  ]);

  async onSubmitForm() {
    if (!this.form.valid) {
      return;
    }

    const {
      value: { password, newPassword, repeatPassword },
    } = this.form;
    if (newPassword !== repeatPassword) {
      this.form.get('repeatPassword')?.setErrors({ dontMatch: true });
      return;
    }
    const loader = await this.presentLoading();
    this.authService
      .changePassword(password, newPassword)
      .pipe(
        finalize(async () => {
          await loader.dismiss();
        })
      )
      .subscribe({
        next: async () => {
          const toast = await this.toast.create({
            header: translate('settings.changePassword.success.header'),
            message: translate('settings.changePassword.success.message'),
            duration: TOAST_DURATION,
            color: 'light',
            mode: 'ios',
            position: 'top',
          });
          toast.present();
        },
        error: async ({ error: { message } }) => {
          this.form.get('password')?.setErrors({ incorrect: 'not corrent' });
          this.form.updateValueAndValidity();
          const toast = await this.toast.create({
            header: translate(`error.${message}.header`),
            message: translate(`error.${message}.message`),
            duration: TOAST_DURATION,
            color: 'light',
            mode: 'ios',
            position: 'top',
          });
          toast.present();
        },
      });
  }

  toggleType(inputName: string) {
    this.visibleInputs.set(inputName, !this.visibleInputs.get(inputName));
  }

  hideInputValue(inputName: string) {
    this.visibleInputs.set(inputName, false);
  }

  presentLoading() {
    this.loading = true;
    this.cdr.detectChanges();
    return {
      dismiss: () => {
        this.loading = false;
        this.cdr.detectChanges();
      },
    };
  }
}
