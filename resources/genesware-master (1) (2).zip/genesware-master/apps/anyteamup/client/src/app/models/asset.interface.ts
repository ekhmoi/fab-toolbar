export interface Asset {
  _id: string;
  path: string;
  url: string;
  createdBy: string;
  fileName: string;
  encoding: string;
  mimeType: string;
  size: number;
}