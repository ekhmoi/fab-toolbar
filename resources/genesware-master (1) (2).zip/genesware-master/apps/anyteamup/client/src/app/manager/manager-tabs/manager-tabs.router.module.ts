import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ManagerRoleGuard } from '../../core/guards/user-role.guard';
import { ManagerTabsPage } from './manager-tabs.page';

const routes: Routes = [
  {
    path: '',
    component: ManagerTabsPage,
    children: [
      {
        path: 'company',
        canActivate: [ManagerRoleGuard],
        loadChildren: () =>
          import('../company/company.module').then((m) => m.CompanyModule),
      },
      {
        path: 'chat',
        canActivate: [ManagerRoleGuard],
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../../group/group.module').then((m) => m.GroupModule),
          },
        ],
      },
      {
        path: 'notification',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../../notifications/notifications.module').then(
                (m) => m.NotificationsModule
              ),
          },
        ],
      },
      {
        path: 'settings',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../../settings/settings.module').then(
                (m) => m.SettingsModule
              ),
          },
        ],
      },
      {
        path: '',
        redirectTo: 'company',
        pathMatch: 'full',
      },
    ],
  },
  {
    path: '',
    redirectTo: 'company',
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManagerTabsPageRoutingModule {}
