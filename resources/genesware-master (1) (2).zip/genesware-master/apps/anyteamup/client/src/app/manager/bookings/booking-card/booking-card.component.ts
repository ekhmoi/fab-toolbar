import { DatePipe } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  HostBinding,
  Input,
} from '@angular/core';
import { User } from '@genesware/shared/angular-sdk';
import { ActionSheetController } from '@ionic/angular';
import * as moment from 'moment';

import { Arena } from '../../../arena/state/arena.model';
import { Booking, BookingStatus } from '../../../booking/state/booking.model';

const HOUR_ROW_HEIGHT = 150;

export function calcTop(date: Date) {
  const start = moment(date);
  return (
    start.get('hours') * HOUR_ROW_HEIGHT +
    (HOUR_ROW_HEIGHT * start.get('minutes')) / 60
  );
}

@Component({
  selector: 'app-booking-card',
  templateUrl: './booking-card.component.html',
  styleUrls: ['./booking-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BookingCardComponent {
  @HostBinding('style.top') top = '0px';

  height!: string;

  @Input() arena!: Arena;
  private _booking!: Booking<User>;
  @Input()
  set booking(booking: Booking<User>) {
    this._booking = booking;
    this._setPosition();
  }
  get booking(): Booking<User> {
    return this._booking;
  }

  get isActionsVisible() {
    return this.booking?.status === BookingStatus.Pending;
  }

  constructor(public actionSheetController: ActionSheetController) {}

  private _setPosition() {
    const start = moment(this.booking.bookedFrom);
    const end = moment(this.booking.bookedTo);
    const top = calcTop(this.booking.bookedFrom);
    const durationInMs = end.toDate().getTime() - start.toDate().getTime();

    const height = (durationInMs / 1000 / 60 / 60) * HOUR_ROW_HEIGHT;
    this.top = `${top}px`;
    this.height = `${height}px`;
  }

  async showActions() {
    const datePipe = new DatePipe('en');
    const { firstName, lastName } = this.booking.createdBy.profile;
    const userName = (firstName || '' + lastName || '').trim();
    const from = datePipe.transform(this.booking.bookedFrom, 'hh:mm');
    const to = datePipe.transform(this.booking.bookedTo, 'hh:mm');

    const actionSheet = await this.actionSheetController.create({
      header: `${userName} wants to book ${this.arena.name} for ${from} - ${to}.`,
      cssClass: 'booking-actions',
      buttons: [
        {
          text: 'Reject',
          icon: 'close',
        },
        {
          text: 'Approve',
          icon: 'checkmark',
        },
        {
          text: 'Reply',
          icon: 'chatbubbles',
        },
      ],
    });

    actionSheet.present();
  }
}
