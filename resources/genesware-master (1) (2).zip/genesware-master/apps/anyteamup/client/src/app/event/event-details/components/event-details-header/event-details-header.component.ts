import { Component, Input } from '@angular/core';
import { Event, User } from '@genesware/shared/angular-sdk';
import { EventDetailsService } from '../../event-details.service';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-event-details-header',
  templateUrl: './event-details-header.component.html',
  styleUrls: ['./event-details-header.component.scss'],
})
export class EventDetailsHeaderComponent {
  @Input() isInvisible = false;
  @Input() event!: Event;
  @Input() user!: User;
  @Input() pendingRequestsCount = 0;

  constructor(
    public readonly service: EventDetailsService,
    private modalCtrl: ModalController
  ) {}

  dismiss() {
    this.modalCtrl.dismiss();
  }
}
