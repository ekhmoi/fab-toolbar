import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Category } from '@genesware/shared/angular-sdk';

import { CategoryIconUrlPipe } from '../../pipes';

@Component({
  selector: 'app-category-icon',
  template: `
    <ion-icon
      *ngIf="mode === 'icon'"
      [ngStyle]="{ 'width.px': size, 'height.px': size, 'font-size.px': size }"
      [src]="icon"
      color="darker"
      [ngClass]="classList"
    ></ion-icon>
    <img
      *ngIf="mode === 'image'"
      class="category-image"
      [src]="image"
      [ngStyle]="{
        'width.px': size,
        'height.px': size
      }"
    />
  `,
  styleUrls: ['./category-icon.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CategoryIconComponent {
  image!: string;
  icon!: string;
  classList: string[] = [];
  svgIcon!: string;
  @Input() mode = 'icon';
  @Input() color!: string;
  @Input() set category(category: Category) {
    if (!category) {
      console.warn('WTF MATE?', category);
      return;
    }
    const categoryIconUrlPipe = new CategoryIconUrlPipe();
    this.icon = categoryIconUrlPipe.transform(category.key, 'icon');
    this.image = categoryIconUrlPipe.transform(category.key, 'image');
    this.classList = [category.key];
  }
  @Input() size!: number;
}
