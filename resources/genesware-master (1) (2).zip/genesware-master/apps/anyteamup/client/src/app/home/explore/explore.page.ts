import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  AuthQuery,
  Event,
  EventQuery,
  EventService,
  NotificationQuery,
  UserService as SDKUserService,
} from '@genesware/shared/angular-sdk';
import { MenuController, ModalController } from '@ionic/angular';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';

import { Arena } from '../../arena/state/arena.model';
import { ArenaQuery } from '../../arena/state/arena.query';
import { ArenaService } from '../../arena/state/arena.service';
import { hidePullToRefresh } from '../../core/helpers';
import { UserService } from '../../core/services';
import { CreateEventPage } from '../../event/create-event/create-event.page';
import { EventDetailsPage } from '../../event/event-details/event-details.page';

@Component({
  selector: 'app-explore',
  templateUrl: './explore.page.html',
})
export class ExplorePage implements OnInit {
  locationMessageDismissed = false;
  locationPermissionDenied = false;
  hasUnreadNotification$: Observable<boolean>;

  events$ = this.gameEventQuery.events$;
  eventsLoading$ = this.gameEventQuery.selectLoading();
  maxDistance$ = this.gameEventQuery.select(
    (state) => state.params.maxDistance
  );
  arenas$ = this.arenaQuery.items$;
  arenasLoading$ = this.arenaQuery.loading$;
  isLoggedIn$ = this.authQuery.isLoggedIn$;

  private _currentPosition!: { lat: number; lng: number };

  constructor(
    private modalController: ModalController,
    private menuController: MenuController,
    private gameEventQuery: EventQuery,
    private gameEventService: EventService,
    private sdkUserService: SDKUserService,
    private authQuery: AuthQuery,
    private arenaQuery: ArenaQuery,
    private cdr: ChangeDetectorRef,
    private userService: UserService,
    private arenaService: ArenaService,
    notificationQuery: NotificationQuery
  ) {
    this.hasUnreadNotification$ = notificationQuery.unreadCount$.pipe(
      map((count) => count > 0)
    );
  }
  async ngOnInit() {
    const coords = await this.userService.getCoordinates();
    if (coords) {
      this._currentPosition = coords;
      this.onRefresh();
    }
  }

  async onClickEvent(event: Event) {
    this.gameEventService.setActive(event.id);
    const modal = await this.modalController.create({
      component: EventDetailsPage,
      mode: 'md',
      componentProps: {
        isInModal: true,
      },
    });
    modal.present();
  }

  async onRefresh(event?: any) {
    const params: any =
      this.sdkUserService.getUserPreference('EVENT_PARAMS') || {};
    const selectedCategories: any =
      this.sdkUserService.getUserPreference('SELECTED_CATEGORIES') || [];
    const { lat, lng } = this._currentPosition || { lat: 0, lng: 0 };

    this.arenaService
      .get({
        params: {
          lat,
          lng,
          categories: selectedCategories.join(','),
          sortBy: 'location',
          maxDistance: params.maxDistance || 5,
          date: params.date || new Date().toJSON(),
        },
      })
      .subscribe();
    this.gameEventService
      .setParams(
        { location: { lat, lng }, selectedCategories, ...params },
        true,
        true
      )
      .pipe(
        finalize(() => {
          this.locationPermissionDenied = false;
          this.cdr.detectChanges();
          hidePullToRefresh(event);
        })
      )
      .subscribe();
  }

  async onNoItemActionClick(action: number) {
    switch (action) {
      case 1:
        this.menuController.open('filters');
        break;
      case 2: {
        const modal = await this.modalController.create({
          component: CreateEventPage,
          mode: 'md',
          componentProps: {
            isInModal: true,
          },
        });
        await modal.present();
        break;
      }
      default:
    }
  }

  getUniqueCategories(arenas: Arena[]) {
    return [...new Set(arenas.map((arena) => arena.category))];
  }

  dismissLocationMessage() {
    this.locationMessageDismissed = true;
  }
}
