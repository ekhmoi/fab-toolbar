import { Component, EventEmitter, Input, Output } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';

@Component({
  selector: 'app-message-input',
  templateUrl: './message-input.component.html',
  styleUrls: ['./message-input.component.scss'],
})
export class MessageInputComponent {
  @Output() inputFocus = new EventEmitter<Event>();
  @Output() sendClick = new EventEmitter<string>();
  @Output() addClick = new EventEmitter<string>();

  @Input() isInEvent = false;
  
  control = new UntypedFormControl('');

  onSendMessage(ev: MouseEvent) {
    ev.stopPropagation();
    ev.preventDefault();
    if (this.control.valid) {
      this.sendClick.emit(this.control.value);
      this.control.reset();
    }
  }
}
