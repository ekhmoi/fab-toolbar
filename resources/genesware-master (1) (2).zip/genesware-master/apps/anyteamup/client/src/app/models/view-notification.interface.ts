import { NotificationType } from '@genesware/shared/angular-sdk';

export interface ViewNotification {
  type: NotificationType;
  id: string;
  icon?: string;
  title?: string;
  content?: string;
  imageURL?: string;
  createdAt: string;
  translationParams: any;
  status: string;
  route?: string[];
  queryParams?: any;
}
