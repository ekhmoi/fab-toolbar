import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Company } from '../../state/company.model';

@Component({
  selector: 'app-company-info',
  templateUrl: './company-info.component.html',
  styleUrls: ['./company-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CompanyInfoComponent {
  @Input() company!: Company;
}
