import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'create',
    loadChildren: () => import('./create-event/create-event.module').then((m) => m.CreateEventModule),
  },
  {
    path: 'details/:id',
    loadChildren: () => import('./event-details/event-details.module').then((m) => m.EventDetailsModule),
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EventRoutingModule {}
