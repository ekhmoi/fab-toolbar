import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';

import { Arena } from '../../../../arena/state/arena.model';

@Component({
  selector: 'app-arena-list',
  templateUrl: './arena-list.component.html',
  styleUrls: ['./arena-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ArenaListComponent {
  @Input() arenas: Arena[] = [];
  @Input() loading = false;

  @Output() add = new EventEmitter<void>();
}
