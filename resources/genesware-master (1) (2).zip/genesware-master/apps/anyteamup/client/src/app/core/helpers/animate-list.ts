import { Animation, createAnimation } from '@ionic/angular';
/**
 * Fade in animation for ion-item
 * @selector {string} Use CSS class defined in ion-item
 * @duration {number} Duration of each animation
 * @delayBetweenItems {number} Delay between each item animation
 */
export function animateList(
  selector: string,
  duration: number,
  delayBetweenItems: number
): Promise<any> {
  const animationArray: Animation[] = [];
  const elemArray = document.querySelectorAll(selector);
  for (let i = 0; i <= elemArray.length; i++) {
    const animation: Animation = createAnimation('')
      .addElement(elemArray[i])
      .easing('cubic-bezier(0, 0.55, 0.45, 1)')
      .duration(duration)
      .delay(i * delayBetweenItems)
      .fromTo('opacity', '0', '1');
    animationArray.push(animation);
  }
  return Promise.all(
    animationArray.map((animation: Animation) => {
      return animation.play();
    })
  );
}
