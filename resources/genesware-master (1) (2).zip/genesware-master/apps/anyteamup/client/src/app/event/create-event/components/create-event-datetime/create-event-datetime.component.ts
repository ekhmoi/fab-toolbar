import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Output,
} from '@angular/core';
import { CategoryQuery } from '@genesware/shared/angular-sdk';
import * as moment from 'moment';
import { map } from 'rxjs/operators';

import { BookingOption } from '../../../../booking/state/booking.model';
import { PartOfDay } from '../../../../models/part-of-day.enum';
import { CreateEventService } from '../../create-event.service';

@Component({
  selector: 'app-create-event-datetime',
  templateUrl: './create-event-datetime.component.html',
  styleUrls: ['./create-event-datetime.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateEventDatetimeComponent {
  partsOfDay: {
    value: PartOfDay;
    text: string;
    hourRange: string;
    selected: boolean;
  }[] = [
    {
      value: PartOfDay.Morning,
      text: 'morning',
      hourRange: '5am - 12pm',
      selected: false,
    },
    {
      value: PartOfDay.Afternoon,
      text: 'afternoon',
      hourRange: '12pm - 5 pm',
      selected: false,
    },
    {
      value: PartOfDay.Evening,
      text: 'evening',
      hourRange: '5pm - 9pm',
      selected: false,
    },
    {
      value: PartOfDay.Night,
      text: 'night',
      hourRange: '9pm - 4am',
      selected: false,
    },
  ];
  bookingOptions: BookingOption[] = [];
  minimumDay = moment().add(5, 'hours').toDate();
  bookedSelected = false;
  selectedDate: any;
  submitted$ = this.service.submittedSteps.pipe(map((steps) => steps[3]));

  @Output() dateSelect = new EventEmitter();

  constructor(
    public service: CreateEventService,
    private categoryQuery: CategoryQuery
  ) {
    const selectedCategory: { data: { bookingOptions: BookingOption[] } } =
      this.categoryQuery
        .getAll()
        .find((c) => c.key === this.service.form.value.category) as any;
    if (selectedCategory) {
      this.bookingOptions = (selectedCategory.data.bookingOptions || []).map(
        (o, i) => ({ ...o, id: i.toString() })
      );
    }
  }

  onStartTimeDurationSelect(value: {
    date: Date;
    bookedFrom: Date;
    bookedTo: Date;
  }) {
    this.service.form.patchValue({
      startTime: value.bookedFrom,
      endTime: value.bookedTo,
      date: value.date,
    });
  }

  onClickChange() {
    this.service.goBack();
  }

  setBooked(booked: boolean) {
    this.service.form.patchValue({ booked });
    if (!this.bookedSelected) {
      this.bookedSelected = true;
    }
  }

  togglePOD(part: {
    value: PartOfDay;
    text: string;
    hourRange: string;
    selected: boolean;
  }) {
    const currentPODs: PartOfDay[] =
      this.service.form.value.preferredTimesOfTheDay || [];

    if (currentPODs.includes(part.value)) {
      console.log('Do something when this happens');
    }
    this.service.form.patchValue({
      preferredTimesOfTheDay: currentPODs.includes(part.value)
        ? currentPODs.filter((pod) => pod !== part.value)
        : [...currentPODs, part.value],
    });
  }
}
