import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';

import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginFormComponent {
  public get valid() {
    return this.form.valid;
  }

  get value() {
    return this.form.getRawValue();
  }

  form: UntypedFormGroup;

  @Input() hidePassword = false;
  constructor(fb: UntypedFormBuilder) {
    this.form = fb.group({
      email: [
        environment.production ? '' : 'm@test',
        [Validators.required, Validators.email],
      ],
      password: [
        environment.production ? '' : '123456',
        [Validators.required, Validators.minLength(5)],
      ],
    });
  }
}
