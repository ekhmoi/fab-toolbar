import { EventParams } from '@genesware/shared/angular-sdk';

export const DEFAULT_EVENT_PARAMS: EventParams = new EventParams({
  sortBy: 'location',
  selectedCategories: [],
});
