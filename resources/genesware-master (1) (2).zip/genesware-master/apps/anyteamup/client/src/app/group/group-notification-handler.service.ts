import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {
  AuthQuery,
  EventQuery,
  EventService,
  EventStore,
  Group,
  GroupService,
  Notification,
  NotificationQuery,
  NotificationService,
  NotificationType,
  User,
} from '@genesware/shared/angular-sdk';
import {
  ModalController,
  NavController,
  ToastController,
} from '@ionic/angular';
import { translate } from '@ngneat/transloco';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

import { TOAST_DURATION } from '../core/constants';
import { UserInfoComponent } from '../user/user-info/user-info.component';

@Injectable({
  providedIn: 'root',
})
export class GroupNotificationHandlerService {
  subs: Subscription[] = [];

  notificationTypesToHandle = [
    NotificationType.JoinGroupRequestReceived,
    NotificationType.JoinGroupRequestRejected,
    NotificationType.JoinGroupRequestAccepted,
    NotificationType.RemovedFromGroup,
  ];

  constructor(
    private modalController: ModalController,
    private toastController: ToastController,
    private notificationQuery: NotificationQuery,
    private groupService: GroupService,
    private eventService: EventService,
    private eventStore: EventStore,
    private eventQuery: EventQuery,
    private notificationService: NotificationService,
    private router: Router,
    private navController: NavController,
    private authQuery: AuthQuery
  ) {}

  subscribeToNotifications() {
    this.subs.push(
      this.notificationQuery
        .selectLast()
        .pipe(
          filter((n) => {
            if (!n) {
              return false;
            }

            return (
              this.notificationTypesToHandle.includes(n.type) &&
              !n.isReceived &&
              n.status !== 'read'
            );
          })
        )
        .subscribe((notification) => {
          const n = notification as unknown as Notification<{
            requestId: string;
          }>;
          this.notificationService
            .update(n.id, { isReceived: true }, { skipWrite: true })
            .subscribe();
          switch (n.type) {
            case NotificationType.JoinGroupRequestReceived:
              this.handleJoinGroupRequestReceived(n);
              break;
            case NotificationType.JoinGroupRequestAccepted:
              this.handleJoinGroupRequestAccepted(n);
              break;
            case NotificationType.JoinGroupRequestRejected:
              this.handleJoinGroupRequestRejected(n);
              break;
            case NotificationType.RemovedFromGroup:
              this.handleRemovedFromGroup(n);
              break;

            default:
              break;
          }
        })
    );
  }

  async handleJoinGroupRequestRejected(
    notification: Notification<{ requestId: string }>
  ) {
    const message = translate<string>(
      'notification.JoinGroupRequestRejected.toast.message',
      {
        title: notification.relatedDocument.title,
      }
    );
    const header = translate<string>(
      'notification.JoinGroupRequestRejected.toast.header'
    );
    this.toast(message, header);
  }

  async handleJoinGroupRequestAccepted(
    notification: Notification<{ requestId: string }, Group>
  ) {
    const message = translate<string>(
      'notification.JoinGroupRequestAccepted.toast.message',
      {
        title: notification.relatedDocument.title,
      }
    );
    const toast = await this.toast(
      message,
      translate<string>('notification.JoinGroupRequestAccepted.toast.header')
    );
    this.eventService.getUserEvents().subscribe();
    this.groupService.get(notification.relatedDocumentId).subscribe();
    toast.onclick = () =>
      this.router.navigate([
        '/group',
        'details',
        notification.relatedDocumentId,
      ]);
  }

  async handleJoinGroupRequestReceived(
    notification: Notification<{ requestId: string }>
  ) {
    // Get user who requested to join and display correct toast message
    const { initiator: user, relatedDocument: group } = notification;
    const message = translate<string>(
      'notification.JoinGroupRequestReceived.toast.message',
      {
        playerName: `${user.profile.firstName} ${user.profile.lastName}`,
      }
    );
    const header = translate<string>(
      'notification.JoinGroupRequestReceived.toast.header'
    );
    const toast = await this.toast(message, header);

    toast.onclick = async (ev) => {
      toast.dismiss();
      this.openUserInfo(user, group, true);
    };

    toast.present();
  }

  async openUserInfo(user: User, group: Group, isUserInPending: boolean) {
    const modal = await this.modalController.create({
      component: UserInfoComponent,
      componentProps: {
        user,
        group: group,
        currentUser: this.authQuery.getValue().user,
        isUserInPending,
      },
      cssClass: 'transparent-modal',
      keyboardClose: true,
    });

    return await modal.present();
  }

  async handleRemovedFromGroup(n: Notification) {
    if (this.router.isActive(`/group/details/${n.relatedDocumentId}`, false)) {
      this.navController.back();
    }
    const event = this.eventQuery
      .getAll()
      .find((event) => event.group.id === n.relatedDocumentId);
    if (event) {
      this.eventStore.remove(event.id);
    }
    await this.toast(
      'You have been removed from group...',
      'Removed from group'
    );
  }

  async toast(message: string, header: string) {
    const toast = await this.toastController.create({
      header,
      message,
      mode: 'ios',
      duration: TOAST_DURATION,
      position: 'top',
      color: 'light',
    });
    toast.present();
    return toast;
  }
}
