import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ModalController, ToastController } from '@ionic/angular';
import { translate, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import * as moment from 'moment';
import { share, switchMap, tap } from 'rxjs/operators';
import {
  AuthQuery,
  Event,
  EventService,
  EventStore,
  Group,
} from '@genesware/shared/angular-sdk';

import { TOAST_DURATION } from '../../core/constants';
import { EventDetailsPage } from '../../event/event-details/event-details.page';
import { CreateBookingComponent } from '../../booking/create-booking/create-booking.component';
import { Arena } from '../state/arena.model';
import { ArenaService } from '../state/arena.service';

@Component({
  selector: 'app-arena-details',
  templateUrl: './arena-details.component.html',
  styleUrls: ['./arena-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'arena' }],
})
export class ArenaDetailsComponent implements OnInit {
  private _arena!: Arena;
  arena$ = this.service.get<Arena>(this.route.snapshot.paramMap.get('id')).pipe(
    share(),
    tap((arena) => (this._arena = arena))
  );
  events: Event[] = [];
  id!: string;
  userId = this.authQuery.getValue()?.user?.id;

  constructor(
    private service: ArenaService,
    private route: ActivatedRoute,
    private eventService: EventService,
    private eventStore: EventStore,
    private modalController: ModalController,
    private cdr: ChangeDetectorRef,
    private authQuery: AuthQuery,
    private toastr: ToastController
  ) {}

  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id') as string;
    this.service.setActive(this.id);
    this.loadEvents().subscribe();
  }

  isUserInGroup(group: Group) {
    return group.users
      .map((user) => user.id || (user as any as string))
      .includes(this.userId);
  }

  loadEvents() {
    return this.service.getArenaEvents(this.id).pipe(
      tap((events) => {
        this.events = events;
        this.cdr.detectChanges();
      })
    );
  }

  async onClickBook() {
    const modal = await this.modalController.create({
      component: CreateBookingComponent,
      mode: 'md',
      componentProps: {
        arena: this._arena,
      },
    });
    modal.present();

    const dismissResponse = await modal.onDidDismiss();

    if (dismissResponse.data) {
      this.service
        .createArenaEvent(this.id, dismissResponse.data)
        .pipe(
          tap(async (event) => {
            const startDate = moment(event.startTime);
            const startTime = startDate.format('HH:mm');
            const endTime = moment(event.endTime).format('HH:mm');

            const toast = await this.toastr.create({
              header: translate('arena.arenaDetails.bookingSuccess.header'),
              message: translate('arena.arenaDetails.bookingSuccess.message', {
                place: event.location.name,
                date: startDate.format('MMM d'),
                from: startTime,
                to: endTime,
              }),
              mode: 'ios',
              duration: TOAST_DURATION,
              position: 'top',
              color: 'light',
              buttons: ['ok'],
            });
            toast.present();
          }),
          switchMap(() => this.loadEvents())
        )
        .subscribe(
          (events) => this.eventStore.upsertMany(events),
          (err) => console.error(err)
        );
    }
  }

  async onClickEvent(event: Event) {
    this.eventService.setActive(event.id);
    const modal = await this.modalController.create({
      component: EventDetailsPage,
      mode: 'md',
      componentProps: {
        isInModal: true,
      },
    });
    modal.present();

    modal.onDidDismiss().then(() => {
      this.eventService.setActive(null);
    });
  }
}
