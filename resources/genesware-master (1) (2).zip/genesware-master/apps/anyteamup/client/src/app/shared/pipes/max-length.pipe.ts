import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'maxLength'
})
export class MaxLengthPipe implements PipeTransform {

  transform(value: string, maxLength: number): unknown {
    if (!value || value.length <= maxLength) {
      return value;
    } else {
      return `${value.substring(0, maxLength)}...`;
    }
  }
}
