import { TranslocoModule } from '@ngneat/transloco';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatMenuModule } from '@angular/material/menu';

import {
  ButtonComponent,
  CategoryGridComponent,
  CategoryIconComponent,
  CurrencyComponent,
  EmptyPageComponent,
  InfoIconComponent,
  InfoPopoverComponent,
  SelectedArenaInfoComponent,
  CardSegmentComponent,
  HeaderSelectorComponent,
  StartDurationSelectorComponent,
  MessageInputModalComponent,
  AvatarComponent,
} from './components';
import { MaxLengthPipe, AssetUrlPipe, CategoryIconUrlPipe, CategoryPipe } from './pipes';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [
    ButtonComponent,
    CategoryIconComponent,
    MaxLengthPipe,
    CurrencyComponent,
    EmptyPageComponent,
    AssetUrlPipe,
    InfoIconComponent,
    InfoPopoverComponent,
    CategoryIconUrlPipe,
    SelectedArenaInfoComponent,
    StartDurationSelectorComponent,
    HeaderSelectorComponent,
    CardSegmentComponent,
    CategoryGridComponent,
    CategoryPipe,
    MessageInputModalComponent,
    AvatarComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    TranslocoModule,
    IonicModule,
    FlexLayoutModule,
    MatDatepickerModule,
    MatMenuModule,
    MatIconModule,
  ],
  exports: [
    ReactiveFormsModule,
    FormsModule,
    ButtonComponent,
    CategoryIconComponent,
    FlexLayoutModule,
    MaxLengthPipe,
    CurrencyComponent,
    EmptyPageComponent,
    AssetUrlPipe,
    TranslocoModule,
    IonicModule,
    InfoIconComponent,
    InfoPopoverComponent,
    CategoryIconUrlPipe,
    SelectedArenaInfoComponent,
    StartDurationSelectorComponent,
    HeaderSelectorComponent,
    CardSegmentComponent,
    CategoryGridComponent,
    CategoryPipe,
    MatIconModule,
    MessageInputModalComponent,
    AvatarComponent,
  ],
})
export class SharedModule {}
