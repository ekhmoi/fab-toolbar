import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { AuthModule } from '../auth/auth.module';
import { WelcomePage } from './welcome.page';

const routes: Routes = [
  {
    path: '',
    component: WelcomePage,
  },
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes),
    TranslocoModule,
    AuthModule,
  ],
  declarations: [WelcomePage],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'welcome' }],
})
export class WelcomePageModule {}
