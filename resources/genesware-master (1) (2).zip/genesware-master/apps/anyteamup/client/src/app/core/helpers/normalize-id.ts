export function normalizeId(id: string) {
  if (id.startsWith('-')) {
    return id.substr(1, id.length - 2);
  }
  return id;
}
