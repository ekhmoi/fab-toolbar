import { CommonModule } from '@angular/common';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { AuthModule } from '../auth/auth.module';
import { MessageModule } from '../message/message.module';
import { SharedModule } from '../shared/shared.module';
import { UserModule } from '../user/user.module';

import {
  EventListComponent,
  EventListItemComponent,
  EventUserReviewComponent,
  RequestGameReviewComponent,
} from './components';
import { EventRoutingModule } from './event-routing.module';

@NgModule({
  declarations: [
    EventListComponent,
    RequestGameReviewComponent,
    EventUserReviewComponent,
    EventListItemComponent,
  ],
  exports: [
    EventListComponent,
    RequestGameReviewComponent,
    EventListItemComponent,
  ],
  imports: [
    EventRoutingModule,
    AuthModule,
    UserModule,
    SharedModule,
    CommonModule,
    MessageModule,
    MatDatepickerModule,
    MatNativeDateModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatInputModule,
  ],
  providers: [
    { provide: TRANSLOCO_SCOPE, useValue: 'game-event' },
  ],
  schemas: [NO_ERRORS_SCHEMA],
})
export class EventModule {}
