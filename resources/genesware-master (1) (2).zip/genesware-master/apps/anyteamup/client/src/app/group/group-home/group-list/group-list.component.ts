import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import {
  Event,
  EventQuery,
  EventService,
  Group,
  GroupService,
  User,
} from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';
import { EventDetailViewMode } from '../../../event/event-details/components';
import { EventDetailsPage } from '../../../event/event-details/event-details.page';

@Component({
  selector: 'app-group-list',
  templateUrl: './group-list.component.html',
  styleUrls: ['./group-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GroupListComponent {
  @Input() groups: Group[] = [];
  @Input() currentUser!: User;

  constructor(
    private groupService: GroupService,
    private router: Router,
    private eventService: EventService,
    private modalController: ModalController,
    private eventQuery: EventQuery
  ) {}

  async onGroupClick(group: Group) {
    const parentEvent = this.eventQuery
      .getAll()
      .find((ev) => ev.group.id === group.id);

    if (parentEvent) {
      this.onClickEvent(parentEvent);
    } else {
      this.groupService.setActive(group.id);
      this.router.navigate(['/group', 'details', group.id]);
    }
  }

  async onClickEvent(event: Event) {
    this.eventService.setActive(event.id);
    const modal = await this.modalController.create({
      component: EventDetailsPage,
      mode: 'md',
      componentProps: {
        isInModal: true,
        queryParamTab: EventDetailViewMode.Chat,
      },
    });
    modal.present();
  }
}
