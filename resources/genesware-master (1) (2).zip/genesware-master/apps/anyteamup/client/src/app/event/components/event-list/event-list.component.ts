import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Event } from '@genesware/shared/angular-sdk';

import { CreateEventPage } from '../../create-event/create-event.page';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventListComponent {
  animated = false;
  private _events: Event[] = [];
  @Input() title = '';
  @Input() loading = false;
  @Input() mini = false;
  @Input() set events(events: Event[]) {
    this._events = events || [];
    this.cdr.detectChanges();
  }
  get events() {
    return this._events;
  }
  @Output() eventClick = new EventEmitter<Event>();

  constructor(
    private modalCtrl: ModalController,
    private cdr: ChangeDetectorRef
  ) {}

  async onClickCreateEvent() {
    const modal = await this.modalCtrl.create({
      component: CreateEventPage,
    });
    return await modal.present();
  }

  trackByFn(index: number, event: Event) {
    return event.id;
  }
}
