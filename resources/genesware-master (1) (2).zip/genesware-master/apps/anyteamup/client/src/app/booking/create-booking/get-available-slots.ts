import { TimeUnit } from 'chart.js';
import * as moment from 'moment';
import { Booking, BookingOption } from '../state/booking.model';

export function filterBookingOptions(
  date: Date,
  bookingOptions: BookingOption[],
  bookedSlots: Partial<Booking>[]
): BookingOption[] {
  const startDate = moment(date);
  return bookingOptions.filter(
    (option) =>
      !getOverlappingBookedSlot(
        startDate,
        moment(startDate).add(
          convertToMinutes(option.duration, option.timeUnit),
          'minutes'
        ),
        bookedSlots
      )
  );
}

export function getAvailableSlots(
  selectedDate: Date,
  bookingOptions: BookingOption[],
  bookedSlots: Partial<Booking>[],
  divideSlotsBy = 15
): { date?: Date; bookedFrom?: Date; bookedTo?: Date }[] {
  const date = moment(selectedDate);

  // find the BookingOption with the smallest duration
  const smallestDuration =
    Math.min(
      ...bookingOptions.map((option) =>
        convertToMinutes(option.duration, option.timeUnit)
      )
    ) || 15;

  const now = new Date();
  if (date.isSame(now, 'day')) {
    // If selected day is today set minutes and hours as current time
    date.minutes(now.getMinutes());
    date.hours(now.getHours());
  }

  return getNextAvailableSlot(
    date,
    moment(date),
    divideSlotsBy,
    smallestDuration,
    [],
    bookedSlots
  );
}

export function convertToMinutes(duration: number, timeUnit: TimeUnit) {
  switch (timeUnit) {
    case 'millisecond':
      return duration / 1000 / 60;
    case 'second':
      return duration / 60;
    case 'minute':
      return duration;
    case 'hour':
      return duration * 60;
    case 'day':
      return duration * 60 * 24;
    case 'week':
      return duration * 60 * 24 * 7;
    case 'month':
      return duration * 60 * 24 * 30;
    case 'year':
      return duration * 60 * 24 * 365;

    default:
      return duration;
  }
}

function getNextAvailableSlot(
  selectedDate: moment.Moment,
  date: moment.Moment,
  division: number,
  smallestDuration: number,
  initialSlots: { date?: Date; bookedFrom?: Date; bookedTo?: Date }[],
  bookedSlots: Partial<Booking>[] = []
): { date?: Date; bookedFrom?: Date; bookedTo?: Date }[] {
  // check if this date + minimum BookedOption overlaps with any bookedSlots
  const startTime = moment(date);
  const startMinutes = Math.ceil(startTime.minutes() / division) * division;
  startTime.minutes(startMinutes);
  const endTime = moment(startTime).add(smallestDuration, 'minutes');

  const stillTodayAfterSlot = moment(startTime)
    .add(division, 'minutes')
    .isSame(selectedDate, 'day');

  const overlappingBooking = getOverlappingBookedSlot(
    startTime,
    endTime,
    bookedSlots
  );
  if (!overlappingBooking && stillTodayAfterSlot) {
    initialSlots.push({ date: startTime.toDate() });
  } else if (overlappingBooking) {
    const lastSlot = initialSlots[initialSlots.length - 1];

    if (lastSlot.bookedFrom && lastSlot.bookedTo) {
      lastSlot.bookedTo = overlappingBooking.bookedTo;
    } else {
      initialSlots.push({
        bookedFrom: overlappingBooking.bookedFrom,
        bookedTo: overlappingBooking.bookedTo,
      });
    }
  }

  if (stillTodayAfterSlot) {
    date.add(division, 'minutes');
    return getNextAvailableSlot(
      selectedDate,
      date,
      division,
      smallestDuration,
      initialSlots,
      bookedSlots
    );
  } else {
    return initialSlots;
  }
}

function getOverlappingBookedSlot(
  startTime: moment.Moment,
  endTime: moment.Moment,
  bookedSlots: Partial<Booking>[]
): Partial<Booking> {
  return bookedSlots.find((booking) => {
    const bookedFrom =
      booking.bookedFrom && moment(new Date(booking.bookedFrom));
    const bookedTo = booking.bookedTo && moment(new Date(booking.bookedTo));

    const startOverlaps =
      // There can be three options
      // - startTime is before booking start date and endTime is after booking start date
      (startTime.isSameOrBefore(bookedFrom) && endTime.isAfter(bookedFrom)) ||
      // - startTime is after booking start date and startTime is before booking end date
      (startTime.isAfter(bookedFrom) && startTime.isBefore(bookedTo));
    // And these two in which there is no overlap, so we ignore them.
    // + startTime is before booking start date and endTime is before booking start date
    // + startTime is after booking start date and is after booking end date

    return startOverlaps; // startTimeOverlaps || endTimeOverlaps;
  }) as Partial<Booking>;
}
