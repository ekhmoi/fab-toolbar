import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { Group } from '@genesware/shared/angular-sdk';
import { skip } from 'rxjs/operators';

@Component({
  selector: 'app-group-no-message',
  templateUrl: './group-no-message.component.html',
  styleUrls: ['./group-no-message.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GroupNoMessageComponent {
  approveNewUsersControl = new UntypedFormControl(null);
  private _group!: Group;
  @Input() set group(group: Group) {
    this._group = group;

    if (this.approveNewUsersControl.value === null && group) {
      this.approveNewUsersControl.setValue(!group.approveNewUsers, {
        emitEvent: false,
      });
    }
  }

  @Output() createLinkClick = new EventEmitter();
  @Output() enableLinkClick = new EventEmitter();
  @Output() shareClick = new EventEmitter();
  @Output() approveToggle = new EventEmitter();

  constructor() {
    this.approveNewUsersControl.valueChanges.pipe(skip(1)).subscribe((val) => {
      if (this.group.token) {
        this.approveToggle.emit(!val);
      }
    });
  }
}
