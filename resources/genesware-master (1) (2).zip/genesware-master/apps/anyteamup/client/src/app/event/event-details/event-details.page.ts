import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  AuthQuery,
  EventQuery,
  EventService,
  RequestQuery,
  RequestStatus,
} from '@genesware/shared/angular-sdk';
import { IonRefresher } from '@ionic/angular';
import { combineLatest } from 'rxjs';
import { finalize, map } from 'rxjs/operators';
import { EventDetailViewMode } from './components';
import { EventDetailsService } from './event-details.service';

@Component({
  selector: 'app-event-details',
  template: `<app-event-details-content
    [event]="(event$ | async)!"
    [requests]="(requests$ | async)!"
    [user]="(user$ | async)!"
    [queryParamTab]="queryParamTab!"
    (refresh)="onRefresh($event)"
  ></app-event-details-content>`,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventDetailsPage implements OnInit {
  user$ = this.authQuery.user$;
  event$ = this.eventQuery.active$;
  requests$ = combineLatest([this.event$, this.requestQuery.selectAll()]).pipe(
    map(
      ([
        {
          group: { id },
        },
        requests,
      ]) =>
        requests.filter(
          (r) =>
            r.status === RequestStatus.Pending &&
            r.requestedForDocumentId === id
        )
    )
  );

  queryParamTab: EventDetailViewMode | null = null;

  constructor(
    public readonly service: EventDetailsService,
    private authQuery: AuthQuery,
    private eventQuery: EventQuery,
    private eventService: EventService,
    private route: ActivatedRoute,
    private requestQuery: RequestQuery
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id') || null;
    if (id && !this.eventQuery.getActive()) {
      this.eventService.setActive(id);
    }

    const tab = this.route.snapshot.queryParamMap.get(
      'tab'
    ) as EventDetailViewMode;
    this.queryParamTab = tab || null;
  }

  onRefresh(event?: { target: IonRefresher }) {
    this.eventService
      .byId(this.eventQuery.getActiveId(), true)
      .pipe(
        finalize(() => {
          event && event.target.complete();
        })
      )
      .subscribe();
  }
}
