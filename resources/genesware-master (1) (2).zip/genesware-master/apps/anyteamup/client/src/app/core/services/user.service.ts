import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoginResponse, User } from '@genesware/shared/angular-sdk';
import { Geolocation } from '@capacitor/geolocation';

import { Observable, of } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private params: { [key: string]: any } = {
    WELCOME_PRESENTED: false,
  };

  private _cachedCoordinates: { lat: number; lng: number } | null = null;
  private get _resourceURI() {
    return `${environment.gatewayUrl}/users`;
  }

  constructor(private http: HttpClient) {
    this.loadParams();
  }

  async getCoordinates(): Promise<{ lat: number; lng: number } | null> {
    return Geolocation.getCurrentPosition()
      .then((value) => {
        try {
          return {
            lat: value.coords.latitude,
            lng: value.coords.longitude,
          };
        } catch (e) {
          return null;
        }
      })
      .catch((e) => {
        return this.getApproximateCoordinates()
          .then((approximateCoordinates) =>
            approximateCoordinates
              ? {
                  lat: approximateCoordinates.latitude,
                  lng: approximateCoordinates.longitude,
                }
              : null
          )
          .catch((err) => {
            return null;
          });
      })
      .then((coords) => {
        this._cachedCoordinates = coords;
        return coords;
      });
  }

  getCachedCoordinates() {
    return this._cachedCoordinates;
  }

  async getApproximateCoordinates() {
    return this.http.get<{ longitude: number; latitude: number }>(`${environment.gatewayUrl}/users/geoip`).toPromise();
  }

  login({ email, password }: { email: string; password: string }) {
    return this.http.post<LoginResponse>(`${this._resourceURI}/token`, {
      email,
      password,
    });
  }

  getUserInfo(id?: string) {
    return this.http.get<User>(`${this._resourceURI}${id ? '/' + id : ''}`);
  }

  register(body: Partial<User>) {
    return this.http.post<User>(this._resourceURI, body);
  }

  changePassword(password: string, newPassword: string) {
    return this.http.put(`${this._resourceURI}/password`, {
      password,
      newPassword,
    });
  }

  getParam<T>(param: string): Observable<T> {
    return of(this.params[param]);
  }

  setParam(param: string, value: any): Observable<any> {
    this.params[param] = value;
    this.storeParams();
    return of();
  }

  private loadParams() {
    this.params = JSON.parse(localStorage.getItem('USER_PARAMS') || '{}');
  }

  private storeParams() {
    localStorage.setItem('USER_PARAMS', JSON.stringify(this.params || {}));
  }
}
