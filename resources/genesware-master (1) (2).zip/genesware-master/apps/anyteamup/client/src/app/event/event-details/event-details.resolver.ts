import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  Resolve,
  RouterStateSnapshot,
} from '@angular/router';
import {
  CategoryQuery,
  CategoryService,
  Event,
  EventService,
  GroupService,
} from '@genesware/shared/angular-sdk';
import { of } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

@Injectable()
export class EventDetailsResolver implements Resolve<Event> {
  constructor(
    private eventService: EventService,
    private categoryService: CategoryService,
    private groupService: GroupService,
    private categoryQuery: CategoryQuery
  ) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const id = route.paramMap.get('id');
    this.eventService.setActive(id);
    const categoriesCount = this.categoryQuery.getCount();
    return this.eventService.byId(id as string, true).pipe(
      switchMap((event) => {
        return categoriesCount
          ? of(event)
          : this.categoryService.get().pipe(map(() => event));
      }),
      switchMap((event) =>
        this.groupService.get(event.group.id).pipe(map(() => event))
      )
    );
  }
}
