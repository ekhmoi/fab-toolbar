import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { IonicModule } from '@ionic/angular';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { AuthModule } from '../auth/auth.module';
import { EventDetailsModule } from '../event/event-details/event-details.module';
import { EventModule } from '../event/event.module';
import { GroupModule } from '../group/group.module';
import { SharedModule } from '../shared/shared.module';

import { HomeMenuComponent, PreviousEventsListComponent } from './components';
import { ExplorePage } from './explore/explore.page';
import { HomePage } from './home.page';
import { UserGamesPage } from './user-games.page';
import { MomentModule } from 'ngx-moment';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SharedModule,
    RouterModule,
    EventModule,
    TranslocoModule,
    GroupModule,
    MatIconModule,
    EventDetailsModule,
    AuthModule,
    MomentModule,
  ],
  declarations: [
    HomePage,
    HomeMenuComponent,
    UserGamesPage,
    ExplorePage,
    PreviousEventsListComponent,
  ],
  exports: [HomeMenuComponent],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'home' }],
})
export class HomePageModule {}
