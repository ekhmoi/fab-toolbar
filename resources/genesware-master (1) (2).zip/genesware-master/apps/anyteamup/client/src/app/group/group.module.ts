import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { MomentModule } from 'ngx-moment';

import { MessageModule } from '../message/message.module';
import { SharedModule } from '../shared/shared.module';
import { UserModule } from '../user/user.module';
import { CreateGroupPage } from './create-group/create-group.page';
import { GroupDetailPage } from './group-detail/group-detail.page';
import { GroupNoMessageComponent } from './group-detail/group-no-message/group-no-message.component';
import { GroupHomePage } from './group-home/group-home.page';
import { GroupListComponent } from './group-home/group-list/group-list.component';
import { GroupOptionsComponent } from './group-options/group-options.component';
import { GroupSettingsPage } from './group-settings/group-settings.page';
import { JoinGroupLinkPipe } from './join-group-link.pipe';

const routes: Routes = [
  {
    path: 'list',
    component: GroupHomePage,
  },
  {
    path: 'details/:id',
    component: GroupDetailPage,
  },

  { path: '', pathMatch: 'full', redirectTo: 'list' },
];

@NgModule({
  declarations: [
    GroupListComponent,
    GroupDetailPage,
    CreateGroupPage,
    GroupHomePage,
    GroupSettingsPage,
    JoinGroupLinkPipe,
    GroupOptionsComponent,
    GroupNoMessageComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    IonicModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MessageModule,
    TranslocoModule,
    MatIconModule,
    MomentModule,
    UserModule,
  ],
  exports: [GroupListComponent],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'group' }],
})
export class GroupModule {}
