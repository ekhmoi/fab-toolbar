import {
  ChangeDetectionStrategy,
  Component,
  Input,
  Output,
} from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { DEFAULT_LANGUAGE } from '../../models/language.enum';

@Component({
  selector: 'app-application-settings',
  templateUrl: './application-settings.component.html',
  styleUrls: ['./application-settings.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ApplicationSettingsComponent {
  themeControl = new UntypedFormControl('auto');
  languageControl = new UntypedFormControl(DEFAULT_LANGUAGE);
  @Input()
  public set theme(theme: any) {
    this.themeControl.setValue(theme, { emitEvent: false });
  }
  @Input()
  public set language(language: string) {
    this.languageControl.setValue(language, { emitEvent: false });
  }

  @Output() changeTheme = this.themeControl.valueChanges.pipe(
    debounceTime(100),
    distinctUntilChanged()
  );
  @Output() changeLanguage = this.languageControl.valueChanges.pipe(
    debounceTime(100),
    distinctUntilChanged()
  );
}
