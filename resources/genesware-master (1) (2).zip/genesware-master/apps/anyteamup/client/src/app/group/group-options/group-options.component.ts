import { Component, Input, OnInit } from '@angular/core';
import { AuthQuery, Group, User } from '@genesware/shared/angular-sdk';
import { PopoverController } from '@ionic/angular';

import { GroupManagerService } from '../group-manager.service';
import { GroupSettingsPage } from '../group-settings/group-settings.page';

@Component({
  selector: 'app-group-options',
  templateUrl: './group-options.component.html',
  styleUrls: ['./group-options.component.scss'],
})
export class GroupOptionsComponent implements OnInit {
  loggedUser!: User;
  @Input() group!: Group;

  constructor(
    public manager: GroupManagerService,
    private authQuery: AuthQuery,
    private popoverController: PopoverController
  ) {}

  get isOwner() {
    return this.group?.createdBy.id === this.loggedUser?.id;
  }

  ngOnInit() {
    this.loggedUser = this.authQuery.getValue().user;
  }

  share() {
    this.manager.share(this.group.id);
    this.popoverController.dismiss();
  }

  leave() {
    this.manager.leave(this.group);
    this.popoverController.dismiss();
  }

  openSettings() {
    this.manager.openGroupModal(GroupSettingsPage);
    this.popoverController.dismiss();
  }
}
