import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { ArenaDetailsComponent, ArenaDetailsModule } from './arena-details';
import { CompanyDetailsComponent, CompanyDetailsModule } from './company-details';

@NgModule({
  imports: [
    CompanyDetailsModule,
    ArenaDetailsModule,
    RouterModule.forChild([
      { path: '', component: CompanyDetailsComponent },
      { path: 'arena/:id', component: ArenaDetailsComponent },
    ]),
  ],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'company' }],
})
export class CompanyModule {}
