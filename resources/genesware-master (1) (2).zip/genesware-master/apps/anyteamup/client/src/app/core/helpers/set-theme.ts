import { StatusBar, Style } from '@capacitor/status-bar';

export function setTheme(theme: 'dark' | 'light' | 'auto') {
  try {
    const root = document.querySelector('html');
    if (root) {
      if (theme === 'auto') {
        root.classList.remove('dark');
        root.classList.remove('light');
      } else {
        root.classList.remove(theme === 'dark' ? 'light' : 'dark');
        root.classList.add(theme === 'dark' ? 'dark' : 'light');
      }
    }
    if (typeof (window as any)['NavigationBar'] !== 'undefined') {
      if (theme === 'dark') {
        StatusBar.setBackgroundColor({ color: '#121212' });
        StatusBar.setStyle({ style: Style.Dark });
        setBottomBarColor('#222428', false);
      } else {
        StatusBar.setBackgroundColor({ color: '#ffffff' });
        StatusBar.setStyle({ style: Style.Light });
        setBottomBarColor('#f4f5f8', true);
      }
    }
  } catch (err) {
    console.log('Cannot set theme - not running in mobile environment.');
  }
}

export function setBottomBarColor(color: string, isLight = false) {
  try {
    (window as any)['NavigationBar'].backgroundColorByHexString(color, isLight);
  } catch (err) {}
}
