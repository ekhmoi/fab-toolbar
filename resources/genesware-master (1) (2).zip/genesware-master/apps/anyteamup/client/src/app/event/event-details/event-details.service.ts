import { Injectable } from '@angular/core';
import { Share } from '@capacitor/share';
import {
  EventService,
  EventStatus,
  Group,
  GroupQuery,
  MessageService,
} from '@genesware/shared/angular-sdk';
import { GroupManagerService } from '../../group/group-manager.service';
import { GroupOptionsComponent } from '../../group/group-options/group-options.component';
import { GroupSettingsPage } from '../../group/group-settings/group-settings.page';

@Injectable({
  providedIn: 'root',
})
export class EventDetailsService {
  constructor(
    private groupManager: GroupManagerService,
    private groupQuery: GroupQuery,
    private messageService: MessageService,
    private eventService: EventService
  ) {}

  showOptions(ev: MouseEvent) {
    this.groupManager.showGroupPopover(
      GroupOptionsComponent,
      this.groupQuery.getActive() as Group,
      ev
    );
  }

  openSettings() {
    this.groupManager.openGroupModal(GroupSettingsPage);
  }

  sendMessage(message: string, groupId: string) {
    this.messageService.sendMessage(message, groupId);
  }

  join(groupId: string) {
    this.eventService.joinEvent(groupId).subscribe();
  }

  updateStatus(id: string, status: EventStatus) {
    this.eventService.updateStatus(id, status).subscribe();
  }

  async share(eventId: string) {
    await Share.share({ url: `https://anyteamup.com/join/${eventId}` });
  }
}
