import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { IonicModule } from '@ionic/angular';
import { TranslocoModule } from '@ngneat/transloco';
import { MomentModule } from 'ngx-moment';

import { SharedModule } from '../shared/shared.module';
import { UserModule } from '../user/user.module';
import { GroupMessagesComponent } from './group-messages/group-messages.component';
import { MessageInputComponent } from './message-input/message-input.component';
import { MessageItemComponent } from './message-item/message-item.component';
import {
  AudioMessageItemComponent,
  ImageMessageItemComponent,
  NotificationMessageItemComponent,
  TextMessageItemComponent,
  VideoMessageItemComponent,
} from './message-item/message-parts';

@NgModule({
  declarations: [
    MessageItemComponent,
    GroupMessagesComponent,
    VideoMessageItemComponent,
    TextMessageItemComponent,
    NotificationMessageItemComponent,
    AudioMessageItemComponent,
    ImageMessageItemComponent,
    MessageInputComponent,
  ],
  exports: [
    GroupMessagesComponent,
    MessageInputComponent,
    MessageItemComponent,
  ],
  imports: [
    CommonModule,
    IonicModule,
    SharedModule,
    FlexLayoutModule,
    MomentModule,
    TranslocoModule,
    UserModule,
  ],
})
export class MessageModule {}
