import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-card-segment',
  templateUrl: './card-segment.component.html',
  styleUrls: ['./card-segment.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CardSegmentComponent {
  @Input() translocoRoot!: string;
  @Input() items: string[] = [];
  @Input() disabledItems: string[] = [];
  @Input() value!: string;

  @Output() change = new EventEmitter<string>();

  onViewModeChange({ detail: { value } }: any) {
    if (!this.disabledItems.includes(value)) {
      this.value = value;
      this.change.emit(this.value);
    }
  }
}
