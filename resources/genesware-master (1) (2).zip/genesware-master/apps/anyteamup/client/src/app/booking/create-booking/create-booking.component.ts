import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { IonContent, ModalController } from '@ionic/angular';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { firstValueFrom, forkJoin } from 'rxjs';

import { Arena } from '../../arena/state/arena.model';
import { ArenaService } from '../../arena/state/arena.service';
import { slideInOut } from '../../shared/animations';
import { Booking, BookingOption, BookingPlace } from '../state/booking.model';

@Component({
  selector: 'app-create-booking',
  templateUrl: './create-booking.component.html',
  styleUrls: ['./create-booking.component.scss'],
  animations: [slideInOut()],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'booking' }],
})
export class CreateBookingComponent implements OnInit {
  @Input() arena!: Arena;
  @Input() mode: 'page' | 'form' = 'page';

  @Output() bookingComplete = new EventEmitter<Partial<Booking>>();

  form = this.fb.group({
    date: [],
    optionId: [null, Validators.required],
    bookedFrom: [null, Validators.required],
    bookedTo: [null, Validators.required],
  });
  bookingPlace!: BookingPlace;
  bookingOptions: BookingOption[] = [];
  bookedSlots: Partial<Booking>[] = [];

  @ViewChild(IonContent) content!: IonContent;

  get value(): Partial<Booking> {
    const { optionId, bookedFrom, bookedTo } = this.form.getRawValue();
    return {
      optionId,
      bookedFrom,
      bookedTo,
      placeId: this.bookingPlace.id,
    };
  }

  constructor(private modalController: ModalController, private fb: UntypedFormBuilder, private arenaService: ArenaService) {}

  async ngOnInit() {
    const [bookingPlace, bookingOptions, bookedSlots] = await firstValueFrom(
      forkJoin([
        this.arenaService.getBookedPlace(this.arena.id),
        this.arenaService.getBookingOptions(this.arena.id),
        this.arenaService.getBookedSlots(this.arena.id),
      ])
    );

    this.bookingOptions = bookingOptions;
    this.bookingPlace = bookingPlace;
    this.bookedSlots = bookedSlots;
  }

  onStartTimeDurationSelect(values: { bookedFrom: Date; bookedTo: Date }) {
    this.form.patchValue(values);
  }

  dismiss() {
    this.modalController.dismiss();
  }

  createBooking() {
    if (this.mode === 'form') {
      this.bookingComplete.emit(this.value);
    } else {
      this.modalController.dismiss(this.value);
    }
  }
}
