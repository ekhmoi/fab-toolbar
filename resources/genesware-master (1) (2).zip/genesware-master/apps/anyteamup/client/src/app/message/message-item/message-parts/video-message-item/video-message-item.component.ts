import { Component, Input } from '@angular/core';
import { Message, MessagePartType, User } from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-video-message',
  templateUrl: './video-message-item.component.html',
  styleUrls: ['./video-message-item.component.scss'],
})
export class VideoMessageItemComponent {
  @Input() message!: Message;
  @Input() groupUsers!: Map<string, User>;
  @Input() part!: { type: MessagePartType; message: string; payload?: any };
  @Input() displaySender!: boolean;
}
