import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { MapModule } from '../../../shared/map';
import { SharedModule } from '../../../shared/shared.module';
import { CreateCompanyComponent } from './create-company.component';

@NgModule({
  declarations: [CreateCompanyComponent],
  exports: [CreateCompanyComponent],
  imports: [CommonModule, SharedModule, FlexLayoutModule, MapModule],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'company' }],
})
export class CreateCompanyModule {}
