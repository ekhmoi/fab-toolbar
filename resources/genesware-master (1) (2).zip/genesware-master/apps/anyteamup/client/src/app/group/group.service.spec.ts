import { TestBed } from '@angular/core/testing';

import { GroupNotificationHandlerService } from './group-notification-handler.service';

describe('GroupNotificationHandlerService', () => {
  let service: GroupNotificationHandlerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GroupNotificationHandlerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
