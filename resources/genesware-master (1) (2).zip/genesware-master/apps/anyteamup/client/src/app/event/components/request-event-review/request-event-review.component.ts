import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Event } from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-request-event-review',
  templateUrl: './request-event-review.component.html',
  styleUrls: ['./request-event-review.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RequestGameReviewComponent {
  @Input() event!: Event;

  constructor(private modalController: ModalController) {}

  dismiss(displayReviewodal = false) {
    this.modalController.dismiss(displayReviewodal);
  }

  onClickYes() {
    this.dismiss(true);
  }

  onClickNo() {
    this.dismiss();
  }
}
