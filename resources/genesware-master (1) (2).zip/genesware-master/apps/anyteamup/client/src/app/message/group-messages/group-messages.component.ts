import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import {
  AuthQuery,
  Group,
  GroupQuery,
  GroupService,
  Message,
  MessageService,
  User,
} from '@genesware/shared/angular-sdk';
import {
  ActionSheetController,
  IonContent,
  ModalController,
} from '@ionic/angular';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { BehaviorSubject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

import { CreateEventPage } from '../../event/create-event/create-event.page';

@Component({
  selector: 'app-group-messages',
  templateUrl: './group-messages.component.html',
  styleUrls: ['./group-messages.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    { provide: TRANSLOCO_SCOPE, useValue: 'game-event', multi: true },
    { provide: TRANSLOCO_SCOPE, useValue: 'group', multi: true },
  ],
})
export class GroupMessagesComponent implements OnInit {
  createdBy!: User;
  groupUsers = new Map<string, User>([]);
  pendingUsers = new Map<string, User>([]); // Get pending users by retrieven active requests
  animating$ = new BehaviorSubject(false);

  lastReadMessageId!: string;
  private _messages: Message[] = [];
  messages$: Observable<Message[]> = this.groupQuery.activeGroupMessages$.pipe(
    tap((messages) => {
      this._messages = messages;
      this.newMessage.emit();
      this._readMessage(this._messages);
    })
  );
  user$ = this.authQuery.user$;

  @Input() isEvent = true;

  @ViewChild(IonContent) content!: IonContent;
  @ViewChild('#input', { static: true }) input: any;

  private _group!: Group;
  @Input() set group(group: Group) {
    if (!group) {
      return;
    }
    this._group = group;
    this.createdBy = group.createdBy;
    this.groupUsers = group.users.reduce(
      (acc, user) => acc.set(user.id, user),
      new Map<string, User>([])
    );
    this.groupService.setActive(group.id);
  }
  get group() {
    return this._group;
  }

  @Input() manageActionsEnabled = false;
  @Output() actionClick = new EventEmitter<{
    message: Message;
    action: string;
  }>();
  @Output() newMessage = new EventEmitter();

  constructor(
    private actionSheetController: ActionSheetController,
    private modalController: ModalController,
    private authQuery: AuthQuery,
    private groupQuery: GroupQuery,
    private messageService: MessageService,
    private groupService: GroupService
  ) {}

  ngOnInit() {
    setTimeout(() => {
      this.animating$.next(false);
    }, 350);
  }

  async onClickPlus(ev: MouseEvent) {
    ev.stopPropagation();
    ev.preventDefault();

    const actionSheet = await this.actionSheetController.create({
      mode: 'md',
      // color: 'light',
      buttons: [
        {
          icon: 'add',
          text: 'Create game & invite players',
          role: 'destructive',
          // icon: 'trash',
          handler: async () => {
            const modal = await this.modalController.create({
              component: CreateEventPage,
              mode: 'md',
              componentProps: {
                isInModal: true,
              },
            });
            return await modal.present();
          },
        },
        {
          text: 'Select game & invite players',
          icon: 'reader-outline',
          handler: () => {
            console.log('[NotImplemented] Select and Invite players');
          },
        },
        {
          text: 'Cancel',
          icon: 'close',
          role: 'cancel',
        },
      ],
    });
    actionSheet.present();
  }
  sendMessage(message: string) {
    this.messageService.sendMessage(message, this.group.id);
  }

  trackByFn(index: number, message: Message) {
    return message.id;
  }

  _readMessage(messages: Message[]) {
    const lastMessage = messages[messages.length - 1];
    const { user } = this.authQuery.getValue();
    if (
      lastMessage &&
      lastMessage.createdBy !== user.id &&
      this.lastReadMessageId !== lastMessage.id
    ) {
      this.lastReadMessageId = lastMessage.id;
      this.messageService.readMessage(lastMessage.id);
    }
  }
}
