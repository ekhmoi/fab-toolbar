import { Pipe, PipeTransform } from '@angular/core';

const CATEGORY_IMAGE_MAP = new Map<string, string>([
  ['american_football', 'american-football.png'],
  ['basketball', 'basketball.png'],
  ['football', 'football.png'],
  ['cricket', 'golf.png'],
  ['ice_hockey', 'table-tennis.png'],
  ['rugby', 'tennis.png'],
  ['volleyball', 'volleyball.png'],
  ['baseball', 'baseball.png'],
  ['field_hockey', 'field-hockey.png'],
]);

@Pipe({
  name: 'categoryIconUrl',
})
export class CategoryIconUrlPipe implements PipeTransform {
  transform(
    categoryKey?: string,
    type: 'icon' | 'image' = 'icon',
    suffix = ''
  ): string {
    if (!categoryKey) {
      return '';
    }
    return type === 'icon'
      ? `assets/custom-icons/game-icons/${
          categoryKey ? categoryKey + suffix : 'not-found'
        }.svg`
      : 'assets/icon/event-icons/' + CATEGORY_IMAGE_MAP.get(categoryKey);
  }
}
