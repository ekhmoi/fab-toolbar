import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  ViewChild,
} from '@angular/core';
import {
  Event,
  Group,
  Request,
  RequestStatus,
  User,
} from '@genesware/shared/angular-sdk';
import { EventDetailsService } from '../../event-details.service';
import { IonContent } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

export enum EventDetailViewMode {
  Chat = 'chat',
  Overview = 'overview',
}

const breakpoint = window.innerWidth / 2;
@Component({
  selector: 'app-event-details-content',
  templateUrl: './event-details-content.component.html',
  styleUrls: ['./event-details-content.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventDetailsContentComponent implements AfterViewInit, OnDestroy {
  private _queryParamTab!: EventDetailViewMode;
  @Input() set queryParamTab(tab: EventDetailViewMode | null) {
    this._queryParamTab = tab || this.viewMode || EventDetailViewMode.Overview;
    this.viewMode = this._queryParamTab;
  }
  get queryParamTab() {
    return this._queryParamTab;
  }

  private _user!: User;
  @Input() set user(user: User) {
    this._user = user;
    this._setGroup(this.group);
    this._resolvePendingRequestsCount();
  }
  get user(): User {
    return this._user;
  }

  @Input() _event!: Event;
  @Input() set event(event: Event) {
    this._event = event;
    if (event) {
      this._setGroup(event.group);
    }
  }
  get event(): Event {
    return this._event;
  }

  get group(): Group {
    return this.event?.group;
  }

  private _requests: Request[] = [];
  @Input() set requests(requests: Request[]) {
    this._requests = requests;
    this._resolvePendingRequestsCount();
  }
  get requests() {
    return this._requests;
  }

  @Output() refresh = new EventEmitter<any>();

  joined = false;
  viewMode!: EventDetailViewMode;
  viewModes = [EventDetailViewMode.Chat, EventDetailViewMode.Overview];
  scrolled = false;
  pendingRequestsCount = 0;
  scrollPassedBreakPoint = false;
  private scrollSubscription!: Subscription;

  @ViewChild('content', { static: false }) content!: IonContent;

  constructor(
    public readonly service: EventDetailsService,
    private cdr: ChangeDetectorRef
  ) {}

  ngAfterViewInit() {
    this.scrollSubscription = this.content.ionScroll
      .pipe(debounceTime(300))
      .subscribe(this._scrollHandler.bind(this));
  }

  ngOnDestroy() {
    this.scrollSubscription?.unsubscribe();
  }

  onViewModeChange(value: any): void {
    this.viewMode = value;
    this.cdr.detectChanges();
  }

  onNewMessage() {
    if (!this.content) {
      setTimeout(() => {
        this.onNewMessage();
      }, 20);
      return;
    }

    let scrollDuration = 100;
    if (!this.scrolled) {
      scrollDuration = 0;
      this.scrolled = true;
    }
    setTimeout(() => {
      this.content.scrollToBottom(scrollDuration);
    }, 100);
  }

  onTextAreaFocus() {
    setTimeout(() => {
      this.content.scrollToBottom(100);
    }, 300);
  }

  private _setGroup(group: Group) {
    if (!this.user || !group) {
      return;
    }
    this.joined = this.user && group.users.some((u) => u.id === this.user.id);

    if (this.viewMode) {
      return;
    }
    if (this.joined) {
      this.viewMode = EventDetailViewMode.Chat;
    } else {
      this.viewMode = EventDetailViewMode.Overview;
    }

    if (this.viewMode === EventDetailViewMode.Chat && !this.joined) {
      this.viewMode = EventDetailViewMode.Overview;
    }
  }

  private _scrollHandler({
    detail: { scrollTop },
  }: {
    detail: { scrollTop: number };
  }) {
    const scrollPassedBreakPoint = scrollTop >= breakpoint;

    if (this.scrollPassedBreakPoint !== scrollPassedBreakPoint) {
      this.scrollPassedBreakPoint = scrollPassedBreakPoint;
      this.cdr.detectChanges();
    }
  }

  private _resolvePendingRequestsCount(shouldBeCreator = true) {
    if (!this.requests?.length || !this.user) {
      this.pendingRequestsCount = 0;
      return;
    }

    const pendingRequests = this.requests.filter((req) => {
      const isCreator = req.createdBy.id === this.user.id;
      const isPending = req.status === RequestStatus.Pending;
      return (!shouldBeCreator || isCreator) && isPending;
    });

    this.pendingRequestsCount = pendingRequests.length;
  }
}
