import { Injectable } from '@angular/core';
import { NgEntityService } from '@datorama/akita-ng-entity-service';
import { Booking, BookingOption } from './booking.model';
import { BookingState, BookingStore } from './booking.store';

@Injectable({ providedIn: 'root' })
export class BookingService extends NgEntityService<BookingState> {
  constructor(protected override store: BookingStore) {
    super(store, { resourceName: 'bookings' });
  }

  setActive(id: string) {
    this.store.setActive(id);
  }

}
