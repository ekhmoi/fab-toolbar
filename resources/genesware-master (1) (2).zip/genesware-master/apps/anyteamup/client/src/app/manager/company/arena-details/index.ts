export * from './arena-details.component';
export * from './arena-details.module';
