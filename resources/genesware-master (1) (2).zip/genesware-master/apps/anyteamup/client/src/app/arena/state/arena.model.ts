export interface Arena {
  id: string;
  name: string;
  category: string;
  images: string[];
  createdBy?: string;
  companyId?: string;
  location: {
    coordinates: [number, number];
    street?: string;
    country?: string;
    city?: string;
    zip?: string;
    address?: string;
  };
}

export function createArena(params: Partial<Arena>) {
  return {} as Arena;
}
