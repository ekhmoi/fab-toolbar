import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { Router } from '@angular/router';
import {
  Notification,
  NotificationQuery,
  NotificationService,
  NotificationStatus,
  VIEW_NOTIFICATION_TYPES,
} from '@genesware/shared/angular-sdk';
import { MenuController } from '@ionic/angular';
import { BehaviorSubject, Observable } from 'rxjs';
import { finalize, map, take } from 'rxjs/operators';

import { hidePullToRefresh } from '../core/helpers';
import { ViewNotification } from '../models/view-notification.interface';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.page.html',
  styleUrls: ['./notifications.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NotificationsPage implements OnInit {
  notifications$ = this.notificationQuery.notifications$.pipe(
    map((notifications) => {
      return notifications.filter(
        ({ type, relatedDocument }) =>
          relatedDocument &&
          [...VIEW_NOTIFICATION_TYPES, 'CreateBookingRequestReceived'].includes(
            type
          )
      );
    })
  );
  private _oldNotifications$ = new BehaviorSubject<Notification[]>([]);
  oldNotifications$: Observable<Notification[]> =
    this._oldNotifications$.asObservable();
  oldNotificationToggleControl = new UntypedFormControl(false);
  loading$ = this.notificationQuery.selectLoading();

  constructor(
    private notificationService: NotificationService,
    private notificationQuery: NotificationQuery,
    private router: Router,
    private menuController: MenuController
  ) {}

  onRefresh(event?: any) {
    this.notificationService
      .get1([NotificationStatus.New, NotificationStatus.Read] as any)
      .pipe(
        finalize(() => {
          hidePullToRefresh(event);
        })
      )
      .subscribe();
  }

  toggleOld() {
    const newValue = !this.oldNotificationToggleControl.value;
    if (newValue) {
      this.notificationService
        .get<Notification[]>('read', { upsert: false })
        .pipe(
          take(1),
          map((notifications: Notification[]) => {
            return notifications.filter(
              ({ type, relatedDocument }) =>
                VIEW_NOTIFICATION_TYPES.includes(type) && !!relatedDocument
            );
          })
        )
        .subscribe((notifications) =>
          this._oldNotifications$.next(notifications)
        );
    }
    this.oldNotificationToggleControl.setValue(newValue);
  }

  ngOnInit() {
    this.notificationService
      .get1([NotificationStatus.New, NotificationStatus.Read] as any)
      .subscribe();
  }

  onClick(notification: ViewNotification) {
    if (notification.route) {
      this.menuController.close();
      setTimeout(() => {
        if (notification.route) {
          this.router.navigate(notification.route, {
            queryParams: notification.queryParams,
          });
        }
      }, 200);
    }
    this.notificationService.markAsRead([notification.id]);
  }
}
