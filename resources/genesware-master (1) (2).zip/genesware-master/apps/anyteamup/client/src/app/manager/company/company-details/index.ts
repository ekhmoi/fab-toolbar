export * from './company-details.component';
export * from './company-details.module';
