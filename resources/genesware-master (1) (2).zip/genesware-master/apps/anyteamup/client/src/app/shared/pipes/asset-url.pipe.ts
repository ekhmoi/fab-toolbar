import { Pipe, PipeTransform } from '@angular/core';

import { environment } from '../../../environments/environment';
import { Asset } from '../../models/asset.interface';

@Pipe({
  name: 'assetUrl',
})
export class AssetUrlPipe implements PipeTransform {
  transform(urlOrAsset: string | Asset): string {
    if (!urlOrAsset) {
      return '';
    }
    let url = urlOrAsset;
    if (typeof urlOrAsset !== 'string') {
      url = urlOrAsset.url;
    }
    return (`${environment.assetUrl}${url}` as string) || '';
  }
}
