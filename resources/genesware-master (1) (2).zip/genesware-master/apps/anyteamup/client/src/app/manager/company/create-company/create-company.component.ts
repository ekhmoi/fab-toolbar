import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ModalController } from '@ionic/angular';
import { switchMap } from 'rxjs/operators';

import { UserService } from '../../../core/services';
import { MapComponent } from '../../../shared/map';
import { Company } from '../state/company.model';
import { CompanyService } from '../state/company.service';

@Component({
  selector: 'app-create-company',
  templateUrl: './create-company.component.html',
  styleUrls: ['./create-company.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateCompanyComponent implements OnInit {
  form = this.fb.group({
    logo: [],
    name: [],
    location: this.fb.group({
      address: [],
      coordinates: [[0, 0]],
    }),
    contacts: this.fb.array([
      this.fb.group({
        value: [],
        type: [],
      }),
    ]),
    schedule: [this.generateScheduleMatrix()],
  });

  step = 0;
  submitted = false;
  placeSelected = false;
  place: any;
  coords: { lat: number; lng: number } | null = { lat: 0, lng: 0 };
  file!: File;
  image!: SafeResourceUrl;
  @ViewChild(MapComponent) map!: MapComponent;

  constructor(
    private fb: UntypedFormBuilder,
    private cdr: ChangeDetectorRef,
    private modalCtrl: ModalController,
    private service: CompanyService,
    private domSanitizer: DomSanitizer,
    private userService: UserService
  ) {}

  generateScheduleMatrix() {
    const closedDays = ['saturday', 'sunday'];
    const openingTime = new Date();
    const closingTime = new Date();
    openingTime.setHours(9);
    openingTime.setMinutes(0);
    closingTime.setHours(18);
    closingTime.setMinutes(0);

    return [
      'monday',
      'tuesday',
      'wednesday',
      'thursday',
      'friday',
      'saturday',
      'sunday',
    ].map((weekDay) => [
      weekDay,
      closedDays.includes(weekDay) ? null : openingTime,
      closedDays.includes(weekDay) ? null : closingTime,
    ]);
  }

  ngOnInit(): void {
    this.initUserLocation();
  }

  async initUserLocation() {
    this.coords = await this.userService.getCoordinates();
    this.cdr.detectChanges();
  }

  setPlace(place: any) {
    this.place = place;
    this.form.patchValue({
      name: this.form.value.name || place.name,
      location: {
        coordinates: [place.lng, place.lat],
        address: place.address,
      },
    });
    this.placeSelected = !!this.place;
    this.cdr.detectChanges();
  }

  dismiss(company?: Partial<Company>) {
    this.modalCtrl.dismiss(company);
  }

  onCreate() {
    this.service
      .uploadAsset(this.file)
      .pipe(
        switchMap((assets) =>
          this.service.create({
            ...this.form.getRawValue(),
            logo: assets[0].url,
          })
        )
      )
      .subscribe(async (company) => {
        this.dismiss(company);
      });
  }

  onClickNext() {
    this.step = 1;
  }

  onFileSelect(event: any) {
    if (event.target.files.length > 0) {
      this.file = event.target.files[0];
      this.image = this.domSanitizer.bypassSecurityTrustResourceUrl(
        URL.createObjectURL(this.file)
      );
    }
  }
}
