import { Component, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import {
  Category,
  CategoryQuery,
  GroupService,
} from '@genesware/shared/angular-sdk';
import {
  IonContent,
  IonInput,
  ModalController,
  ViewDidEnter,
} from '@ionic/angular';

@Component({
  selector: 'app-create-group',
  templateUrl: './create-group.page.html',
  styleUrls: ['./create-group.page.scss'],
})
export class CreateGroupPage implements ViewDidEnter {
  @ViewChild('title') title!: IonInput;
  @ViewChild(IonContent) content!: IonContent;

  categories$ = this.categoryQuery.selectAll();
  form: UntypedFormGroup;
  submitted = false;
  constructor(
    private modalController: ModalController,
    private categoryQuery: CategoryQuery,
    private groupService: GroupService,
    fb: UntypedFormBuilder
  ) {
    this.form = fb.group({
      title: [null, Validators.required],
      category: [null, Validators.required],
    });
  }

  ionViewDidEnter() {
    setTimeout(() => {
      this.title.setFocus();
    });
  }

  dismiss() {
    this.modalController.dismiss();
  }

  onCategoryClick([category, state]: [Category, boolean]) {
    this.form.get('category')?.setValue(state ? category.key : null);
    this.content.scrollToBottom(300);
  }

  onCreate() {
    this.submitted = true;
    if (this.form.valid) {
      this.groupService.add(this.form.value).subscribe((group) => {
        this.modalController.dismiss(group);
      });
    }
  }
}
