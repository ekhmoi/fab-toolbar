import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';

import { SharedModule } from '../../../shared/shared.module';
import { ArenaDetailsComponent } from './arena-details.component';
import { BookingListComponent } from './booking-list/booking-list.component';

@NgModule({
  declarations: [ArenaDetailsComponent, BookingListComponent],
  exports: [ArenaDetailsComponent],
  imports: [CommonModule, SharedModule, FlexLayoutModule],
})
export class ArenaDetailsModule {}
