import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

import { DefaultRedirectGuard } from './core/guards';
import { ManagerRoleGuard, UserRoleGuard } from './core/guards/user-role.guard';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    children: [],
    canActivate: [DefaultRedirectGuard],
  },
  {
    path: 'welcome',
    loadChildren: () =>
      import('./welcome/welcome.module').then((m) => m.WelcomePageModule),
    canActivate: [DefaultRedirectGuard],
  },
  {
    path: 'event',
    loadChildren: () =>
      import('./event/event.module').then((m) => m.EventModule),
  },
  {
    path: 'group',
    loadChildren: () =>
      import('./group/group.module').then((m) => m.GroupModule),
  },
  {
    path: 'tabs',
    loadChildren: () =>
      import('./tabs/tabs.module').then((m) => m.TabsPageModule),
    canActivateChild: [UserRoleGuard],
  },
  {
    path: 'manage',
    loadChildren: () =>
      import('./manager/manager-tabs/manager-tabs.module').then(
        (m) => m.ManagerTabsPageModule
      ),
    canActivateChild: [ManagerRoleGuard],
  },
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      preloadingStrategy: PreloadAllModules,
      useHash: false,
      relativeLinkResolution: 'legacy',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
