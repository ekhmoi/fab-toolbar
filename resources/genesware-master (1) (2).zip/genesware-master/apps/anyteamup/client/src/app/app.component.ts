import { ChangeDetectionStrategy, Component } from '@angular/core';
import {
  AuthQuery,
  EventParams,
  EventQuery,
  EventService,
  UserService,
} from '@genesware/shared/angular-sdk';
import { DEFAULT_EVENT_PARAMS } from './event/event-params.defaults';
import { forkJoin } from 'rxjs';
import { ArenaService } from './arena/state/arena.service';
import { AppService } from './core/services';

@Component({
  selector: 'app-root',
  template: `
    <ion-app>
      <ion-menu
        side="start"
        menuId="filters"
        contentId="app"
        type="overlay"
        [swipeGesture]="isOnHomePage$ | async"
        (ionDidClose)="ion_menu_scroll_bug_fix()"
        (ionDidOpen)="ion_menu_scroll_bug()"
        (ionWillClose)="refreshEvents()"
      >
        <app-home-menu></app-home-menu>
      </ion-menu>

      <ion-menu
        side="end"
        menuId="managerNotifications"
        contentId="app"
        type="overlay"
        [swipeGesture]="isOnManagerHomePage$ | async"
        (ionDidClose)="ion_menu_scroll_bug_fix()"
        (ionDidOpen)="ion_menu_scroll_bug()"
      >
        Manager notifications here
        <!-- <app-home-menu></app-home-menu> -->
      </ion-menu>

      <ion-router-outlet
        id="app"
        main
        [style.top.px]="ios14Fix"
        mode="ios"
        ngClass.gt-sm="desktop-mode"
      >
        <ion-progress-bar
          type="indeterminate"
          *ngIf="loading$ | async"
        ></ion-progress-bar>
      </ion-router-outlet>
    </ion-app>
  `,
  styles: [
    `
      ion-progress-bar {
        z-index: 102;
        top: 50px;
      }
      ion-menu[menuid='notificationMenu'] {
        --width: 300px;
      }
      ion-router-outlet.desktop-mode ::ng-deep .ion-page:not(app-tabs) {
        padding-top: 55px;
      }
      ion-router-outlet.desktop-mode ::ng-deep ion-content,
      ion-router-outlet.desktop-mode ::ng-deep ion-header:not(.desktop-header) {
        width: 1000px;
        left: calc(50vw - 500px);
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
  ios14Fix = 0;
  loading$ = this.app.loading$;
  isLoggedIn$ = this.authQuery.isLoggedIn$;
  isOnHomePage$ = this.app.isOnHomePage$;
  isOnManagerHomePage$ = this.app.isOnManagerHomePage$;

  constructor(
    private gameEventService: EventService,
    private gameEventQuery: EventQuery,
    private authQuery: AuthQuery,
    private userService: UserService,
    private arenaService: ArenaService,
    private app: AppService
  ) {
    this.app.start();
  }

  refreshEvents() {
    const params: EventParams =
      this.userService.getUserPreference<EventParams>('EVENT_PARAMS') ||
      DEFAULT_EVENT_PARAMS;
    const selectedCategories =
      this.userService.getUserPreference<string[]>('SELECTED_CATEGORIES') || [];
    const { lat, lng } = this.gameEventQuery.getValue().params.location || {
      lat: 0,
      lng: 0,
    };
    this.arenaService
      .getNearbyArenas({
        lat,
        lng,
        categories: (selectedCategories || []).join(','),
        sortBy: 'location',
        maxDistance: params.maxDistance,
        date: params.date,
      })
      .subscribe();
    forkJoin([
      this.gameEventService.setParams(
        { ...params, selectedCategories },
        false,
        true
      ),
      this.gameEventService.getUserEvents(),
    ]).subscribe();
  }

  ion_menu_scroll_bug() {
    this.ios14Fix = 1;
  }

  ion_menu_scroll_bug_fix() {
    this.ios14Fix = 0;
  }
}
