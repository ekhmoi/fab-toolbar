import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { SharedModule } from '../shared/shared.module';
import { AuthDialogComponent } from './auth-dialog/auth-dialog.component';
import { SuccessfulRegistrationDialog } from './auth-dialog/successful-registration.dialog';
import { HasRoleDirective } from './has-role.directive';
import { LoginFormComponent } from './login-form/login-form.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { RequireAuthorizationDirective } from './require-authorization.directive';
import { SocialLoginCardComponent } from './social-login-card/social-login-card.component';

@NgModule({
  declarations: [
    AuthDialogComponent,
    LoginFormComponent,
    RegisterFormComponent,
    HasRoleDirective,
    RequireAuthorizationDirective,
    SuccessfulRegistrationDialog,
    SocialLoginCardComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    IonicModule,
    SharedModule,
    TranslocoModule,
  ],
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'auth' }],
  exports: [
    HasRoleDirective,
    RegisterFormComponent,
    RequireAuthorizationDirective,
    SocialLoginCardComponent,
  ],
})
export class AuthModule {}
