import { animate, style, transition, trigger } from '@angular/animations';

export const slideInOut = (animationName = 'slideInOut', duration = 200, easingValue = 'ease-in') =>
  trigger(animationName, [
    transition(':enter', [
      style({ transform: 'translateX(-100%)' }),
      animate(`${duration}ms ${easingValue}`, style({ transform: 'translateX(0%)' })),
    ]),
    transition(':leave', [animate(`${duration}ms ${easingValue}`, style({ transform: 'translateX(-100%)' }))]),
  ]);
