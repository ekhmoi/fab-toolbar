export enum Language {
  AZ = 'az',
  EN = 'en',
  RU = 'ru'
}

export const DEFAULT_LANGUAGE = Language.EN;