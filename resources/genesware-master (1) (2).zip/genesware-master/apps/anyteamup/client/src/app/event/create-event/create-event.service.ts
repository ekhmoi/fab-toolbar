import { Injectable } from '@angular/core';
import {
  AbstractControl,
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { AuthQuery, Category, Event } from '@genesware/shared/angular-sdk';
import { translate, TranslocoService } from '@ngneat/transloco';
import * as moment from 'moment';
import { BehaviorSubject, Observable } from 'rxjs';
import { filter, take, tap } from 'rxjs/operators';

import { Booking } from '../../booking/state/booking.model';
import { MapService } from '../../shared/map';

@Injectable()
export class CreateEventService {
  private user$ = this.authQuery.user$;
  form!: UntypedFormGroup;
  step$ = new BehaviorSubject<number>(1);
  minUsers!: number;
  maxUsers!: number;
  submittedSteps = new BehaviorSubject<{ [key: number]: boolean }>({});

  constructor(
    private fb: UntypedFormBuilder,
    private translate: TranslocoService,
    private authQuery: AuthQuery,
    private mapService: MapService
  ) {
    this.resetSubmittedSteps();
  }

  resetSubmittedSteps() {
    this.submittedSteps.next({
      1: false,
      2: false,
      3: false,
      4: false,
    });
  }

  onCategorySelect({ key, minUsers, maxUsers }: Category) {
    this.minUsers = minUsers as number;
    this.maxUsers = maxUsers as number;
    this.user$
      .pipe(
        filter((user) => !!user),
        take(1)
      )
      .subscribe((user) => {
        this.form
          .get('playerCount')
          ?.setValue({ lower: minUsers, upper: maxUsers });
      });
  }

  goBack(step = Math.max(this.step$.getValue() - 1, 1)) {
    this.step$.next(step);
  }

  goNext(step = this.step$.getValue() + 1) {
    if (!this.validateStep()) {
      this.submittedSteps.next({
        ...this.submittedSteps.getValue(),
        [step - 1]: true,
      });
      return;
    }
    this.submittedSteps.next({
      ...this.submittedSteps.getValue(),
      [step - 1]: true,
    });

    this.step$.next(step);
    // TODO: Move it to a different place
    if (step === 4) {
      this.form.get('title')?.setValue(this.generateTitle());
      this.form.get('description')?.setValue(this.generateDescription());
    }
  }

  setPlace({ lat, lng, name, address }: any) {
    this.setLocationDetails({ lat, lng });

    const loc = this.form.get('location');
    if (!loc) {
      return;
    }
    loc.get('name')?.setValue(name);
    loc.get('address')?.setValue(address);
  }

  setLocationDetails(details: {
    lat?: number;
    lng?: number;
    name?: string;
    address?: string;
  }) {
    const loc = this.form.get('location');
    const coordinatesControl = loc?.get('coordinates');
    if (typeof details.lat !== 'undefined') {
      coordinatesControl?.setValue([details.lng, coordinatesControl.value[1]]);
    }

    if (typeof details.lng !== 'undefined') {
      coordinatesControl?.setValue([coordinatesControl.value[0], details.lat]);
    }

    if (typeof details.address !== 'undefined') {
      loc?.get('address')?.setValue(details.address);
    }

    if (typeof details.name !== 'undefined') {
      loc?.get('name')?.setValue(details.name);
    }
  }

  setLocation(lat: number, lng: number): Observable<any> {
    this.setLocationDetails({ lat, lng });
    return this.mapService.geocode(lat, lng).pipe(
      tap(
        (place) => {
          if (place === null) {
            // set to empty string
            this.setLocationDetails({ name: '' });
            return;
          }

          this.setLocationDetails(place);
        },
        ({ results, status }) => {
          console.error('Geocoder failed due to: ', status, results);
        }
      )
    );
  }

  setBooking(booking: Partial<Booking>) {
    this.form.patchValue({
      booking,
      startTime: booking.bookedFrom,
      endTime: booking.bookedTo,
      date: booking.bookedFrom,
    });
  }

  toggleShowAdditional() {
    this.form
      .get('showAdditional')
      ?.setValue(!this.form.get('showAdditional')?.value);
  }

  createForm(event?: Event) {
    this.form = this.fb.group({
      minUsers: [0, [Validators.required, Validators.min(4)]],
      maxUsers: [0, [Validators.required, Validators.min(4)]],
      category: [null, [Validators.required]],
      price: [null, Validators.required],
      arenaId: [null],
      currency: ['CZK'],
      title: [null, Validators.required],
      date: [null, [Validators.required]],
      startTime: [null, [Validators.required]],
      endTime: [null, [Validators.required]],
      description: [null],
      banner: [null],
      location: this.fb.group({
        name: [null, Validators.required],
        address: [null, Validators.required],
        coordinates: [[0, 0]],
      }),
      showAdditional: [false, []],
      playerCount: [{ lower: 8, upper: 15 }],
      isPrivate: [false],
      anyoneCanInvite: [true],
      minimumRating: [0],
      booked: [null, Validators.required],
      booking: [null],
      preferredTimesOfTheDay: [[]],
    });
  }

  generateTitle(): string {
    const {
      category: cKey,
      location: { name },
      playerCount: { lower, upper },
    } = this.form.getRawValue();
    const category = this.translate.translate(`categories.${cKey}`);

    return translate('gameEvent.createEvent.eventDetails.generatedTitle', {
      category,
      location: name,
    });
  }

  generateDescription(): string {
    const {
      category: cKey,
      location: { name },
      playerCount: { lower, upper },
      date,
    } = this.form.getRawValue();
    const category = this.translate.translate(`categories.${cKey}`);
    return translate(
      'gameEvent.createEvent.eventDetails.generatedDescription',
      {
        category,
        location: name,
        date: moment(date.value).format('dddd'),
      }
    );
  }

  validateStep() {
    const step = this.step$.getValue();
    const validateControls: AbstractControl[] = [];
    let hasError = false;
    if (step === 3) {
      const { booked, startTime, endTime, date, location, price } =
        this.form.controls;
      validateControls.push(date, location);
      if (booked.value) {
        // Should set date and time
        validateControls.push(startTime, price, endTime);

        if (date.pristine) {
          hasError = true;
        }
        if (startTime.pristine) {
          hasError = true;
        }
        if (endTime.pristine) {
          hasError = true;
        }
      }
    }

    if (step === 4) {
      console.log('Should something happen now?');
    }
    return !hasError && !validateControls.some((control) => control.invalid);
  }
}
