import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  NgZone,
  OnInit,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  EventQuery,
  UserService as UserPreferenceService,
} from '@genesware/shared/angular-sdk';
import { IonContent } from '@ionic/angular';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { UserService } from '../../core/services';
import { Arena } from '../state/arena.model';
import { ArenaQuery } from '../state/arena.query';
import { ArenaService } from '../state/arena.service';

const MAX_ZOOM = 13;
const MIN_ZOOM = 8;
@Component({
  selector: 'app-nearby-arenas',
  templateUrl: './nearby-arenas.component.html',
  styleUrls: ['./nearby-arenas.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'arena' }],
})
export class NearbyArenasComponent implements OnInit {
  coords: { lat: number; lng: number } | null = { lat: 0, lng: 0 };
  arenas$ = this.arenaQuery.items$;
  zoom = MAX_ZOOM;

  highlightedArenaId!: string;

  @ViewChild(IonContent) content!: IonContent;

  constructor(
    private arenaQuery: ArenaQuery,
    private service: ArenaService,
    private route: ActivatedRoute,
    private gameEventQuery: EventQuery,
    private userPreferenceService: UserPreferenceService,
    private userService: UserService,
    private ngZone: NgZone,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.initUserLocation();
  }

  async initUserLocation() {
    const maxDistance = +(
      this.route.snapshot.queryParamMap.get('maxDistance') || 5
    );
    this.zoom = Math.max(MAX_ZOOM - maxDistance / 5, MIN_ZOOM);
    await this.userService.getCoordinates();
    this.ngZone.run(() => {
      const position = this.userService.getCachedCoordinates();
      this.coords = position ? position : null;
      if (!this.coords) {
        return;
      }
      this.getNearbyArenas(this.coords.lat, this.coords.lng).subscribe();
      this.cdr.detectChanges();
    });
  }

  getNearbyArenas(lat: number, lng: number) {
    const selectedCategories =
      this.userPreferenceService.getUserPreference<string[]>(
        'SELECTED_CATEGORIES'
      ) || [];
    const { params } = this.gameEventQuery.getValue();

    return this.service.getNearbyArenas({
      lat,
      lng,
      categories: (selectedCategories || []).join(','),
      maxDistance: params.maxDistance,
      date: params.date,
    });
  }

  onArenaMapClick(arena: Arena) {
    this.highlightedArenaId = arena.id;
    this.scrollTo(arena.id);
  }

  scrollTo(elementId: string) {
    const y = document.getElementById(elementId)?.offsetTop || 0;
    this.content.scrollToPoint(0, y, 500);
  }
}
