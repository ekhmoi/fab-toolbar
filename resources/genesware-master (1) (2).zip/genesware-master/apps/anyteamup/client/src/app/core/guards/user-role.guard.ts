import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  CanActivateChild,
  Router,
  RouterStateSnapshot
} from '@angular/router';
import { AuthQuery } from '@genesware/shared/angular-sdk';


@Injectable({
  providedIn: 'root',
})
export class UserRoleGuard implements CanActivate, CanActivateChild {
  constructor(private auth: AuthQuery, private router: Router) {}

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.canActivate();
  }
  canActivate(): boolean {
    const auth = this.auth.getValue();
    if (auth.isLoggedIn) {
      const isUser = (auth.user.role as string).toLowerCase() === 'user';
      const isManager = (auth.user.role as string).toLowerCase() === 'manager';
      if (isManager) {
        this.router.navigate(['/manage']);
      }
      return isUser;
    } else {
      return true; // Guest users can explore nearby events
    }
  }
}

@Injectable({
  providedIn: 'root',
})
export class ManagerRoleGuard implements CanActivate, CanActivateChild {
  constructor(private auth: AuthQuery, private router: Router) {}

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.canActivate();
  }
  canActivate(): boolean {
    const auth = this.auth.getValue();
    if (auth.isLoggedIn) {
      const isManager = (auth.user.role as string).toLowerCase() === 'manager';

      if (!isManager) {
        this.router.navigate(['/tabs', 'home']);
      }
      return isManager;
    } else {
      this.router.navigate(['/tabs', 'home']);
      return false; // Guest users can explore nearby events
    }
  }
}
