import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { User } from '@genesware/shared/angular-sdk';

import { Booking } from '../../../../booking/state/booking.model';
import { MessageInputModalComponent } from '../../../../shared/components';

@Component({
  selector: 'app-booking-list',
  templateUrl: './booking-list.component.html',
  styleUrls: ['./booking-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BookingListComponent {
  @Input() bookings: Booking<User>[] = [];
  @Input() translocoRoot!: string;
  @Input() viewMode!: string;

  @Output() add = new EventEmitter();
  @Output() approve = new EventEmitter<Booking<User>>();
  @Output() reject = new EventEmitter<{
    booking: Booking<User>;
    reason?: string;
  }>();
  @Output() cancel = new EventEmitter<{
    booking: Booking<User>;
    reason?: string;
  }>();
  @Output() chat = new EventEmitter<{
    booking: Booking<User>;
    message: string;
  }>();

  actionsVisibilityMap = {};

  constructor(private bottomSheet: MatBottomSheet) {}

  onApprove(ev: MouseEvent, booking: Booking<User>) {
    ev.stopPropagation();
    this.approve.emit(booking);
  }

  onCancel(ev: MouseEvent, booking: Booking<User>) {
    ev.stopPropagation();
    MessageInputModalComponent.open(
      this.bottomSheet,
      {
        title: 'Cancel booking',
        description:
          'You are about to cancel this booking. You can write your reason for canceling in the below field.',
        placeholder: 'Type here...',
        rows: 2,
        buttonColor: 'danger',
        buttonText: 'Cancel Booking',
        buttonIcon: 'close',
      },
      (reason) => this.cancel.emit({ booking, reason })
    );
  }

  onReject(ev: MouseEvent, booking: Booking<User>) {
    ev.stopPropagation();
    MessageInputModalComponent.open(
      this.bottomSheet,
      {
        title: 'Reject booking request',
        description:
          'Do you want to reject this booking request?. You can write additional message to user in the below field.',
        placeholder: 'Type here...',
        rows: 2,
        buttonColor: 'danger',
        buttonText: 'Reject Request',
        buttonIcon: 'close',
      },
      (reason) => this.reject.emit({ booking, reason })
    );
  }

  async onChat(ev: MouseEvent, booking: Booking<User>) {
    ev.stopPropagation();

    MessageInputModalComponent.open(
      this.bottomSheet,
      {
        user: booking.createdBy,
        showUserInHeader: true,
        rows: 6,
        placeholder: 'Your message...',
        buttonColor: 'primary',
        buttonText: 'Send Message',
        buttonIcon: 'send',
      },
      (msg) => this.chat.emit({ booking, message: msg as string })
    );
  }
}
