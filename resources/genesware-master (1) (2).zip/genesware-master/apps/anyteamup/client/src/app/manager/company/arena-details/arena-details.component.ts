import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { filterNilValue } from '@datorama/akita';
import {
  RequestQuery,
  RequestService,
  RequestStatus,
  User,
} from '@genesware/shared/angular-sdk';
import * as moment from 'moment';
import { forkJoin } from 'rxjs';
import { pluck, switchMap, tap } from 'rxjs/operators';

import { Arena } from '../../../arena/state/arena.model';
import { ArenaService } from '../../../arena/state/arena.service';
import { Booking, BookingStatus } from '../../../booking/state/booking.model';

type ViewMode = 'pending' | 'booked';

@Component({
  selector: 'app-arena-details',
  templateUrl: './arena-details.component.html',
  styleUrls: ['./arena-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ArenaDetailsComponent implements OnInit {
  viewMode: ViewMode = 'pending';
  viewModes: ViewMode[] = ['pending', 'booked'];
  pendingBookings: Booking<User>[] = [];
  bookedBookings: Booking<User>[] = [];
  arena!: Arena;

  constructor(
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private arenaService: ArenaService,
    private requestQuery: RequestQuery,
    private requestService: RequestService
  ) {}

  ngOnInit(): void {
    this.route.params
      .pipe(
        pluck('id'),
        filterNilValue(),
        switchMap((id) =>
          forkJoin([
            this.arenaService.get<Arena>(id),
            this.arenaService.getBookings(id, {
              fromDate: moment().startOf('day').toJSON(),
              status: BookingStatus.Pending,
            }),
            this.arenaService.getBookings(id, {
              fromDate: moment().startOf('day').toJSON(),
              status: BookingStatus.Approved,
            }),
          ])
        ),
        tap(([arena]) => this.arenaService.setActive(arena.id))
      )
      .subscribe(([arena, pendingBookings, bookedBookings]) => {
        this.arena = arena;
        this.pendingBookings = pendingBookings;
        this.bookedBookings = bookedBookings;

        this.cdr.detectChanges();
      });
  }

  sendMessage(data: { booking: Booking<User>; message: string }) {
    console.log('[NotImplemented] ArenaDetailsComponent.sendMessage'), data;
  }

  cancelBooking(data: { booking: Booking<User>; reason?: string }) {
    console.log('[NotImplemented] ArenaDetailsComponent.cancelBooking', data);
  }

  addBooking() {
    console.log('[NotImplemented] ArenaDetailsComponent.addBooking');
  }

  async approveBooking(booking: Booking<User>) {
    const request = await this._findBookingRequestFromServerIfNeeded(
      booking.id as string
    );
    if (request) {
      this.requestService.approve(request.id as string).subscribe(() => {
        this._removePendingBooking(booking.id as string);
      });
    } else {
      console.warn(
        'Trying to approve a booking to which non pending request could be found',
        booking
      );
    }
  }

  async rejectBooking(data: { booking: Booking<User>; reason?: string }) {
    const request = await this._findBookingRequestFromServerIfNeeded(
      data.booking.id as string
    );
    if (request) {
      this.requestService.reject(request.id as string).subscribe(() => {
        this._removePendingBooking(data.booking.id as string);
      });
    } else {
      console.warn(
        'Trying to reject a booking to which non pending request could be found',
        data
      );
    }
  }

  private async _findBookingRequestFromServerIfNeeded(id: string) {
    const bookingRequest = this._findBookingRequest(id);

    if (!bookingRequest) {
      // If couldn't find request in current state, try to reload from server and find it again.
      await this.requestService.get().toPromise();
      return this._findBookingRequest(id);
    }
    return bookingRequest;
  }

  private _findBookingRequest(bookingId: string) {
    return this.requestQuery
      .getAll()
      .find(
        (request) =>
          request.requestedForDocumentId === bookingId &&
          request.status === RequestStatus.Pending
      );
  }

  _removePendingBooking(id: string) {
    this.pendingBookings = this.pendingBookings.filter((b) => b.id !== id);
    this.cdr.detectChanges();
  }

  onViewModeChange(viewMode: string) {
    this.viewMode = viewMode as ViewMode;
    this._getViewModeData(viewMode);
  }

  private _getViewModeData(viewMode: string) {
    const isPending = viewMode === 'pending';
    this.arenaService
      .getBookings(this.route.snapshot.paramMap.get('id') as string, {
        fromDate: moment().startOf('day').toJSON(),
        status: isPending ? BookingStatus.Pending : BookingStatus.Approved,
      })
      .subscribe((bookings) => {
        if (isPending) {
          this.pendingBookings = bookings;
        } else {
          this.bookedBookings = bookings;
        }
        this.cdr.detectChanges();
      });
  }
}
