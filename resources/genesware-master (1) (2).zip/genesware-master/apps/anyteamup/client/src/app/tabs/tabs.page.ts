import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import {
  AuthQuery,
  EventService,
  GroupQuery,
  GroupService,
  NotificationQuery,
  UserRole,
} from '@genesware/shared/angular-sdk';
import { IonFab, IonTabs, ModalController } from '@ionic/angular';
import { map } from 'rxjs/operators';

import { CreateArenaComponent } from '../arena/create-arena/create-arena.component';
import { CreateEventPage } from '../event/create-event/create-event.page';
import { EventDetailsPage } from '../event/event-details/event-details.page';
import { CreateGroupPage } from '../group/create-group/create-group.page';

enum TabMode {
  Home = 'home',
  Groups = 'group',
  Notifications = 'notification',
  Settings = 'settings',
}

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TabsPage implements OnInit {
  isOnSettingsTab = false;
  inited = false;
  isLoggedIn$ = this.authQuery.isLoggedIn$;
  currentTab: TabMode = TabMode.Home;
  groupsCount$ = this.groupQuery.count$;
  unreadGroupsCount$ = this.groupQuery.groups$.pipe(
    map((groups) => groups.filter((group) => group.hasUnread).length)
  );
  hasUnreadGroup$ = this.groupQuery.hasUnreadGroup$;
  notificationsCount$ = this.notificationQuery.unreadCount$;

  @ViewChild(IonTabs) tabs!: IonTabs;
  @ViewChild(IonFab) fab!: IonFab;

  userRole!: string;

  constructor(
    private authQuery: AuthQuery,
    private groupQuery: GroupQuery,
    private modalController: ModalController,
    private gameEventService: EventService,
    private groupService: GroupService,
    private router: Router,
    private notificationQuery: NotificationQuery,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.authQuery.user$.subscribe((user) => {
      this.userRole = user?.role || UserRole.User;
      this.cdr.detectChanges();
    });
  }

  tabChange({ tab }: { tab: string }) {
    this.currentTab = tab as TabMode;
    this.isOnSettingsTab = tab === 'settings';
    // close fab if it is opened
    this.fab?.close();
  }

  async openCreateArenaModal() {
    const modal = await this.modalController.create({
      component: CreateArenaComponent,
      cssClass: 'my-custom-class',
    });
    await modal.present();

    modal.onDidDismiss().then(({ data }) => {
      if (data && data.id) {
        this.router.navigate(['/tabs', 'home', 'arena', data.id]);
      }
    });
  }

  async onClickCreateEvent() {
    const modal = await this.modalController.create({
      component: CreateEventPage,
      mode: 'md',
      componentProps: {
        isInModal: true,
      },
    });
    const { data } = await modal.onDidDismiss();
    if (data) {
      this.gameEventService.setActive(data.id);
      const modal = await this.modalController.create({
        component: EventDetailsPage,
        mode: 'md',
        componentProps: {
          isInModal: true,
        },
      });
      modal.present();
    }
    return await modal.present();
  }

  async onClickCreateGroup() {
    const modal = await this.modalController.create({
      component: CreateGroupPage,
    });
    modal.present();

    const { data } = await modal.onDidDismiss();
    if (data) {
      this.groupService.get().subscribe();
      this.groupService.setActive(data.id);
      this.router.navigate(['/group', 'details', data.id], {
        queryParams: { firstTime: true },
      });
    }
  }
}
