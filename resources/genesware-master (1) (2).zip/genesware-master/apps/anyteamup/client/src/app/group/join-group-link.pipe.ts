import { Group } from '@genesware/shared/angular-sdk';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'joinGroupLink'
})
export class JoinGroupLinkPipe implements PipeTransform {

  transform({id, token}: Group): string {
    return `https://anyteamup.com/join-group/${id}/${token}`;
  }
}
