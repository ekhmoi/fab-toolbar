import { Component, Input } from '@angular/core';
import { Message, MessagePartType, User } from '@genesware/shared/angular-sdk';

@Component({
  selector: 'app-image-message',
  templateUrl: './image-message-item.component.html',
  styleUrls: ['./image-message-item.component.scss'],
})
export class ImageMessageItemComponent {
  @Input() message!: Message;
  @Input() groupUsers!: Map<string, User>;
  @Input() part!: {
    type: MessagePartType;
    message: string;
    payload?: { assetId: string };
  };
  @Input() displaySender!: boolean;
}
