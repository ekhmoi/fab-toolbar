import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-selected-arena-info',
  templateUrl: './selected-arena-info.component.html',
  styleUrls: ['./selected-arena-info.component.scss'],
})
export class SelectedArenaInfoComponent {
  @Input() place: any;
  @Input() arena: any;
}
