import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { SharedModule } from '../../../shared/shared.module';
import { UserModule } from '../../../user/user.module';
import { CompanyDetailsCardComponent } from './components';

@NgModule({
  declarations: [CompanyDetailsCardComponent],
  imports: [CommonModule, SharedModule, UserModule],
  exports: [CompanyDetailsCardComponent],
})
export class CompanySharedModule {}
