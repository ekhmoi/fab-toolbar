import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { map } from 'rxjs/operators';
import { ArenaStore, ArenaState } from './arena.store';

@Injectable({ providedIn: 'root' })
export class ArenaQuery extends QueryEntity<ArenaState> {
  items$ = this.selectAll();
  loading$ = this.selectLoading();

  constructor(protected override store: ArenaStore) {
    super(store);
  }

  selectByCompanyId(companyId: string) {
    return this.selectAll().pipe(map((arenas) => arenas.filter((arena) => arena.companyId === companyId)));
  }
}
