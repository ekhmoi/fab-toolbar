import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingsToolbarComponent } from './bookings-toolbar.component';

describe('BookingsToolbarComponent', () => {
  let component: BookingsToolbarComponent;
  let fixture: ComponentFixture<BookingsToolbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookingsToolbarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingsToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
