import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import {
  AuthQuery,
  AuthStore,
  Category,
  CategoryQuery,
  CategoryService,
  EventService,
  UserService,
  serializePreferences,
} from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';

import { DEFAULT_EVENT_PARAMS } from '../../event/event-params.defaults';
import { SettingsService } from '../../settings/settings.service';

@Component({
  selector: 'app-category-selector-modal',
  templateUrl: './user-preferences-setup-modal.component.html',
  styleUrls: ['./user-preferences-setup-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: TRANSLOCO_SCOPE, useValue: 'game-event' }],
})
export class UserPreferencesSetupModalComponent implements OnInit {
  categories$ = this.categoryQuery.selectAll();
  selectedCategories = new Map<string, boolean>([]);
  selectedKeys: string[] = [];

  constructor(
    private authQuery: AuthQuery,
    private authStore: AuthStore,
    private categoryQuery: CategoryQuery,
    private categoryService: CategoryService,
    private modalController: ModalController,
    private settingsService: SettingsService,
    private gameEventService: EventService,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.categoryService.get().subscribe();
  }

  onCategoryClick([cat, selected]: [Category, boolean]) {
    // const currentValue = this.selectedCategories.get(cat.key) || false;
    this.selectedCategories.set(cat.key, selected);
    this.selectedKeys = [...this.selectedCategories.entries()]
      .filter(([key, selected]) => selected)
      .map(([key]) => key);
  }

  savePreferences(dismiss?: boolean) {
    const preferences = [
      {
        name: 'SELECTED_CATEGORIES',
        value: JSON.stringify([...this.selectedCategories.keys()]),
      } as any,
      { name: 'EVENT_PARAMS', value: JSON.stringify(DEFAULT_EVENT_PARAMS) },
    ];
    if (this.authQuery.getValue().isLoggedIn) {
      this.userService.upsertPreferences(preferences).subscribe(() => {
        if (dismiss) {
          this.dismiss();
        }
      });
    } else {
      this.authStore.update((state) => ({
        user: {
          ...state.user,
          preferences: serializePreferences(preferences),
        },
      }));
      // Store selected categories locally, and send them to backend when user registers
      this.dismiss();
    }
  }

  trackByFn(index: number, { id }: Category) {
    return id;
  }

  async dismiss() {
    this.gameEventService
      .setParams(
        this.userService.getUserPreference('EVENT_PARAMS') ||
          DEFAULT_EVENT_PARAMS,
        false,
        true
      )
      .toPromise();
    this.modalController.dismiss(this.selectedCategories);
  }
}
