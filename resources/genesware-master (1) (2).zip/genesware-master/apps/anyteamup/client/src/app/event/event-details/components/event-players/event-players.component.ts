import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { AuthQuery, Event, Request, User } from '@genesware/shared/angular-sdk';
import { ModalController } from '@ionic/angular';

import { UserInfoComponent } from '../../../../user/user-info/user-info.component';

@Component({
  selector: 'app-event-players',
  templateUrl: './event-players.component.html',
  styleUrls: ['./event-players.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventPlayersComponent {
  @Input() event!: Event;
  @Input() requests: Request[] = [];
  playerId = this.authQuery.getValue()?.user?.id;
  constructor(
    private authQuery: AuthQuery,
    private modalCtrl: ModalController
  ) {}

  async onView(user: User) {
    // const { user: currentUser } = this.authQuery.getValue();
    const isUserInPending = this.requests.some(
      ({ createdBy }) =>
        (typeof createdBy === 'string' ? createdBy : (createdBy as any).id) ===
        user.id
    );
    const modal = await this.modalCtrl.create({
      component: UserInfoComponent,
      componentProps: {
        user,
        group: this.event.group,
        currentUser: this.authQuery.getValue().user,
        isUserInPending,
      },
      cssClass: 'transparent-modal',
      keyboardClose: true,
    });
    return await modal.present();
  }

  trackByFn(index: number, { id }: User) {
    return id;
  }
}
