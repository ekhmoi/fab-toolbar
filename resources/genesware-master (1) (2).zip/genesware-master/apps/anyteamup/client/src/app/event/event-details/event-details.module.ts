import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MomentModule } from 'ngx-moment';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';

import { UserModule } from '../../user/user.module';
import { SharedModule } from '../../shared/shared.module';
import { MessageModule } from '../../message/message.module';
import { AuthModule } from '../../auth/auth.module';
import {
  EventDetailsContentComponent,
  EventDetailsHeaderComponent,
  EventOverviewComponent,
  EventPlayersComponent,
  EventStatusSwiperComponent,
} from './components';
import { EventDetailsPage } from './event-details.page';
import { EventDetailsService } from './event-details.service';
import { EventDetailsResolver } from './event-details.resolver';

const routes: Routes = [
  {
    path: '',
    resolve: [EventDetailsResolver],
    component: EventDetailsPage,
  },
];

@NgModule({
  declarations: [
    EventDetailsPage,
    EventDetailsContentComponent,
    EventDetailsHeaderComponent,
    EventOverviewComponent,
    EventPlayersComponent,
    EventStatusSwiperComponent,
  ],
  exports: [EventDetailsPage],
  imports: [
    RouterModule.forChild(routes),
    MomentModule,
    MatIconModule,
    CommonModule,
    SharedModule,
    MessageModule,
    UserModule,
    AuthModule,
    MatMenuModule,
  ],
  providers: [EventDetailsService, EventDetailsResolver],
})
export class EventDetailsModule {}
