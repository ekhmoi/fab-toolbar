import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, Output } from '@angular/core';
import { EventStatus } from '@genesware/shared/angular-sdk';
import { AlertController } from '@ionic/angular';
import { AlertButton, AlertOptions } from '@ionic/core';
import { translate } from '@ngneat/transloco';

@Component({
  selector: 'app-event-status-swiper',
  templateUrl: './event-status-swiper.component.html',
  styleUrls: ['./event-status-swiper.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventStatusSwiperComponent {
  selectedStatusIndex = 0;
  statuses = [
    {
      status: EventStatus.Active,
      color: 'primary',
      width: 180,
      icon: 'search',
      canChange: true,
    },
    {
      status: EventStatus.Confirmed,
      color: 'success',
      width: 180,
      icon: 'checkmark',
      canChange: true,
    },
    {
      status: EventStatus.Finished,
      color: 'secondary',
      width: 130,
      icon: 'checkmark-done',
      canChange: false,
    },
    {
      status: EventStatus.Canceled,
      color: 'danger',
      width: 130,
      icon: 'close',
      canChange: false,
    },
  ];
  statusIndexes = this.statuses.map(({ status }) => status);
  constructor(public alertController: AlertController, private cdr: ChangeDetectorRef) {}

  get currentStatus() {
    return this.statuses[this.selectedStatusIndex] || null;
  }

  @Input() set selectedStatus(status: EventStatus) {
    this.selectedStatusIndex = this.statusIndexes.indexOf(status);
  }

  @Output() statusChange = new EventEmitter<EventStatus>();

  onStatusSelect(statusIndex: number) {
    const status = this.statuses[statusIndex];
    if (!status?.canChange) {
      this.presentAlertConfirm(
        translate('gameEvent.status.confirmAction.title'),
        translate('gameEvent.status.confirmAction.message'),
        {
          text: translate(`gameEvent.status.${status.status}.actionText`),
          cssClass: `no-text-transform color-${status.color || 'dark'}`,
          handler: () => {
            this.selectedStatusIndex = statusIndex;
            this.statusChange.emit(status?.status);
            this.cdr.detectChanges();
          },
        }
      );
    } else {
      this.selectedStatusIndex = statusIndex;
      this.statusChange.emit(status?.status);
    }
  }

  async presentAlertConfirm(header: string, message: string, confirmButton: AlertButton) {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header,
      message,
      buttons: [
        {
          text: translate('gameEvent.status.confirmAction.cancel'),
          role: 'cancel',
          cssClass: 'color-dark no-text-transform',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          },
        },
        confirmButton,
      ],
    });

    await alert.present();
  }
}
