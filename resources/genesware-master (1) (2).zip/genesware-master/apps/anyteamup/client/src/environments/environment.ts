export const environment = {
  production: false,
  googleMapAPIKey: 'AIzaSyDVnWlhrTFcBxDfjWzL9tX7LJvlRWsLud0\n',

  gatewayUrl: 'http://localhost:8101/api',
  assetUrl: 'http://localhost:5002',
  messageUrl: 'http://localhost:5011',
  notificationUrl: 'http://localhost:5012',

  // gatewayUrl: 'http://94.142.237.189:12021/api',
  // assetUrl: 'http://94.142.237.189:12008',
  // messageUrl: 'http://94.142.237.189:12009',
  // notificationUrl: 'http://94.142.237.189:12006',

  // gatewayUrl: 'http://192.168.1.22:12021/api',
  // assetUrl: 'http://192.168.1.22:12008',
  // messageUrl: 'http://192.168.1.22:12009',
  // notificationUrl: 'http://192.168.1.22:12006',

  firebase: {
    apiKey: 'AIzaSyAliGfUiSwzVZ8v3z1cR-QlzzQcxJ-7mNA',
    authDomain: 'tapplay-2021.firebaseapp.com',
    projectId: 'tapplay-2021',
    storageBucket: 'tapplay-2021.appspot.com',
    messagingSenderId: '235164054661',
    appId: '1:235164054661:web:90cc1ab0f0d36b7b2f25ec',
    measurementId: 'G-52G3WFMVR4',
  },
};
