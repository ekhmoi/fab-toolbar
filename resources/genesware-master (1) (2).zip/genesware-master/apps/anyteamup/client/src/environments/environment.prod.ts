export const environment = {
  production: true,

  gatewayUrl: 'https://gateway.anyteamup.com/api',
  assetUrl: 'https://assets.anyteamup.com',
  messageUrl: 'https://messages.anyteamup.com',
  notificationUrl: 'https://notifications.anyteamup.com',
  
  googleMapAPIKey: 'AIzaSyDVnWlhrTFcBxDfjWzL9tX7LJvlRWsLud0\n'
};